﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages.Members
{
    public partial class ShowMembers : Common
    {
        int CH_ID = 0;
        public ShowMembers()
        {
            InitializeComponent();
        }

        private void ShowMemebersInLabel()
		{
            string sql = @"Select * from Committee_Members c INNER JOIN Committee_Hierarchy h 
                        ON c.CH_ID = h.ID Order by CH_ID";
            DataTable dt = (DataTable)Select(sql).Data;
            int left = 1;
            int top = 0;
            int hight = 1;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                int heirarchyId = Convert.ToInt32(dt.Rows[i]["CH_ID"]);
                string name = dt.Rows[i]["MemberName"].ToString();
                string title = dt.Rows[i]["Title"].ToString();
                if (heirarchyId != CH_ID) { left = 1; top = (hight++) * 40; CH_ID = heirarchyId; } else left += 10;
                Label label = new Label();
                label.Text = String.Format("{0}\n{1}", name, title);
                label.Left = 30 * left;
                label.Top = top;
                label.Font = new Font("Arial", 10, FontStyle.Regular);
                int width = 170; //Width available to your label
                using (Graphics g = CreateGraphics())
                {
                    SizeF size = g.MeasureString(label.Text, label.Font);
                    //lines = (int)Math.Ceiling(size.Width / width);
                    label.Height = (int)Math.Ceiling(size.Height);
                    label.Width = width;
                    label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                }

                this.Controls.Add(label);
            }
        }

       
        private void ShowMembers_Load(object sender, EventArgs e)
        {
            ShowMemebersInLabel();
        }

        
    }
}
