﻿using Model;
using Models;
using Racssoft;
using SecurityDesktop.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SecurityDesktop
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
            //ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT Product, SerialNumber FROM Win32_BaseBoard");

            //ManagementObjectCollection information = searcher.Get();
            //foreach (ManagementObject obj in information)
            //{
            //    foreach (PropertyData data in obj.Properties)
            //        listBox1.Items.Add(string.Format("{0} = {1}", data.Name, data.Value));
            //}

            //searcher.Dispose();


            GetBiosInformation();

            InternetCheck.CheckForInternetConnection(url: "https://google.com");



            string ComputerSerialKey = ComputerIdentifications.SerialNumber();

            Common com = new Common();
            Result result = com.Select("SELECT * FROM SETTINGS WHERE KEYCode = '" + ComputerSerialKey + "'");
            if (result != null && result.Data != null)
            {
                DataTable dt = (DataTable)result.Data;
                bool isVerified = dt != null && dt.Rows.Count > 0 ? Convert.ToBoolean(dt?.Rows[0]["IsVerified"]) : false;

                if (!isVerified)
                {
                    SerialKeyValidation serialKeyValidation = new SerialKeyValidation();
                    serialKeyValidation.txtSerial.Text = ComputerIdentifications.SerialNumber();
                    if (result.IsSuccess)
                    {
                        string sql = @"INSERT INTO Settings(Types,Title,KEYCode,IsVerified) VALUES('Security','Computer-Serial','" + ComputerSerialKey + "','0')";
                        com.CUD(sql);
                        serialKeyValidation.ShowDialog();
                    }
                    else
                    {
                        Environment.Exit(0);
                    }
                }
            }

        }
        private void GetBiosInformation()
        {
            string relDt = "";
            try
            {
                //wmic bios get serialnumber in cmd.exe
                ManagementObjectSearcher mSearcher = new ManagementObjectSearcher("SELECT SerialNumber, SMBIOSBIOSVersion, ReleaseDate FROM Win32_BIOS");
                ManagementObjectCollection collection = mSearcher.Get();
                foreach (ManagementObject obj in collection)
                {
                    listBox1.Items.Add(string.Format("Serial Number = {0}", (string)obj["SerialNumber"]));
                    listBox1.Items.Add(string.Format("BIOS Version = {0}", (string)obj["SMBIOSBIOSVersion"]));
                    
                    relDt = (string)obj["ReleaseDate"];
                    DateTime dt = ManagementDateTimeConverter.ToDateTime(relDt);
                    string lblBiosDate = dt.ToString("dd-MMM-yyyy");//date format
                    listBox1.Items.Add(string.Format("BIOS Release Date = {0}", lblBiosDate));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
