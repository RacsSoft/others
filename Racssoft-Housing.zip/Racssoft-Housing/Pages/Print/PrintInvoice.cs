﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Models;

namespace Racssoft_Housing.Pages
{
	public partial class PrintInvoice : Form
	{
		private string ids, months, apartments, comments;
		private double  electricBills, mosqueBills, lpss, dues, gasBill, waterBill, others,totals;

        

        public PrintInvoice(string id,string month,string apartment,double electricBill,double mosqueBill,double lps,double due,string comment,double gas, double water, double other,double total)
		{
			ids = id;
			months = month;
			apartments = apartment;
			comments = comment;
			electricBills = electricBill;
			mosqueBills = mosqueBill;
			lpss = lps;
			dues = due;
			gasBill = gas;
			waterBill = water;
			others = other;
			totals = total;
			InitializeComponent();
		}

		private void label15_Click(object sender, EventArgs e)
		{

		}
		Bitmap bmp;

		private void btnPrint_Click(object sender, EventArgs e)
		{
			btnPrint.Visible = false;

			Graphics g = this.CreateGraphics();
			bmp = new Bitmap(this.Size.Width, this.Size.Height, g);
			Graphics p = Graphics.FromImage(bmp);
			p.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, this.Size);
			//printDialog.ShowDialog();

			printDialog.Document = printDocument;
			if (printDialog.ShowDialog() == DialogResult.OK)
			{
				printDocument.Print();
			}
			this.Close();
		}

		private void PrintBill_Load(object sender, EventArgs e)
		{
			lblMonth.Text = months.ToString();
			lblApartment.Text = apartments.ToString();
			lblDue.Text = dues.ToString();
			lblElectricity.Text = electricBills.ToString();
			lblInvoice.Text = ids.ToString();
			lblMosque.Text = mosqueBills.ToString();
			lblLps.Text = lpss.ToString();
			lblGas.Text = gasBill.ToString();
			lblWater.Text = waterBill.ToString();
			lblOthers.Text = others.ToString();
			lblTotal.Text = totals.ToString();
			
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			e.Graphics.DrawImage(bmp, 0, 0);

			
		}
	}
}
