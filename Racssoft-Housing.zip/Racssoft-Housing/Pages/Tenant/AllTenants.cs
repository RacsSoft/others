﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages.Tenant
{
	public partial class AllTenants : Common
	{
		public AllTenants()
		{
			InitializeComponent();
		}
        private void ShowMemebersInLabel()
        {
            string sql = @"Select * from Tenants t Inner Join One_Building_Flats f on t.FlatID = f.ID";
            DataTable dt = (DataTable)Select(sql).Data;
          
            int width = 200;
            for (int i = 0, top = 0; i < dt?.Rows.Count; i++, top += 40)
            {
                for (int j = 0, left = 0; j < 5 && i < dt.Rows.Count; j++, i++, left++)
                {
                    string flatId = dt.Rows[i]["FlatID"].ToString();
                    string tenantId = dt.Rows[i]["t.ID"].ToString();
                    string flat = dt.Rows[i]["Title"].ToString();
                    string tanentName = dt.Rows[i]["TenantName"].ToString();
                    Label label = new Label();
                    label.Text = string.Format("{0}\n{1}", flat, tanentName);
                    label.Left = width * left;
                    label.Top = top;
                    label.Font = new Font("Arial", 10, FontStyle.Regular);
                    label.Name = "Label_" + tenantId;
                    using (Graphics g = CreateGraphics())
                    {
                        SizeF size = g.MeasureString(label.Text, label.Font);
                        //lines = (int)Math.Ceiling(size.Width / width);
                        label.Height = (int)Math.Ceiling(size.Height);
                        label.Width = width;
                        label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                    }
                    label.Click += new System.EventHandler(label_Click);
                    label.Cursor = Cursors.Hand;
                    this.Controls.Add(label);
                }
                
            }
        }

        private void AllTenants_Load(object sender, EventArgs e)
		{
            ShowMemebersInLabel();

        }

		private void label_Click(object sender, EventArgs e)
		{
            Label lbl = (Label)sender;
            //label1.Text = lbl.Name;
            int tenantId = Convert.ToInt32(lbl.Name.Split('_')[1]);
            TenantDetails tenantDetails = new TenantDetails(tenantId);
            tenantDetails.ShowDialog();
		}
	}
}
