﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Runtime.InteropServices;

namespace Racssoft_Housing.Pages.Tenant
{


	//class ExtendedRichTextBox : RichTextBox
	//{
	//	[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
	//	static extern IntPtr LoadLibrary(string dllName);
	//	protected override CreateParams CreateParams
	//	{
	//		get
	//		{
	//			CreateParams baseParams = base.CreateParams;
	//			if (LoadLibrary("msftedit.dll") != IntPtr.Zero)
	//			{
	//				baseParams.ClassName = "RICHEDIT50W";
	//			}
	//			return baseParams;
	//		}
	//	}
	//}
	public partial class TenantDetails : Common
	{
		int tenantId = 0;
		public TenantDetails(int tId)
		{
			InitializeComponent();
			tenantId = tId;
		}
		//Method to create a table format string which can directly be set to RichTextBox Control
		private void InsertTableInRichtextbox()
		{
			//CreateStringBuilder object
			StringBuilder strTable = new StringBuilder();

			//Beginning of rich text format,don’t alter this line
			strTable.Append(@"{\rtf1 ");

			////Prepare the header Row
			//strTable.Append(@"\trowd");

			////A cell with width 1000.
			//strTable.Append(@"\cellx1000");

			//strTable.Append(@"\intbl   ID");

			////Another cell with width 1000.Endpoint at 2000(which is 1000+1000).
			//strTable.Append(@"\cellx2000");

			//strTable.Append(@"\cell    Name");

			////Another cell with width 1000.Ending at 3000 (which is 2000+1000)
			//strTable.Append(@"\cellx3000");

			//strTable.AppendFormat(@"\cell    City");

			////Another cell with width 1000.End at 4000 (which is 3000+1000)
			//strTable.Append(@"\cellx4000");

			//strTable.Append(@"\cell    Country");

			////Add the created row
			//strTable.Append(@"\intbl \cell \row");


			//Create 5 rows with 4 columns
			for (int i = 0; i < 5; i++)
			{
				//Start the row
				strTable.Append(@"\trowd");

				//First cell with width 1000.
				strTable.Append(@"\cellx1000");

				//Second cell with width 1000.Ending point is 2000, which is 1000+1000.
				strTable.Append(@"\cellx2000");

				//Third cell with width 1000.Endingat3000,which is 2000+1000.
				strTable.Append(@"\cellx3000");

				//Last cell with width 1000.Ending at 4000 (which is 3000+1000)
				strTable.Append(@"\cellx4000");

				//Append the row in StringBuilder
				strTable.Append(@"\intbl \cell \row"); //create the row
			}

			strTable.Append(@"\pard");
			//string rtf1 = txtDetails.Rtf;
			//strTable.Append(@"aaaaaaaaaaaaaaaaa");
			strTable.Append(@"}");

			//strTable.Append(details);

			//txtDetails.Rtf = strTable.ToString();
			//txtDetails.Text = details;
			//txtDetails.Rtf = txtDetails.Rtf.Replace(@"@@@", strTable.ToString());

			StringBuilder tableRtf = new StringBuilder();
			tableRtf.Append(@"{\fonttbl{\f0\fnil\fcharset0 Courier;}}");
			for (int j = 0; j < 5; j++)
			{
				tableRtf.Append(@"\trowd");
				tableRtf.Append(@"\cellx2500" + "  ghhghgjghjghjhggjh");
				tableRtf.Append(@"\intbl\cell");
				tableRtf.Append(@"\cellx10000\intbl\cel");
				tableRtf.Append("   " + "sdfsdfs" + @"\intbl\clmrg\cell\row");
			}

			tableRtf.Append(@"\pard");
			tableRtf.Append(@"}");

			//string rtf1 = txtDetails.Rtf.Trim().TrimEnd('}');
			string rtf2 = tableRtf.ToString();
			//txtDetails.Rtf = rtf1 + rtf2;
			txtDetails.Rtf = rtf2;

			//string rtf1 = txtDetails.Rtf.Trim().TrimEnd('}');
			//string rtf2 = strTable.ToString();
			//txtDetails.Rtf = rtf2;// rtf1 + rtf2;
		}
		// Method to create a table format string with data from a DataTable.

		private static String InsertTableInRichTextBox(DataTable dtbl, int width)
		{
			//Since too much string appending go for string builder
			StringBuilder sringTableRtf = new StringBuilder();

			//beginning of rich text format,dont customize this begining line
			sringTableRtf.Append(@"{\rtf1 ");

			//create 5 rows with 3 cells each
			int cellWidth;

			//Start the Row
			sringTableRtf.Append(@"\trowd");

			//Populate the Table header from DataTable column headings.
			for (int j = 0; j < dtbl.Columns.Count; j++)
     {
				//A cell with width 1000.
				sringTableRtf.Append(@"\cellx" + ((j + 1) * width).ToString());

				if (j == 0)
					sringTableRtf.Append(@"\intbl  " + dtbl.Columns[j].ColumnName);
				else
					sringTableRtf.Append(@"\cell   " + dtbl.Columns[j].ColumnName);
			}

			//Add the table header row
			sringTableRtf.Append(@"\intbl \cell \row");

			//Loop to populate the table cell data from DataTable
			for (int i = 0; i < dtbl.Rows.Count; i++)
      {
				//Start the Row
				sringTableRtf.Append(@"\trowd");

				for (int j = 0; j < dtbl.Columns.Count; j++)
          {
					cellWidth = (j + 1) * width;

					//A cell with width 1000.
					sringTableRtf.Append(@"\cellx" + cellWidth.ToString());

					if (j == 0)
						sringTableRtf.Append(@"\intbl  " + dtbl.Rows[i][j].ToString());
					else
						sringTableRtf.Append(@"\cell   " + dtbl.Rows[i][j].ToString());
				}

				//Insert data row
				sringTableRtf.Append(@"\intbl \cell \row");
			}

			sringTableRtf.Append(@"\pard");
			sringTableRtf.Append(@"}");

			//convert the string builder to string
			return sringTableRtf.ToString();
		}
		
		private void TenantDetails_Load(object sender, EventArgs e)
		{
			string sql = @"Select TenantName as [Tenant Name], FatherName as [Father's Name], DOB as [Date of Birth],
NID,  MaritalStatus as [Marital Status], PermanentAddress as [Permanent Address], f.Title as Flat, 
Occupation, Religion, Education, Mobile as [Contact Number], Email, NID, Passport 
from Tenants t INNER JOIN One_Building_Flats f ON t.FlatID = f.ID where t.ID = " + tenantId;
			DataTable dt = (DataTable)Select(sql).Data;
			string details = string.Empty;
			int col = dt.Columns.Count;
			for (int i = 0; i < col; i++)
			{
				details += dt.Columns[i].ColumnName + ": " + dt.Rows[0][i].ToString() + Environment.NewLine;
			}

			txtDetails.Text = details;

			txtDetails.Text += "Family Members:" + Environment.NewLine;
			txtDetails.Text += "Name \t\t Age \t Occupation \t Mobile" + Environment.NewLine;
			sql = @"SELECT FName as[Name], FAge as [Age], FOccupation as [Occupation], FMobile as [Mobile] FROM Tenant_Family_Members where TenantID = " + tenantId;
			dt = (DataTable)Select(sql).Data;
			details = string.Empty;
			for (int i = 0; i < dt.Rows.Count; i++)
            {
				details += (i+1) + "." + dt.Rows[i][0] + " \t " + dt.Rows[i][1] + " \t " + dt.Rows[i][2] + " \t " + dt.Rows[i][3] + Environment.NewLine;
			}
			txtDetails.Text += details;
		}

		private void btnPrint_Click(object sender, EventArgs e)
		{
			if (printDialog1.ShowDialog() == DialogResult.OK)
			{
				printDocument1.Print();
			}
		}

		private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
		{
			char[] param = { '\n' };

			if (printDialog1.PrinterSettings.PrintRange == PrintRange.Selection)
			{
				lines = txtDetails.SelectedText.Split(param);
			}
			else
			{
				lines = txtDetails.Text.Split(param);
			}

			int i = 0;
			char[] trimParam = { '\r' };
			foreach (string s in lines)
			{
				lines[i++] = s.TrimEnd(trimParam);
			}
		}

		private int linesPrinted;
		private string[] lines;

		private void OnPrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			int x = e.MarginBounds.Left;
			int y = e.MarginBounds.Top;
			Brush brush = new SolidBrush(txtDetails.ForeColor);

			while (linesPrinted < lines.Length)
			{
				e.Graphics.DrawString(lines[linesPrinted++],
					txtDetails.Font, brush, x, y);
				y += 15;
				if (y >= e.MarginBounds.Bottom)
				{
					e.HasMorePages = true;
					return;
				}
			}

			linesPrinted = 0;
			e.HasMorePages = false;
		}



		//private void a()
		//{
		//	//Instance of the customized RichTextBox control class.Create Instance
		//	//Programatically.
		//	ExtendedRichTextBox advRichTextBox = new ExtendedRichTextBox();
		//	advRichTextBox.Size = new Size(200, 50);

		//	//Uncomment this linerichTextBox.MaximumSize if you want to limit the size of
		//	//rich textbox.Scollbar gets enabled automaticallywhen it crosses this maximum
		//	//limit.
		//	//richTextBox.MaximumSize = new Size(500, 400);
		//	//Since too much string appending, go for string builder
		//	StringBuilder strRtfTable = new StringBuilder();

		//	//beginning of rich text format,dont customize this begining line
		//	strRtfTable.Append(@"{\rtf1 ");
		//	//create 5 rows with 3 cells each.Write a method with parameters for accepting any no of rows and columns.

		//	for (int i = 0; i < 5; i++)
  //          {
		//		strRtfTable.Append(@"\trowd");

		//		strRtfTable.Append(@"\cellx1000");

		//		strRtfTable.Append(@"\cellx2000");

		//		//Last cell with width 2000.Last position is 4000 (which is 2000+2000)
		//		strRtfTable.Append(@"\cellx4000");

		//		strRtfTable.Append(@"\intbl \cell \row"); //create row
		//	}

		//	strRtfTable.Append(@"\pard");
		//	strRtfTable.Append(@"}");
		//	advRichTextBox.Rtf = strRtfTable.ToString();

		//	//Add the programatically created richtextbox to the form's control collection.
		//	//Else it won't be displayed in form.
		//	this.Controls.Add(advRichTextBox);

		//	//Bring the control to top level,else will be appearing in back.
		//	advRichTextBox.BringToFront();
		//}
	}
}
