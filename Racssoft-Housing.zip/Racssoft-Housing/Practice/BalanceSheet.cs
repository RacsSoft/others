﻿using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Schema;

namespace Racssoft_Housing.Pages
{
    public partial class BalanceSheet : Common
    {
        public BalanceSheet()
        {
            InitializeComponent();
        }

        void graph()
        {
            saleChart.Series["sale"].Points.AddXY("Profit", 10000);
            saleChart.Series["sale"].Points[0].Color = Color.YellowGreen;
            saleChart.Series["sale"].Points.AddXY("Loss", 200);
            saleChart.Series["sale"].Points[1].Color = Color.Red;
        }
        private void BalanceSheet_Load(object sender, EventArgs e)
        {
            graph();
            LoadCredit(dpFrom.Value, dpTo.Value);
            LoadDebit(dpFrom.Value, dpTo.Value);
           

            var openingBalance = Balance(dpFrom.Value.AddDays(-1));
            openingBalanceCalculation(openingBalance);
            var currentBalance = Balance(dpTo.Value);
            currentBalanceCalculation(currentBalance);

            for(int y = 2021; y <= DateTime.Now.Year; y++)
			{
                cmbYear.Items.Add(y);
			}
            cmbSearch.SelectedIndex = 0;
        }

        private void openingBalanceCalculation((double, double, double, double) openingBalance)
        {
            double cash = openingBalance.Item1 - openingBalance.Item3;
            lblOpeningBalanceB.Text = "Opening Balance: " + cash.ToString();
            lblOpeningBalanceCash.Text = "Opening Balance(Cash): " + cash.ToString();
            lblOpeningBalanceBank.Text = "Opening Balance(Bank): " + (openingBalance.Item2 - openingBalance.Item4);
        }
        private void currentBalanceCalculation((double, double, double, double) currentBalance)
        {
            lblCurrentBalance.Text = "Current Balance: " + (currentBalance.Item1 - currentBalance.Item3).ToString();
            lblCurrentBalanceCash.Text = "Current Balance(Cash): " + (currentBalance.Item1 - currentBalance.Item3).ToString();
            lblCurrentBalanceBank.Text = "Current Balance(Bank): " + (currentBalance.Item2 - currentBalance.Item4);
        }

        void LoadCredit(DateTime dFrom, DateTime dTo)
        {
            string sql = @"SELECT PaidCash as Cash, PaidBank as Bank, DueAmmount as [Due], PaidDate as [Paid Date] FROM Bill_Collection 
                    WHERE PaidDate Between #" + dFrom.Date + "# AND #" + dTo.Date + "# ";
            DataTable dt = (DataTable)Select(sql).Data;
            dgCredit.DataSource = dt;
            object totalCash = dt?.Compute("Sum(Cash)", "");
            object totalBank = dt?.Compute("Sum(Bank)", "");
            totalCash = totalCash is DBNull ? 0 : totalCash;
            totalBank = totalBank is DBNull ? 0 : totalBank;
            double total = Convert.ToDouble(totalCash) + Convert.ToDouble(totalBank);
            lblTotalCredit.Text = "Total Credit: " + total;
            lblCreditCash.Text = "Cash: " + totalCash;
            lblCreditBank.Text = "Bank: " + totalBank;
        }
        void LoadDebit(DateTime dFrom, DateTime dTo)
        {
            string sql = @"SELECT WhichDateTime as [Collection Date], Cash, Bank FROM Daily_Expenditure_Debit 
                        WHERE WhichDateTime Between #" + dFrom.Date + "# AND #" + dTo.Date + "#";
            DataTable dt = (DataTable)Select(sql).Data;
            dgDebit.DataSource = dt;
            object totalCash = dt?.Compute("Sum(Cash)", "");
            object totalBank = dt?.Compute("Sum(Bank)", "");
            totalCash = totalCash is DBNull ? 0 : totalCash;
            totalBank = totalBank is DBNull ? 0 : totalBank;
            double total = Convert.ToDouble(totalCash) + Convert.ToDouble(totalBank);
            lblTotalDebit.Text = "Total Debit: " + total;
        }
        (double, double, double, double) Balance(DateTime date)
        {
            string sql = @"SELECT PaidCash as [Cash], PaidBank as [Bank], DueAmmount as [Due], PaidDate as [Paid Date] FROM Bill_Collection WHERE PaidDate = #" + date.Date.ToString("MM/dd/yyyy") + "#";
            DataTable dt = (DataTable)Select(sql).Data;

            object totoalCreditCash = dt?.Compute("Sum(Cash)", "");
            totoalCreditCash = totoalCreditCash is DBNull ? 0 : totoalCreditCash;
            
            object totoalCreditBank = dt?.Compute("Sum(Bank)", "");
            totoalCreditBank = totoalCreditBank is DBNull ? 0 : totoalCreditBank;

            sql = @"SELECT WhichDateTime as [Collection Date], Cash, Bank FROM Daily_Expenditure_Debit WHERE WhichDateTime = #" + date.Date.ToString("MM/dd/yyyy") + "#";
            dt = (DataTable)Select(sql).Data;

            object totoalDebitCash = dt?.Compute("Sum(Cash)", "");
            totoalDebitCash = totoalDebitCash is DBNull ? 0 : totoalDebitCash; 
            
            object totoalDebitBank = dt?.Compute("Sum(Bank)", "");
            totoalDebitBank = totoalDebitBank is DBNull ? 0 : totoalDebitBank;
            return (Convert.ToDouble(totoalCreditCash), Convert.ToDouble(totoalCreditBank), Convert.ToDouble(totoalDebitCash), Convert.ToDouble(totoalDebitBank));
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (dpFrom.Value > dpTo.Value) { lblMessage.Text = "Date range not valid!"; lblMessage.Visible = true; return; }
            LoadCredit(dpFrom.Value, dpTo.Value);
            LoadDebit(dpFrom.Value, dpTo.Value);

            var openingBalance = Balance(dpFrom.Value.Date.AddDays(-1));
            openingBalanceCalculation(openingBalance);
            var currentBalance = Balance(dpTo.Value);
            currentBalanceCalculation(currentBalance);
        }

        private void cmbSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            string searchText = cmbSearch.Text;
            if(searchText == "Today")
			{
                //graph();
                DateTime dateTime = DateTime.Now.Date;
                LoadCredit(dateTime, dateTime);
                LoadDebit(dateTime, dateTime);

                var openingBalance = Balance(dateTime.AddDays(-1));
                openingBalanceCalculation(openingBalance);
                var currentBalance = Balance(dpTo.Value);
                currentBalanceCalculation(currentBalance);
            }
            if (searchText == "Month Wise")
            {
                cmbYear.Visible = true;
                cmbMonth.Visible = true;
                //calendar.Visible = true;
                dpFrom.Visible = false;
                dpTo.Visible = false;
                btnRefresh.Visible = false;
                //calculation
            }
            else if (searchText == "Date Wise")
            {
                //calendar.Visible = false;
                cmbYear.Visible = false;
                cmbMonth.Visible = false;
                dpFrom.Visible = true;
                dpTo.Visible = true;
                btnRefresh.Visible = true;
                //calculation
            }
            else if (searchText == "This Month")
            {
                DateTime dateTime = DateTime.Now.Date;
                var firstDayOfMonth = new DateTime(dateTime.Year, dateTime.Month, 1);
                //graph();
                LoadCredit(firstDayOfMonth, dateTime);
                LoadDebit(firstDayOfMonth, dateTime);

                var openingBalance = Balance(dateTime.AddDays(-1));
                openingBalanceCalculation(openingBalance);
                var currentBalance = Balance(dpTo.Value);
                currentBalanceCalculation(currentBalance);
            }
            else if (searchText == "Last Month")
            {
                DateTime dateTime = DateTime.Now.Date;
                var firstDayOfLastMonth = new DateTime(dateTime.Year, dateTime.AddMonths(-1).Month, 1);
                var lastDayOfLastMonth = firstDayOfLastMonth.AddMonths(1).AddDays(-1);
                //graph();
                LoadCredit(firstDayOfLastMonth, lastDayOfLastMonth);
                LoadDebit(firstDayOfLastMonth, lastDayOfLastMonth);


                var openingBalance = Balance(dateTime.AddDays(-1));
                openingBalanceCalculation(openingBalance);
                var currentBalance = Balance(dpTo.Value);
                currentBalanceCalculation(currentBalance);
            }
            else if (searchText == "This Year")
            {
                DateTime dateTime = DateTime.Now.Date;
                var firstDayOfYear = new DateTime(dateTime.Year, 1, 1);
                
                //graph();
                LoadCredit(firstDayOfYear, dateTime);
                LoadDebit(firstDayOfYear, dateTime);


                var openingBalance = Balance(dateTime.AddDays(-1));
                openingBalanceCalculation(openingBalance);
                var currentBalance = Balance(dpTo.Value);
                currentBalanceCalculation(currentBalance);
            }
            else if (searchText == "Last Year")
            {
                //graph();
                DateTime dateTime = DateTime.Now.Date;
                var firstDayOfLastYear = new DateTime(dateTime.AddYears(-1).Year, 1, 1);
                var lastDayOfLstYear = new DateTime(dateTime.AddYears(-1).Year, 12, 31);
                LoadCredit(firstDayOfLastYear, lastDayOfLstYear);
                LoadDebit(firstDayOfLastYear, lastDayOfLstYear);


                var openingBalance = Balance(dateTime.AddDays(-1));
                openingBalanceCalculation(openingBalance);
                var currentBalance = Balance(dpTo.Value);
                currentBalanceCalculation(currentBalance);
            }
        }

		private void cmbYear_SelectedIndexChanged(object sender, EventArgs e)
		{
            if (!string.IsNullOrEmpty(cmbYear.Text) && !string.IsNullOrEmpty(cmbMonth.Text)) {
                //graph();
                (double, double, double, double) balance = BalanceMonthWise(cmbMonth.SelectedIndex+1, Convert.ToInt32(cmbYear.Text));
                double totalDebit = balance.Item3 + balance.Item4;
                lblTotalDebit.Text = "Total Debit: " + totalDebit;

                double totalCredit = balance.Item1 + balance.Item2;
                lblTotalCredit.Text = "Total Credit: " + totalCredit;
                lblCreditCash.Text = "Cash: " + balance.Item1;
                lblCreditBank.Text = "Bank: " + balance.Item2;
            }
        }

        (double, double, double, double) BalanceMonthWise(int month, int year)
        {
            string sql = @"SELECT PaidCash as [Cash], PaidBank as [Bank], DueAmmount as [Due], PaidDate as [Paid Date] FROM Bill_Collection WHERE Month(PaidDate) = " + month + " and Year(PaidDate) = " + year;
            DataTable dt = (DataTable)Select(sql).Data;

            object totoalCreditCash = dt?.Compute("Sum(Cash)", "");
            totoalCreditCash = totoalCreditCash is DBNull ? 0 : totoalCreditCash;

            object totoalCreditBank = dt?.Compute("Sum(Bank)", "");
            totoalCreditBank = totoalCreditBank is DBNull ? 0 : totoalCreditBank;

            sql = @"SELECT WhichDateTime as [Collection Date], Cash, Bank FROM Daily_Expenditure_Debit WHERE Month(WhichDateTime) = " + month + " and Year(WhichDateTime) = " + year;
            dt = (DataTable)Select(sql).Data;

            object totoalDebitCash = dt?.Compute("Sum(Cash)", "");
            totoalDebitCash = totoalDebitCash is DBNull ? 0 : totoalDebitCash;

            object totoalDebitBank = dt?.Compute("Sum(Bank)", "");
            totoalDebitBank = totoalDebitBank is DBNull ? 0 : totoalDebitBank;
            return (Convert.ToDouble(totoalCreditCash), Convert.ToDouble(totoalCreditBank), Convert.ToDouble(totoalDebitCash), Convert.ToDouble(totoalDebitBank));
        }
    }
}
