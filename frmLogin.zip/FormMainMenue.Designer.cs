﻿
namespace Racssoft_Housing
{
    partial class FormMainMenue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenue = new System.Windows.Forms.Panel();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnMemberManage = new System.Windows.Forms.Button();
            this.btnDocumentUp = new System.Windows.Forms.Button();
            this.panelMemberManage = new System.Windows.Forms.Panel();
            this.btnMemberTitle = new System.Windows.Forms.Button();
            this.btnMemberListAdd = new System.Windows.Forms.Button();
            this.btnShowMember = new System.Windows.Forms.Button();
            this.btnTenantInfo = new System.Windows.Forms.Button();
            this.btnCashMainTain = new System.Windows.Forms.Button();
            this.btnBillCollection = new System.Windows.Forms.Button();
            this.btnBillInvoice = new System.Windows.Forms.Button();
            this.btnDailyExpenditure = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.btnMinimze = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCloseChildForm = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelDesktopPane = new System.Windows.Forms.Panel();
            this.panelMenue.SuspendLayout();
            this.panelMemberManage.SuspendLayout();
            this.panelLogo.SuspendLayout();
            this.panelTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenue
            // 
            this.panelMenue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelMenue.Controls.Add(this.btnSettings);
            this.panelMenue.Controls.Add(this.btnMemberManage);
            this.panelMenue.Controls.Add(this.btnDocumentUp);
            this.panelMenue.Controls.Add(this.panelMemberManage);
            this.panelMenue.Controls.Add(this.btnTenantInfo);
            this.panelMenue.Controls.Add(this.btnCashMainTain);
            this.panelMenue.Controls.Add(this.btnBillCollection);
            this.panelMenue.Controls.Add(this.btnBillInvoice);
            this.panelMenue.Controls.Add(this.btnDailyExpenditure);
            this.panelMenue.Controls.Add(this.panelLogo);
            this.panelMenue.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenue.Location = new System.Drawing.Point(0, 0);
            this.panelMenue.Name = "panelMenue";
            this.panelMenue.Size = new System.Drawing.Size(220, 603);
            this.panelMenue.TabIndex = 0;
            // 
            // btnSettings
            // 
            this.btnSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSettings.FlatAppearance.BorderSize = 0;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnSettings.Image = global::Racssoft_Housing.Properties.Resources.settings;
            this.btnSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettings.Location = new System.Drawing.Point(0, 375);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnSettings.Size = new System.Drawing.Size(220, 50);
            this.btnSettings.TabIndex = 9;
            this.btnSettings.Text = "  Settings";
            this.btnSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnMemberManage
            // 
            this.btnMemberManage.FlatAppearance.BorderSize = 0;
            this.btnMemberManage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMemberManage.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberManage.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMemberManage.Image = global::Racssoft_Housing.Properties.Resources.team;
            this.btnMemberManage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMemberManage.Location = new System.Drawing.Point(0, 426);
            this.btnMemberManage.Name = "btnMemberManage";
            this.btnMemberManage.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnMemberManage.Size = new System.Drawing.Size(220, 50);
            this.btnMemberManage.TabIndex = 7;
            this.btnMemberManage.Text = "  Member Manage";
            this.btnMemberManage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMemberManage.UseVisualStyleBackColor = true;
            this.btnMemberManage.Click += new System.EventHandler(this.btnMemberManage_Click);
            // 
            // btnDocumentUp
            // 
            this.btnDocumentUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDocumentUp.FlatAppearance.BorderSize = 0;
            this.btnDocumentUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDocumentUp.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDocumentUp.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnDocumentUp.Image = global::Racssoft_Housing.Properties.Resources.upload;
            this.btnDocumentUp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDocumentUp.Location = new System.Drawing.Point(0, 325);
            this.btnDocumentUp.Name = "btnDocumentUp";
            this.btnDocumentUp.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnDocumentUp.Size = new System.Drawing.Size(220, 50);
            this.btnDocumentUp.TabIndex = 8;
            this.btnDocumentUp.Text = "  Document Upload";
            this.btnDocumentUp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDocumentUp.UseVisualStyleBackColor = true;
            this.btnDocumentUp.Click += new System.EventHandler(this.btnDocumentUp_Click);
            // 
            // panelMemberManage
            // 
            this.panelMemberManage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panelMemberManage.Controls.Add(this.btnMemberTitle);
            this.panelMemberManage.Controls.Add(this.btnMemberListAdd);
            this.panelMemberManage.Controls.Add(this.btnShowMember);
            this.panelMemberManage.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelMemberManage.Location = new System.Drawing.Point(0, 476);
            this.panelMemberManage.Name = "panelMemberManage";
            this.panelMemberManage.Size = new System.Drawing.Size(220, 127);
            this.panelMemberManage.TabIndex = 0;
            // 
            // btnMemberTitle
            // 
            this.btnMemberTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMemberTitle.FlatAppearance.BorderSize = 0;
            this.btnMemberTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMemberTitle.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberTitle.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMemberTitle.Image = global::Racssoft_Housing.Properties.Resources.upload;
            this.btnMemberTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMemberTitle.Location = new System.Drawing.Point(0, 80);
            this.btnMemberTitle.Name = "btnMemberTitle";
            this.btnMemberTitle.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnMemberTitle.Size = new System.Drawing.Size(220, 40);
            this.btnMemberTitle.TabIndex = 12;
            this.btnMemberTitle.Text = "  Member Title";
            this.btnMemberTitle.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMemberTitle.UseVisualStyleBackColor = true;
            this.btnMemberTitle.Click += new System.EventHandler(this.btnMemberTitle_Click);
            // 
            // btnMemberListAdd
            // 
            this.btnMemberListAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMemberListAdd.FlatAppearance.BorderSize = 0;
            this.btnMemberListAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMemberListAdd.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMemberListAdd.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMemberListAdd.Image = global::Racssoft_Housing.Properties.Resources.upload;
            this.btnMemberListAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMemberListAdd.Location = new System.Drawing.Point(0, 40);
            this.btnMemberListAdd.Name = "btnMemberListAdd";
            this.btnMemberListAdd.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnMemberListAdd.Size = new System.Drawing.Size(220, 40);
            this.btnMemberListAdd.TabIndex = 11;
            this.btnMemberListAdd.Text = "  Member List Add";
            this.btnMemberListAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMemberListAdd.UseVisualStyleBackColor = true;
            this.btnMemberListAdd.Click += new System.EventHandler(this.btnMemberListAdd_Click);
            // 
            // btnShowMember
            // 
            this.btnShowMember.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnShowMember.FlatAppearance.BorderSize = 0;
            this.btnShowMember.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowMember.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowMember.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnShowMember.Image = global::Racssoft_Housing.Properties.Resources.upload;
            this.btnShowMember.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnShowMember.Location = new System.Drawing.Point(0, 0);
            this.btnShowMember.Name = "btnShowMember";
            this.btnShowMember.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnShowMember.Size = new System.Drawing.Size(220, 40);
            this.btnShowMember.TabIndex = 10;
            this.btnShowMember.Text = "  Show Member";
            this.btnShowMember.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnShowMember.UseVisualStyleBackColor = true;
            this.btnShowMember.Click += new System.EventHandler(this.btnShowMember_Click);
            // 
            // btnTenantInfo
            // 
            this.btnTenantInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTenantInfo.FlatAppearance.BorderSize = 0;
            this.btnTenantInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTenantInfo.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTenantInfo.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTenantInfo.Image = global::Racssoft_Housing.Properties.Resources.project;
            this.btnTenantInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTenantInfo.Location = new System.Drawing.Point(0, 275);
            this.btnTenantInfo.Name = "btnTenantInfo";
            this.btnTenantInfo.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnTenantInfo.Size = new System.Drawing.Size(220, 50);
            this.btnTenantInfo.TabIndex = 6;
            this.btnTenantInfo.Text = "  Tenant Info Manage";
            this.btnTenantInfo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTenantInfo.UseVisualStyleBackColor = true;
            this.btnTenantInfo.Click += new System.EventHandler(this.btnTenantInfo_Click);
            // 
            // btnCashMainTain
            // 
            this.btnCashMainTain.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCashMainTain.FlatAppearance.BorderSize = 0;
            this.btnCashMainTain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCashMainTain.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCashMainTain.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCashMainTain.Image = global::Racssoft_Housing.Properties.Resources.money_management;
            this.btnCashMainTain.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCashMainTain.Location = new System.Drawing.Point(0, 225);
            this.btnCashMainTain.Name = "btnCashMainTain";
            this.btnCashMainTain.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnCashMainTain.Size = new System.Drawing.Size(220, 50);
            this.btnCashMainTain.TabIndex = 5;
            this.btnCashMainTain.Text = "  Cash Maintain";
            this.btnCashMainTain.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCashMainTain.UseVisualStyleBackColor = true;
            this.btnCashMainTain.Click += new System.EventHandler(this.btnCashMainTain_Click);
            // 
            // btnBillCollection
            // 
            this.btnBillCollection.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBillCollection.FlatAppearance.BorderSize = 0;
            this.btnBillCollection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBillCollection.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBillCollection.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBillCollection.Image = global::Racssoft_Housing.Properties.Resources.bills;
            this.btnBillCollection.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBillCollection.Location = new System.Drawing.Point(0, 175);
            this.btnBillCollection.Name = "btnBillCollection";
            this.btnBillCollection.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnBillCollection.Size = new System.Drawing.Size(220, 50);
            this.btnBillCollection.TabIndex = 4;
            this.btnBillCollection.Text = "  Bill Collection";
            this.btnBillCollection.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBillCollection.UseVisualStyleBackColor = true;
            this.btnBillCollection.Click += new System.EventHandler(this.btnBillCollection_Click);
            // 
            // btnBillInvoice
            // 
            this.btnBillInvoice.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBillInvoice.FlatAppearance.BorderSize = 0;
            this.btnBillInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBillInvoice.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBillInvoice.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBillInvoice.Image = global::Racssoft_Housing.Properties.Resources.bill;
            this.btnBillInvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBillInvoice.Location = new System.Drawing.Point(0, 125);
            this.btnBillInvoice.Name = "btnBillInvoice";
            this.btnBillInvoice.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnBillInvoice.Size = new System.Drawing.Size(220, 50);
            this.btnBillInvoice.TabIndex = 3;
            this.btnBillInvoice.Text = "  Bill Invoice";
            this.btnBillInvoice.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnBillInvoice.UseVisualStyleBackColor = true;
            this.btnBillInvoice.Click += new System.EventHandler(this.btnBillInvoice_Click);
            // 
            // btnDailyExpenditure
            // 
            this.btnDailyExpenditure.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDailyExpenditure.FlatAppearance.BorderSize = 0;
            this.btnDailyExpenditure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDailyExpenditure.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDailyExpenditure.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnDailyExpenditure.Image = global::Racssoft_Housing.Properties.Resources.expensesss;
            this.btnDailyExpenditure.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDailyExpenditure.Location = new System.Drawing.Point(0, 75);
            this.btnDailyExpenditure.Name = "btnDailyExpenditure";
            this.btnDailyExpenditure.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnDailyExpenditure.Size = new System.Drawing.Size(220, 50);
            this.btnDailyExpenditure.TabIndex = 2;
            this.btnDailyExpenditure.Text = "  Daily Expenditure";
            this.btnDailyExpenditure.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDailyExpenditure.UseVisualStyleBackColor = true;
            this.btnDailyExpenditure.Click += new System.EventHandler(this.btnDailyExpenditure_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panelLogo.Controls.Add(this.label2);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(220, 75);
            this.panelLogo.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(45, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 30);
            this.label2.TabIndex = 0;
            this.label2.Text = "RacsApart";
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.panelTitleBar.Controls.Add(this.btnMinimze);
            this.panelTitleBar.Controls.Add(this.btnClose);
            this.panelTitleBar.Controls.Add(this.btnCloseChildForm);
            this.panelTitleBar.Controls.Add(this.lblTitle);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(220, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(929, 75);
            this.panelTitleBar.TabIndex = 1;
            this.panelTitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTitleBar_MouseDown);
            // 
            // btnMinimze
            // 
            this.btnMinimze.FlatAppearance.BorderSize = 0;
            this.btnMinimze.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimze.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimze.ForeColor = System.Drawing.Color.White;
            this.btnMinimze.Image = global::Racssoft_Housing.Properties.Resources.minimize_tab;
            this.btnMinimze.Location = new System.Drawing.Point(850, 3);
            this.btnMinimze.Name = "btnMinimze";
            this.btnMinimze.Size = new System.Drawing.Size(35, 35);
            this.btnMinimze.TabIndex = 3;
            this.btnMinimze.UseVisualStyleBackColor = true;
            this.btnMinimze.Click += new System.EventHandler(this.btnMinimze_Click);
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Image = global::Racssoft_Housing.Properties.Resources.close_button;
            this.btnClose.Location = new System.Drawing.Point(889, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(35, 35);
            this.btnClose.TabIndex = 2;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCloseChildForm
            // 
            this.btnCloseChildForm.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnCloseChildForm.FlatAppearance.BorderSize = 0;
            this.btnCloseChildForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloseChildForm.Image = global::Racssoft_Housing.Properties.Resources.cancel1;
            this.btnCloseChildForm.Location = new System.Drawing.Point(0, 0);
            this.btnCloseChildForm.Name = "btnCloseChildForm";
            this.btnCloseChildForm.Size = new System.Drawing.Size(75, 75);
            this.btnCloseChildForm.TabIndex = 1;
            this.btnCloseChildForm.Text = " ";
            this.btnCloseChildForm.UseVisualStyleBackColor = true;
            this.btnCloseChildForm.Click += new System.EventHandler(this.btnCloseChildForm_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(408, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(128, 28);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Dashboard";
            // 
            // panelDesktopPane
            // 
            this.panelDesktopPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktopPane.Location = new System.Drawing.Point(220, 75);
            this.panelDesktopPane.Name = "panelDesktopPane";
            this.panelDesktopPane.Size = new System.Drawing.Size(929, 528);
            this.panelDesktopPane.TabIndex = 2;
            // 
            // FormMainMenue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1149, 603);
            this.ControlBox = false;
            this.Controls.Add(this.panelDesktopPane);
            this.Controls.Add(this.panelTitleBar);
            this.Controls.Add(this.panelMenue);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMainMenue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FormMainMenue_Load);
            this.panelMenue.ResumeLayout(false);
            this.panelMemberManage.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            this.panelTitleBar.ResumeLayout(false);
            this.panelTitleBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenue;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnTenantInfo;
        private System.Windows.Forms.Button btnCashMainTain;
        private System.Windows.Forms.Button btnBillCollection;
        private System.Windows.Forms.Button btnBillInvoice;
        private System.Windows.Forms.Button btnDailyExpenditure;
        private System.Windows.Forms.Button btnMemberManage;
        private System.Windows.Forms.Button btnDocumentUp;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelDesktopPane;
        private System.Windows.Forms.Button btnCloseChildForm;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMinimze;
        private System.Windows.Forms.Panel panelMemberManage;
        private System.Windows.Forms.Button btnMemberTitle;
        private System.Windows.Forms.Button btnMemberListAdd;
        private System.Windows.Forms.Button btnShowMember;
    }
}