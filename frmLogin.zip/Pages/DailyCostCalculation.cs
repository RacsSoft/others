﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class DailyCostCalculation : Common
    {
        TextBox textBox = new TextBox();
        public DailyCostCalculation()
        {
            InitializeComponent();
            
        }

        private void DailyCostCalculation_Load(object sender, EventArgs e)
        {
            getDailyCostCal();
            dataGridView1.AutoGenerateColumns = false;
            lblMessage.Text = "";
            DeleteButton();
            LoadTheme();
        }
        
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label4.ForeColor = ThemeColor.PrimaryColor;
            label5.ForeColor = ThemeColor.PrimaryColor;
            label6.ForeColor = ThemeColor.PrimaryColor;
            label7.ForeColor = ThemeColor.PrimaryColor;
            label8.ForeColor = ThemeColor.PrimaryColor;
            lblDue.ForeColor = ThemeColor.PrimaryColor;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = ThemeColor.SecondaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.Gainsboro;
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;

            
        }

        void DeleteButton()
        {
            DataGridViewButtonColumn DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.UseColumnTextForButtonValue = true;
            DeleteButton.HeaderText = "Delete";
            DeleteButton.DataPropertyName = "lnkColumn";
            //DeleteButton.LinkBehavior = LinkBehavior.SystemDefault;
            DeleteButton.Text = "Delete";
            DeleteButton.Name = "Delete";
            DeleteButton.FlatStyle = FlatStyle.Flat;
            DeleteButton.DefaultCellStyle.ForeColor = Color.White;
            DeleteButton.DefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            DeleteButton.DefaultCellStyle.SelectionBackColor = ThemeColor.SecondaryColor;
            DeleteButton.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.Columns.Add(DeleteButton);
        }
        
        private void textBox_Click(object sender, EventArgs e)
        {
            if(sender.GetType() == typeof(TextBox))
            ((TextBox)sender).SelectAll();
            else if (sender.GetType() == typeof(NumericUpDown))
            {
                NumericUpDown numeric = (NumericUpDown)sender;
                (numeric).Select(0, numeric.Value.ToString().Length+3);
            }
            else
            {
                ((RichTextBox)sender).SelectAll();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string title = txtTitle.Text.Trim();
                string detail = txtDetails.Text.Trim();
                string comment = txtComments.Text.Trim();
                decimal payable = txtPayable.Value;
                decimal due = txtPayable.Value - txtPaid.Value;
                bool isPaid = due == 0 ? true : false;
                string sql = @"INSERT INTO Daily_Expenditure_Debit(Title, Details, Comment, Cost, Due,
                        WhichDateTime,IsPaid) Values('" + title + "', '" + detail + "','" + comment + "',"
                            + payable + ", " + due + ",'" + dateTimePicker.Value + "'," + isPaid + ")";
                CUD(sql);
                getDailyCostCal();
                lblMessage.Text = Program.InsertSuccessMessage;
                lblMessage.ForeColor = Color.Green;
                clear();
            }
            catch(Exception ex)
            {
                ex.ToString();
            }
            

        }
        private void txt_Leave_Event_ForCal_Due(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtPaid.Value.ToString()) && !String.IsNullOrEmpty(txtPayable.Value.ToString()))
            {
                lblDue.Text = (txtPayable.Value - txtPaid.Value).ToString();
            }
        }
        void clear()
        {
            txtTitle.Clear();
            txtPayable.ResetText();
            txtPaid.ResetText();
            txtDetails.Clear();
            txtComments.Clear();
            lblDue.Text = "0.00";
        }
        void getDailyCostCal()
        {
            string sql = @"SELECT *From Daily_Expenditure_Debit";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;
            dataGridView1.Columns["isPaid"].Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            long id = Convert.ToInt64(dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString());
            if (e.ColumnIndex == 9)
            {
                string title = dataGridView1.Rows[e.RowIndex].Cells["Title"].Value.ToString();
                DialogResult dr = MessageBox.Show("Are You Sure You Want To Delete " + Environment.NewLine
                            + title + "'s Informations", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr.ToString() == "Yes")
                {
                    string sql = "DELETE FROM Daily_Expenditure_Debit WHERE ID = " + id + "";
                    if (CUD(sql).IsSuccess)
                    {
                        getDailyCostCal();
                        lblMessage.Text = Program.DeleteSuccessMessage;
                        lblMessage.ForeColor = Color.Green;
                    }
                    else
                    {
                        lblMessage.Text = "Data couldn't be delete!";
                        lblMessage.ForeColor = Color.Red;
                    }
                }
            }
        }  
        private void btnPrint_Click(object sender, EventArgs e)
        {
            string date = dtpSearch.Value.ToShortDateString();
            PrintDailyExpend pd = new PrintDailyExpend(date);
            pd.ShowDialog();
        }
    }
}
