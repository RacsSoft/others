﻿using System;
using Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class Buyer : Common
    {
        public Buyer()
        {
            InitializeComponent();
        }

        private void Buyer_Load(object sender, EventArgs e)
        {
            getOwners();
            lblMessage.Text = "";
            editButton();
            DeleteButton();
            dataGridView1.AutoGenerateColumns = false;
        }
        void getOwners()
        {
            string sql = @"SELECT ID,OwnerName AS[Owner],PresentAddress AS[Present Address],PermanentAddress AS[Permanent Address],NID,Email,Contact1,Contact2,Contact3,Comment  FROM Owners";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;
            dataGridView1.Refresh();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if(btnSave.Text == "Save")
                {
                    if (txtOName.Text != "" && txtPAddress.Text != "" && txtPrAddress.Text != "" && txtNid.Text != "" && txtEmail.Text != "" && txtC1.Text != "")
                    {
                        string sql = @"INSERT INTO Owners(OwnerName,PresentAddress,PermanentAddress,NID,Email,Contact1,Contact2,Contact3,Comment) VALUES('" + txtOName.Text.Trim() + "','" + txtPAddress.Text.Trim() + "','" + txtPrAddress.Text.Trim() + "','" + txtNid.Text.Trim() + "','" + txtEmail.Text.Trim() + "','" + txtC1.Text.Trim() + "','" + txtC2.Text.Trim() + "','" + txtC3.Text.Trim() + "','" + rTxComment.Text.Trim() + "')";
                        CUD(sql);
                        lblMessage.Text = Program.InsertSuccessMessage;
                        lblMessage.ForeColor = Color.Green;
                        getOwners();
                        clear();
                    }
                    else
                    {
                        lblMessage.Text = Program.WrongMessage;
                        lblMessage.ForeColor = Color.Red;
                    }
                }
                if(btnSave.Text == "Update")
                {
                    UpdateOwnerDetails();
                }
                
            }
            catch(Exception ex)
            {
                ex.ToString();
            }
        }
        void UpdateOwnerDetails()
        {
            int id = Convert.ToInt32(hiddenTextBox.Text.Trim());
            string sql = @"UPDATE Owners SET OwnerName = '" + txtOName.Text.Trim() + "', PresentAddress = '"+txtPAddress.Text.Trim()+"', PermanentAddress = '"+txtPrAddress.Text.Trim()+"', NID = '"+txtNid.Text.Trim()+"', Email='"+txtEmail.Text.Trim()+"', Contact1 = '"+txtC1.Text.Trim()+"',Contact2 = '"+txtC2.Text.Trim()+"',Contact3 = '"+txtC3.Text.Trim()+"',Comment='"+rTxComment.Text.Trim()+"' WHERE ID = "+id+"";
            CUD(sql);
            lblMessage.Text = Program.UpdateSuccessMessage;
            lblMessage.ForeColor = Color.Green;
            getOwners();
            btnSave.Text = "Save";
            clear();
        }
        void clear()
        {
            txtC1.Clear();
            txtC2.Clear();
            txtC3.Clear();
            txtEmail.Clear();
            txtNid.Clear();
            txtOName.Clear();
            txtPAddress.Clear();
            txtPrAddress.Clear();
            rTxComment.Clear();
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"SELECT *From Owners  WHERE OwnerName LIKE '%" + txtSearch.Text + "%' OR PresentAddress LIKE '%" + txtSearch.Text + "%' OR PermanentAddress LIKE '%" + txtSearch.Text + "%' OR NID LIKE '%" + txtSearch.Text + "%' OR Email LIKE '%" + txtSearch.Text + "%' OR Contact1 LIKE '%" + txtSearch.Text + "%'";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;
        }
        void DeleteButton()
        {
            DataGridViewButtonColumn DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.UseColumnTextForButtonValue = true;
            DeleteButton.HeaderText = "Delete";
            DeleteButton.DataPropertyName = "lnkColumn";
            //DeleteButton.LinkBehavior = LinkBehavior.SystemDefault;
            DeleteButton.Text = "Delete";
            DeleteButton.FlatStyle = FlatStyle.Flat;
            DeleteButton.DefaultCellStyle.ForeColor = Color.White;
            DeleteButton.DefaultCellStyle.BackColor = Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridView1.Columns.Add(DeleteButton);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                long id = Convert.ToInt64(dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString());
                if(e.ColumnIndex == 10)
                {
                    hiddenTextBox.Text = dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString();
                    txtOName.Text = dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString();
                    txtPAddress.Text = dataGridView1.Rows[e.RowIndex].Cells["Present Address"].Value.ToString();
                    txtPrAddress.Text = dataGridView1.Rows[e.RowIndex].Cells["Permanent Address"].Value.ToString();
                    txtNid.Text = dataGridView1.Rows[e.RowIndex].Cells["NID"].Value.ToString();
                    txtEmail.Text = dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
                    txtC1.Text = dataGridView1.Rows[e.RowIndex].Cells["Contact1"].Value.ToString();
                    txtC2.Text = dataGridView1.Rows[e.RowIndex].Cells["Contact2"].Value.ToString();
                    txtC3.Text = dataGridView1.Rows[e.RowIndex].Cells["Contact3"].Value.ToString();
                    rTxComment.Text = dataGridView1.Rows[e.RowIndex].Cells["Comment"].Value.ToString();
                    btnSave.Text = "Update";
                }
                if (e.ColumnIndex == 11)
                {
                    string OwnerName = dataGridView1.Rows[e.RowIndex].Cells["Owner"].Value.ToString();
                    DialogResult dr = MessageBox.Show("Are You Sure You Want To Delete " + Environment.NewLine
                                + OwnerName + "'s Informations", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr.ToString() == "Yes")
                    {
                        string sql = "DELETE FROM Owners WHERE ID = " + id + "";
                        if (CUD(sql).IsSuccess)
                        {
                            getOwners();
                            lblMessage.Text = Program.DeleteSuccessMessage;
                            lblMessage.ForeColor = Color.Green;
                            dataGridView1.Refresh();
                        }
                        else
                        {
                            lblMessage.Text = "Data couldn't be delete!";
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                ex.ToString();
            }
            
        }
        void editButton()
        {
            DataGridViewButtonColumn EditButton = new DataGridViewButtonColumn();
            EditButton.UseColumnTextForButtonValue = true;
            EditButton.HeaderText = "Edit";
            EditButton.DataPropertyName = "lnkColumn";
            //EditButton.LinkBehavior = LinkBehavior.SystemDefault;
            EditButton.Text = "Edit";
            EditButton.FlatStyle = FlatStyle.Flat;
            EditButton.DefaultCellStyle.ForeColor = Color.White;
            EditButton.DefaultCellStyle.BackColor = Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(102)))), ((int)(((byte)(153)))));
            dataGridView1.Columns.Add(EditButton);
        }
    }
}
