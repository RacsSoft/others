﻿using System;
using Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Racssoft_Housing.Pages
{
    public partial class Bill_Collection : Common
    {
        static string path = Environment.CurrentDirectory;
        static string databasePath = @"\DB\RacssoftHousingDB.accdb;";
        static string tPath = path + databasePath;
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + tPath);
        
        string sql;
        public Bill_Collection()
        {
            InitializeComponent();
        }

        private void Monthly_Collection_Load(object sender, EventArgs e)
        {
            getInvoiceId();
            cmbBankCash.SelectedIndex = 0;
            cmbInvId.ResetText();
            getBillCollection();
            DeleteButton();
            lblMessage.Text = "";
            printButton();
            dataGridView1.AutoGenerateColumns = false;
            getOpeningBalance();
            numPayable.ReadOnly = true;
            numPayable.Increment = 0;
            //LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label4.ForeColor = ThemeColor.PrimaryColor;
            label5.ForeColor = ThemeColor.PrimaryColor;
            label6.ForeColor = ThemeColor.PrimaryColor;
            label7.ForeColor = ThemeColor.PrimaryColor;
            label8.ForeColor = ThemeColor.PrimaryColor;
            


            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = ThemeColor.SecondaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.Gainsboro;
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;

        }
        void printButton()
        {
            DataGridViewButtonColumn print = new DataGridViewButtonColumn();
            //Deletelink.UseColumnTextForLinkValue = true;
            print.HeaderText = "Print";
            print.Text = "Print";
            print.UseColumnTextForButtonValue = true;
            print.FlatStyle = FlatStyle.Flat;
            print.DefaultCellStyle.ForeColor = Color.White;
            print.DefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            print.DefaultCellStyle.SelectionBackColor = ThemeColor.SecondaryColor;
            print.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.Columns.Add(print);
        }
        void getInvoiceId()
        {
			try
			{
                string sql = @"SELECT ID, InvoiceNo From Invoice";
                DataTable dt = (DataTable)Select(sql).Data;
                cmbInvId.DataSource = dt;
                cmbInvId.DisplayMember = "InvoiceNo";
                cmbInvId.ValueMember = "ID";
                cmbInvId.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                cmbInvId.AutoCompleteSource = AutoCompleteSource.ListItems;
            }
			catch (Exception ex)
			{
                ex.ToString();
                throw;
			}
        }
        private void cmbInvId_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                long data = Convert.ToInt64(cmbInvId.SelectedValue);
                string sql = @"SELECT i.ID,i.FlatID,i.Total,i.MonthName,f.Title From Invoice i LEFT JOIN One_Building_Flats f ON i.FlatID=f.ID WHERE i.ID ="+data+"";
                DataTable dt = (DataTable)Select(sql).Data;
                if (dt != null && dt.Rows.Count > 0)
                {
                    numPayable.Value = Convert.ToDecimal(dt.Rows[0]["Total"].ToString());
                    textBox2.Text = dt.Rows[0]["Title"].ToString();
                    txtMonth.Text = dt.Rows[0]["MonthName"].ToString();
                }
            }
            catch(Exception ex)
            {
                ex.ToString();
            }  
        }
        

        private void numPayed_ValueChanged(object sender, EventArgs e)
        {
            if(numPayable.Value >= numPayed.Value)
            {
                numDue.Value = numPayable.Value - numPayed.Value;
            }
            else
            {
                lblMessage.Text = "Due Minimum Value 0!";
                lblMessage.ForeColor = Color.Red;
            }
        }
        
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (btnSave.Text == "Save")
            {
                try
                {
                    con.Open();
                    string time = DateTime.Now.ToString();
                    string getInvoice = @"SELECT COUNT (*) FROM Bill_Collection Where InvoiceID = '" + cmbInvId.Text + "'";
                    OleDbCommand cmd = new OleDbCommand(getInvoice, con);
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();
                    if (txtOther.Text != "")
                    {
                        string sql1 = @"INSERT INTO Bill_Collection(OtherCollection,PaidAmmount,PaidDate) VALUES('" + txtOther.Text.Trim() + "','" + numProfit.Value + "','" + time + "')";
                        CUD(sql1);
                        double totals = Convert.ToDouble(numProfit.Value + txtCashBalance.Value);
                        string collectionSql = @"UPDATE Opening_Balance SET CashAmmount = '" + totals + "'";
                        CUD(collectionSql);
                        getOpeningBalance();
                        lblMessage.Text = "Insert Success ! Collection Add to Cash";
                        lblMessage.ForeColor = Color.Green;
                    }
                    else
                    {
                        if (count > 0)
                        {
                            lblMessage.Text = "This Invoice Allready Exist";
                            lblMessage.ForeColor = Color.Red;
                        }
                        else
                        {
                            if (numPayed.Value != 0)
                            {
                                string sql = @"INSERT INTO Bill_Collection(InvoiceID,ApartmentName,PaidAmmount,DueAmmount,PaidDate,BankOrCash,MonthName) VALUES('" + cmbInvId.Text + "','" + textBox2.Text.Trim() + "','" + numPayed.Value + "','" + numDue.Value + "','" + time + "','" + cmbBankCash.Text + "','" + txtMonth.Text.Trim() + "')";
                                CUD(sql);

                                //Collection add to opening Blance start
                                if (cmbBankCash.Text == "Bank")
                                {
                                    double totals = Convert.ToDouble(numPayed.Value + txtBankBalance.Value);
                                    string collectionSql = @"UPDATE Opening_Balance SET BankAmmount = '" + totals + "'";
                                    CUD(collectionSql);
                                    getOpeningBalance();
                                    lblMessage.Text = "Insert Success ! Collection Add to Bank";
                                    lblMessage.ForeColor = Color.Green;
                                }
                                else
                                {
                                    double totals = Convert.ToDouble(numPayed.Value + txtCashBalance.Value);
                                    string collectionSql = @"UPDATE Opening_Balance SET CashAmmount = '" + totals + "'";
                                    CUD(collectionSql);
                                    getOpeningBalance();
                                    lblMessage.Text = "Insert Success ! Collection Add to Cash";
                                    lblMessage.ForeColor = Color.Green;
                                }
                            }
                            else
                            {
                                lblMessage.Text = "Please Fill Payed Field!";
                                lblMessage.ForeColor = Color.Red;
                            }
                        }
                    }                       
                    getBillCollection();
                    clear();
                }
                catch (Exception ex)
                {
                    ex.ToString();
                    lblMessage.Text = Program.WrongMessage;
                    lblMessage.ForeColor = Color.Red;
                }
            }
        }
        void getOpeningBalance()
        {
            string sql = @"SELECT *FROM Opening_Balance";
            DataTable dt = (DataTable)Select(sql).Data;
            if(dt != null && dt.Rows.Count > 0)
            {
                txtBankBalance.Text = dt.Rows[0]["BankAmmount"].ToString();
                txtCashBalance.Text = dt.Rows[0]["CashAmmount"].ToString();
            }
        }
        
        void getBillCollection()
        {
            string sql = @"SELECT ID, InvoiceID AS[Invoice], ApartmentName AS[Apartment],OtherCollection AS[Other Collection],PaidAmmount AS[Payed],DueAmmount AS[Due],PaidDate AS[Pay Date],BankOrCash AS[Bank/Cash],MonthName AS[Month]  FROM Bill_Collection";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;
        }
        void clear()
        {
            txtOther.Clear();
            numProfit.Value = 0;
            numPayable.Value = 0;
            numDue.Value = 0;
            numPayed.Value = 0;
            cmbBankCash.ResetText();
            cmbInvId.ResetText();
            groupBox2.Enabled = true;
            groupBox3.Enabled = true;
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            clear();
            lblMessage.Text = "";
        }
        void DeleteButton()
        {
            DataGridViewButtonColumn DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.UseColumnTextForButtonValue = true;
            DeleteButton.HeaderText = "Delete";
            DeleteButton.DataPropertyName = "lnkColumn";
            //DeleteButton.LinkBehavior = LinkBehavior.SystemDefault;
            DeleteButton.Text = "Delete";
            DeleteButton.Name = "Delete";
            DeleteButton.FlatStyle = FlatStyle.Flat;
            DeleteButton.DefaultCellStyle.ForeColor = Color.White;
            DeleteButton.DefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            DeleteButton.DefaultCellStyle.SelectionBackColor = ThemeColor.SecondaryColor;
            DeleteButton.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.Columns.Add(DeleteButton);
        }

        private void groupBox3_MouseHover(object sender, EventArgs e)
        {
            groupBox2.Enabled = false;
        }

        private void groupBox2_MouseHover(object sender, EventArgs e)
        {
            groupBox3.Enabled = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            long id = Convert.ToInt64(dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString());
            if (e.ColumnIndex == 9)
            {
                string invoice = dataGridView1.Rows[e.RowIndex].Cells["Invoice"].Value.ToString();
                DialogResult dr = MessageBox.Show("Are You Sure You Want To Delete " + Environment.NewLine
                            + invoice + "'s Informations", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr.ToString() == "Yes")
                {
                    string sql = "DELETE FROM Bill_Collection WHERE ID = " + id + "";
                    if (CUD(sql).IsSuccess)
                    {
                        getBillCollection();
                        lblMessage.Text = Program.DeleteSuccessMessage;
                        lblMessage.ForeColor = Color.Green;
                    }
                    else
                    {
                        lblMessage.Text = "Data couldn't be delete!";
                    }
                }
            }
            if (e.ColumnIndex == 10)
            {
                //get every column value here
                string invoice = dataGridView1.Rows[e.RowIndex].Cells["Invoice"].Value.ToString();
                string month = dataGridView1.Rows[e.RowIndex].Cells["Month"].Value.ToString();
                string apartment = dataGridView1.Rows[e.RowIndex].Cells["Apartment"].Value.ToString();
                string payed = dataGridView1.Rows[e.RowIndex].Cells["Payed"].Value.ToString();
                string due = dataGridView1.Rows[e.RowIndex].Cells["Due"].Value.ToString();
                string payDate = dataGridView1.Rows[e.RowIndex].Cells["Pay Date"].Value.ToString();
                string bankOrCash = dataGridView1.Rows[e.RowIndex].Cells["Bank/Cash"].Value.ToString();

                PrintBillRecipt frm = new PrintBillRecipt(invoice,month,apartment,payed,due,payDate,bankOrCash);
                frm.ShowDialog();

            }
        }
        //numeric updown click
        private void numPayed_Click(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(TextBox))
                ((TextBox)sender).SelectAll();
            else if (sender.GetType() == typeof(NumericUpDown))
            {
                NumericUpDown numeric = (NumericUpDown)sender;
                (numeric).Select(0, numeric.Value.ToString().Length + 3);
            }
            else
            {
                ((RichTextBox)sender).SelectAll();
            }
        }
        //search
        //private void txtSearch_TextChanged(object sender, EventArgs e)
        //{
        //    string sql = @"SELECT *FROM Bill_Collection WHERE InvoiceID LIKE '%" + txtSearch.Text + "%' OR ApartmentName LIKE '%" + txtSearch.Text + "%' OR MonthName LIKE '%" + txtSearch.Text + "%'";
        //    DataTable dt = (DataTable)Select(sql).Data;
        //    dataGridView1.DataSource = dt;
        //    dataGridView1.Columns["ID"].Visible = false;
        //}
    }
}
