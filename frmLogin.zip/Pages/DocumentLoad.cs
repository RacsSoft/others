﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;

namespace Racssoft_Housing.Pages
{
    public partial class DocumentLoad : Common
    {
        private byte[] bytes;
        public DocumentLoad(byte[] bytess)
        {
            InitializeComponent();
            bytes = bytess;
            showImage();
        }
        private void showImage()
        {
            MemoryStream memStream = new MemoryStream(bytes);
            try
            {
                Bitmap myImage = new Bitmap(memStream);
                pictureBox1.Image = myImage;
                pictureBox1.Size = new Size(614,555);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                pictureBox1.Image = null;
            }
        }
    }
}
