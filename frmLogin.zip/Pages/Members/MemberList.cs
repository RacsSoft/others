﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class MemberList : Common
    {
        public MemberList()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sql = @"INSERT INTO Committee_Members(MemberName, PresentAddress, PermanentAddress,
NID, Email, Contact1, Contact2, Contact3, Comment, CH_ID) VALUES('" + txtName.Text + "', '" +
txtPresent.Text + "', '" + txtPermanent.Text + "', '" + txtNID.Text + "', '"
+ txtEmail.Text + "', '" + txtContact1.Text + "', '" + txtContact2.Text + "', '"
+ txtContact3.Text + "', '" + txtComment.Text + "', " + cmbHierarchy.SelectedValue + ")";
            CUD(sql);
        }

        private void MemberList_Load(object sender, EventArgs e)
        {
            string sql = @"SELECT * From Committee_Hierarchy";
            DataTable dt = (DataTable)Select(sql).Data;
            if (dt != null)
            {
                cmbHierarchy.DataSource = dt;
                cmbHierarchy.SelectedIndex = 0;

                cmbHierarchy.DisplayMember = "Title";
                cmbHierarchy.ValueMember = "ID";
            }
        }
    }
}
