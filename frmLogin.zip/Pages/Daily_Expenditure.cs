﻿using Model;
using Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class Daily_Expenditure : Common
    {

        List<ItemGrid> allProduct;
        List<string> productName;
        long productId;
        List<long> productIds;
        Dictionary<int, string> names;
        Dictionary<int, string> utilityType;
        Dictionary<int, string> flat;
        Dictionary<int, string> building;
        Dictionary<int, string> area;
        Dictionary<int, string> road;
        Dictionary<int, string> expenditureType;  // DB Spend_Time
        Dictionary<int, string> address;
        int spend_EnrollmentId;
        bool isClickedOnEdit = false;

        public Daily_Expenditure()
        {
            InitializeComponent();
            Initialize();
        }

        void Initialize()
        {



            int sessionId = Convert.ToInt32(Program.SessionID);
            comboboxGenerator();


            getItems();
            //GrandTotalinLastRowofGridview();
            //MessageBox.Show(address[5]);
            //dataGridView1.ColumnCount = 4;
            //dataGridView1.Columns[0].Name = "Name";
            //dgItems.Columns[0].Visible = false;
            //dataGridView1.Columns[1].Name = "Area of Expenditure";
            //dataGridView1.Columns[2].Name = "Expense";
            //dataGridView1.Columns[3].Name = "Date";
        }

        private void comboboxGenerator()
        {

            //string sql = "Select FullName FROM tblUsers WHERE ID = " +sessionId+ "";
            //lvl.Text = Program.SessionName;
            //names = getComboList("Select ID, FullName FROM tblUsers");
            //cmbName.Items.AddRange(names.Select(s => s.Value).ToArray());

            string sql = @"SELECT c.ID, f.Title, b.Title, r.Title, a.Title FROM ((((Address c LEFT JOIN Flats f ON c.Flat_ID = f.ID) 
            LEFT JOIN Building b ON c.Building_ID = b.ID) LEFT JOIN Roads r ON c.Road_ID = r.ID) 
            LEFT JOIN Areas a ON c.Area_ID = a.ID)";
            DataTable dt = (DataTable)Select(sql).Data;



            address = getAddressList(sql);
            //flat = getComboList(address);
            cmbAddress.Items.AddRange(address.Select(s => s.Value).ToArray());

            utilityType = getComboList("Select * FROM Spend_Area_Type");
            cmbUtilityType.Items.AddRange(utilityType.Select(s => s.Value).ToArray());
            
            expenditureType = getComboList("Select * FROM Spend_Time"); // expenditure time daily or monthly
            cmbExpenditureType.Items.AddRange(expenditureType.Select(s => s.Value).ToArray());
            //flat = getComboList("Select ID, Title FROM Flats");
            //cmbFlat.Items.AddRange(flat.Select(s => s.Value).ToArray());
            //building = getComboList("Select ID, Title FROM Building");
            //cmbBuilding.Items.AddRange(building.Select(s => s.Value).ToArray());
            //area = getComboList("Select ID, Title FROM Areas");
            //cmbArea.Items.AddRange(area.Select(s => s.Value).ToArray());
            //road = getComboList("Select ID, Title FROM Roads");
            //cmbRoad.Items.AddRange(road.Select(s => s.Value).ToArray());
            //billType = getComboList("Select ID, Title FROM Spend_Time");
            //cmbBillType.Items.AddRange(billType.Select(s => s.Value).ToArray());
            //address = getComboList("Select ID, Flat_ID FROM Address");
            //cmbUtilityType.Items.AddRange(utilityType.Select(s => s.Value).ToArray());
        }

        //public void combosFlat(string str)
        //{
        //    string sql = @"SELECT Flat_ID FROM Address";
        //    DataTable dt = (DataTable)Select(sql).Data;
        //    foreach (DataRow row in dt.Rows)
        //    {
        //        string id = row["Flat_ID"].ToString();
        //        string sql1 = @"SELECT Title From Flats";
        //        DataTable dt1 = (DataTable)Select(sql1).Data;
        //        foreach (DataRow dr in dt1.Rows)
        //        {
        //            comboFlat.Items.Add(dr["Title"]).ToString();
        //        }
        //        //comboFlat.Items.Add(row["Flat_ID"]).ToString();
        //    }

        //}

        Dictionary<int, string> getAddressList(string sql)
        {
            DataTable dt = (DataTable)Select(sql).Data;
            return dt.AsEnumerable()
      .ToDictionary<DataRow, int, string>(row => row.Field<int>(0),
                                row => row.Field<string>(1) + ", " + row.Field<string>(2) + ", " + row.Field<string>(3) + ", " + row.Field<string>(4));
        }


        Dictionary<int, string> getComboList(string sql)
        {
            //string sql = "Select ID, FullName FROM tblUsers";
            DataTable dt = (DataTable)Select(sql).Data;
            return dt.AsEnumerable()
      .ToDictionary<DataRow, int, string>(row => row.Field<int>(0),
                                row => row.Field<string>(1));
            //Dictionary<int, string> units = new Dictionary<int, string>();
            //foreach(DataRow r in dt.Rows)
            //         {

            //         }

        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            isClickedOnEdit = false;
            //int nameId = Convert.ToInt16(names.ElementAt(cmbName.SelectedIndex).Key);
            if (cmbUtilityType.SelectedIndex > -1 && cmbAddress.SelectedIndex > -1)
            {
                int nameId = Convert.ToInt32(Program.SessionID);
                //int utilityTypeId = Convert.ToInt16(utilityType.ElementAt(cmbUtilityType.SelectedIndex).Key);
                int spendAreaId = Convert.ToInt16(utilityType.ElementAt(cmbUtilityType.SelectedIndex).Key);
                int expenditureTypeId = Convert.ToInt16(expenditureType.ElementAt(cmbExpenditureType.SelectedIndex).Key); //DB Spend_Time
                int addressId = Convert.ToInt16(address.ElementAt(cmbAddress.SelectedIndex).Key);
                double cost = Convert.ToDouble(txtCost.Value), monthlyCost = 0;
                //DateTime paidDate = DateTime.Parse(PaidDate.Text);
                DateTime paidDate = PaidDate.Value;
                if (paidDate > DateTime.Now) MessageBox.Show("Paid date can not be a future date!!!");
                else
                {
                    //IF (RADIOBTNDAILY.CHECKED == TRUE)
                    //{
                    //    DAILYCOST = CONVERT.TODOUBLE(TXTCOST.VALUE);
                    //    MONTHLYCOST = 0;
                    //
                    //}
                    //ELSE IF(RADIOBTNMONTHLY.CHECKED == TRUE)
                    //{
                    //   MONTHLYCOST = CONVERT.TODOUBLE(TXTCOST.VALUE);
                    //    DAILYCOST = 0;
                    //}
                    //bool isEarned = Convert.ToBoolean(IsEarned.Checked);
                    //bool isPaid = Convert.ToBoolean(IsPaid.Checked);
                    double duplicateCost = Convert.ToDouble(txtDuplicatedCost.Value);


                    string sql = null;
                    //   sql = btn.Name == "btnSubmit" ?
                    //       @"INSERT INTO Spend_Enrollment(AddressID, EntryBy, SpendAreaID, Cost, DuplicateCost, CreatedDate, IsPaid, IsEarned, SpendTimeID, UserID) values(" + addressId + ", " + nameId + ", " + spendAreaId + ", " + cost + ", " + duplicateCost + ", '" + DateTime.Now + "' , " + false + ", " + false + ", '1', '1')"
                    //   :   @"INSERT INTO Spend_Enrollment(AddressID, EntryBy, SpendAreaID, Cost, DuplicateCost, CreatedDate, PaidDate, IsPaid, IsEarned, SpendTimeID, UserID) values(" + addressId + ", " + nameId + ", " + spendAreaId + ", " + cost + ", " + duplicateCost + ", '" + DateTime.Now + "', '" + paidDate + "', " + true + ", " + false + ", '1', '1')";


                    string s = btn.Text;
                    if (btn.Text == "ADD")
                    {
                        sql = @"INSERT INTO Spend_Enrollment(AddressID, EntryBy, SpendAreaID, Cost, DuplicateCost, CreatedDate, IsPaid, IsEarned, SpendTimeID, UserID) values(" + addressId + ", " + nameId + ", " + spendAreaId + ", " + cost + ", " + duplicateCost + ", '" + DateTime.Now + "' , " + false + ", " + false + ", "+expenditureTypeId+", '1')";
                    }
                    else if (btn.Text == "PAID && ADD")
                    {
                        sql = @"INSERT INTO Spend_Enrollment(AddressID, EntryBy, SpendAreaID, Cost, DuplicateCost, CreatedDate, PaidDate, IsPaid, IsEarned, SpendTimeID, UserID) values(" + addressId + ", " + nameId + ", " + spendAreaId + ", " + cost + ", " + duplicateCost + ", '" + DateTime.Now + "', '" + paidDate + "', " + true + ", " + false + ", "+expenditureTypeId+", '1')";
                    }

                    else if (btn.Text == "EDIT")
                    {
                        sql = @"UPDATE Spend_Enrollment SET AddressID = " + addressId + ", EntryBy = " + nameId + ", SpendAreaID = " + spendAreaId + ", Cost = " + cost + ", DuplicateCost = " + duplicateCost + ", spendTimeID = "+expenditureTypeId+", IsPaid = "+checkboxPaid.Checked+ ", PaidDate = NULL WHERE ID = " + spend_EnrollmentId + "";
                    }

                    else if (btn.Text == "PAID && EDIT") {
                        sql = @"UPDATE Spend_Enrollment SET AddressID = " + addressId + ", EntryBy = " + nameId + ", SpendAreaID = " + spendAreaId + ", Cost = " + cost + ", DuplicateCost = " + duplicateCost + ", spendTimeID = " + expenditureTypeId + ", PaidDate = '" + paidDate + "', IsPaid = " + checkboxPaid.Checked + " WHERE ID = " + spend_EnrollmentId + "";
                    }

                    //else if(btn.Text == "")
                    
                    CUD(sql);

                    getItems();

                    btnReset_Click(s, e);



                }
            }
            else MessageBox.Show("Insert all the fields");

            //getItems();




            //string[] row = { name, details, expense.tostring(), dt.tostring() };

            //dgitems.rows.add(row);
            //dgitems.columns[0].displayindex = 1;
        }

        void getItems()
        {
            //bool flag = false;
            //Connection con = new Connection();
            string sql = @"SELECT f.ID, f.AddressID as [Address], l.Title as [Flat No], u.Title as [Utility Type], n.Title as [Expense Type], f.IsPaid as [Paid?], f.CreatedDate as [Date], f.PaidDate as [Paid Date], f.Cost FROM ((((Spend_Enrollment f LEFT JOIN Spend_Area_Type u ON f.SpendAreaID = u.ID) LEFT JOIN Spend_Time n ON f.SpendTimeID = n.ID) LEFT JOIN Address a ON f.AddressID = a.ID) Left JOIN Flats l ON a.Flat_ID = l.ID)";
            //string sql1 = @"SELECT e.ID, e.AddressID as [Address], u.Title as [Utility Type], f.Title, e.IsPaid as [Paid?], e.CreatedDate as [Date], e.PaidDate as [Paid Date], e.Cost
            //FROM Spend_Enrollment e FULL OUTER JOIN Spend_Area_Type u ON e.SpendAreaID = u.ID
            //FULL OUTER JOIN Address c ON e.AddressID = c.ID
            //FULL OUTER JOIN Flats f ON c.Flat_ID = f.ID 
            //FULL OUTER JOIN Building b ON c.Building_ID = b.ID
            //FULL OUTER JOIN Roads r ON c.Road_ID = r.ID 
            //FULL OUTER JOIN Areas a ON c.Area_ID = a.ID ";

            //string sql1 = @"SELECT * from Address WHERE Title = " + 
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            GrandTotalinLastRowofGridview();


            //dataGridView1.AutoGenerateColumns = false;
            //dataGridView1.Columns[0].Visible = false;
            //dataGridView1.Columns[1].Visible = false;
            //dataGridView1.Columns.Add() = address;
            //dataGridView1.Refresh();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void Daily_Expenditure_Load(object sender, EventArgs e)
        {
            getItems();

            DataGridViewLinkColumn Editlink = new DataGridViewLinkColumn();
            Editlink.UseColumnTextForLinkValue = true;
            Editlink.HeaderText = "Edit";
            Editlink.DataPropertyName = "lnkColumn";
            Editlink.LinkBehavior = LinkBehavior.SystemDefault;
            Editlink.Text = "Edit";
            dataGridView1.Columns.Add(Editlink);

            DataGridViewLinkColumn Deletelink = new DataGridViewLinkColumn();
            Deletelink.UseColumnTextForLinkValue = true;
            Deletelink.HeaderText = "Delete";
            Deletelink.DataPropertyName = "lnkColumn";
            Deletelink.LinkBehavior = LinkBehavior.SystemDefault;
            Deletelink.Text = "Delete";
            dataGridView1.Columns.Add(Deletelink);
        }
    

        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 9)
                {
                    isClickedOnEdit = true;
                    btnSubmit.Text = checkboxPaid.Checked ? "PAID && EDIT" : "EDIT";
                    //btnEdit.Visible = true;
                    //btnSubmit.Visible = false;
                    //btnPayAdd.Visible = false;
                    //long id = Convert.ToInt64(dgItems.Rows[e.RowIndex].Cells[0].Value.ToString());
                    //string address = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                    //string code = dgItems.Rows[e.RowIndex].Cells[2].Value.ToString();
                    //int totalBuyingQuantity = Convert.ToInt32(dgItems.Rows[e.RowIndex].Cells[3].Value);
                    bool cbChecked = Convert.ToBoolean(dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString());
                    double cost = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells[8].Value);
                    txtCost.Text = cost.ToString();

                    spend_EnrollmentId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);

                    string utilityType1 = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
                    var itemKey = 0;
                    for (int i = utilityType.Count - 1; i >= 0; i--)
                    {
                        var item = utilityType.ElementAt(i);
                        if (item.Value == utilityType1)
                        {
                            itemKey = item.Key;
                        }
                        //var itemValue = item.Value;
                    }

                    string expenditureType1 = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[4].Value);
                    var itemKey1 = 0;
                    for (int i = expenditureType.Count - 1; i >= 0; i--)
                    {
                        var item = expenditureType.ElementAt(i);
                        if (item.Value == expenditureType1)
                        {
                            itemKey1 = item.Key;
                        }
                        //var itemValue = item.Value;
                    }
                    int addressId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString());
                    int addressIndex = address.Keys.ToList().IndexOf(addressId);
                    int utilityIndex = utilityType.Keys.ToList().IndexOf(itemKey);
                    int expenditureIndex = expenditureType.Keys.ToList().IndexOf(itemKey1);
                    //DateTime dateTime = dataGridView1.Rows[e.RowIndex].Cells[5].Value.);
                    cmbAddress.SelectedIndex = addressIndex;
                    cmbUtilityType.SelectedIndex = utilityIndex;
                    cmbExpenditureType.SelectedIndex = expenditureIndex;
                    checkboxPaid.Checked = cbChecked;

                    PaidDate.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString());
                    

                    //int sellingPrice = Convert.ToInt32(dgItems.Rows[e.RowIndex].Cells[5].Value);

                    //txtCode.Text = code;
                    //txtName.Text = name;
                    //txtPrice.Text = price.ToString();
                    //txtDiscount.Text = "0.00";
                    //txtSellPrice.Text = sellingPrice.ToString();
                    //txtQuantity.Text = totalBuyingQuantity.ToString();



                    //this.ActiveControl = txtName;
                    //hideResults();





                }
                else if (e.ColumnIndex == 10)
                {
                    long id = Convert.ToInt64(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                    //string utilityType = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                    DialogResult dr = MessageBox.Show("Are You Sure You Want To Delete " + Environment.NewLine
                        + id + "'s Informations", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr.ToString() == "Yes")
                    {
                        string sql = "DELETE FROM Spend_Enrollment WHERE Id = " + id;
                        //string sql1 = "DELETE FROM ProductDetails WHERE ProductId = " + id;
                        //bool flag = false;
                        if (CUD(sql).IsSuccess)
                        {
                            //sql = "DELETE FROM DoctorDetails WHERE DoctorId = " + id;
                            //if (crud.Delete(sql))
                            //{
                            //	flag = true;
                            //}
                            getItems();
                        }
                        else
                        {
                            MessageBox.Show("Data couldn't be deleted!");
                        }
                    }
                }
            }
            
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            cmbUtilityType.SelectedIndex = -1;
            cmbAddress.SelectedIndex = -1;
            txtCost.Text = "0";
            txtDuplicatedCost.Text = "0";
            PaidDate.Value = DateTime.Now;
            checkboxPaid.Checked = false;

            btnSubmit.Text = "ADD";
            isClickedOnEdit = false;
        }

        private void btnPaidAdd_Click(object sender, EventArgs e)
        {
            btnSubmit_Click(sender, e);

        }

        private void checkboxPaid_CheckedChanged(object sender, EventArgs e)
        {
            if (isClickedOnEdit)
            {
                if (checkboxPaid.Checked)
                {
                    Pay.Enabled = true;
                    btnSubmit.Text = "PAID && EDIT";
                }
                else
                {
                    Pay.Enabled = false;
                    btnSubmit.Text = "EDIT";
                }
            }
            else
            {
                if (checkboxPaid.Checked && !isClickedOnEdit)
                {
                    Pay.Enabled = true;
                    btnSubmit.Text = "PAID && ADD";
                }
                else
                {
                    Pay.Enabled = false;
                    btnSubmit.Text = "ADD";
                }
            }
        }
        //Textbox myTxtbx = new Textbox();
        //myTxtbx.Text = "Enter text here...";

 
        public void RemoveText()
        {
             txtSearch.Text = "";
        }

        public void AddText(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
                txtSearch.Text = "Search";
        }


        public void GrandTotalinLastRowofGridview()
        {
            
            //dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[7].Style.BackColor = Color.White;
            //dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[7].Style.ForeColor = Color.Brown;

            decimal totaQty = 0;
            for(int a = 0; a < dataGridView1.Rows.Count  - 1; a++)
            {
                var valueQty = dataGridView1.Rows[a].Cells[8].Value.ToString();
                if(valueQty != DBNull.Value.ToString())
                {
                    totaQty += Convert.ToDecimal(valueQty);
                }
                //dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[8].Value = totaQty.ToString();
            }
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[7].Style.BackColor = Color.Gray;
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[7].Value = "Total";
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[8].Value = totaQty.ToString();
            //dataGridView1.Rows[0].Cells[8].Value = 2;
            //string ab = totaQty.ToString();
            //dataGridView1.Rows[e.RowIndex].Cells[0].Value
            ///MessageBox.Show(totaQty.ToString());

        } 


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string name = txtSearch.Text;

            if (name != "Search")
            {
                //string sql = @"SELECT p.Id, p.Name, p.ItemCode AS Code, TotalQuantity AS [Total Buying Quantity] , p.Price, d.SellingPrice, u.Title AS SellingUnit, n.Title AS BuyingUnit
                // FROM ((Products AS p LEFT JOIN ProductDetails AS d ON p.ID = d.ProductId) LEFT JOIN Units AS u ON d.UnitId = u.ID)  LEFT JOIN Units AS n ON p.UnitId = n.ID WHERE Name = '" + name + "'";

                string sql = @"SELECT e.ID, e.AddressID as [Address], f.Title as [Flat No], u.Title as [Utility Type], j.Title, e.IsPaid as [Paid?], e.CreatedDate as [Date], e.PaidDate as [Paid Date], e.Cost
            FROM (((((((Spend_Enrollment e LEFT JOIN Spend_Area_Type u ON e.SpendAreaID = u.ID) LEFT JOIN Address c ON e.AddressID = c.ID) LEFT JOIN Flats f ON c.Flat_ID = f.ID) 
            LEFT JOIN Building b ON c.Building_ID = b.ID) 
            LEFT JOIN Roads r ON c.Road_ID = r.ID) 
            LEFT JOIN Areas a ON c.Area_ID = a.ID)
            LEFT JOIN Spend_Time j ON e.SpendTimeID = j.ID) WHERE f.Title LIKE '%" + name + "%' OR u.Title LIKE '%" + name + "%' OR b.Title LIKE '%" + name + "%' OR r.Title LIKE '%" + name + "%' OR a.Title LIKE '%" + name + "%' OR j.Title LIKE '%" + name + "%'";
                //string sql = @"SELECT * from Address a INNER JOIN Flats f ON f.ID = a.Flat_ID WHERE f.Title LIKE '%" + name+ "%'";
                //string sql = 
                DataTable dt = (DataTable)Select(sql).Data;
                dataGridView1.DataSource = dt;
                //GrandTotalinLastRowofGridview();
                dataGridView1.AutoGenerateColumns = false;

                //dataGridView1.Columns[0].Visible = false;
                //dataGridView1.Columns[4].Visible = false;
                //dataGridView1.Refresh();
            }
        }

        private void cmbAddress_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        

        private void txtSearch_MouseEnter(object sender, EventArgs e)
        {
            if (txtSearch.Text == "Search")
            {
                txtSearch.Text = "";
            }
        }

        private void txtSearch_MouseLeave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "Search";
            }

        }
    }
}
