﻿using System;
using Model;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;

namespace Racssoft_Housing.Pages
{
    public partial class Print : Common
    {
        Dictionary<int, string> address;
        Dictionary<int, string> invoiceType;
        public Print()
        {
            InitializeComponent();
            combosAddress();
			combosInvoiceType();
        }
        private void Print_Load(object sender, EventArgs e)
        {
			
		}

        //Start PDF Generate
        public static Byte[] HtmlToBytes(string htmlText)
        {
            Byte[] bytes;

            using (var ms = new MemoryStream())
            {
                using (var doc = new Document(PageSize.A4, 10, 10, 10, 10))
                {
                    using (var writer = PdfWriter.GetInstance(doc, ms))
                    {
                        writer.CloseStream = false;
                        doc.Open();
                        using (var msHtml = new MemoryStream(Encoding.UTF8.GetBytes(htmlText)))
                        {
                            XMLWorkerHelper.GetInstance().ParseXHtml(writer, doc, msHtml, Encoding.UTF8);
                        }
                    }
                }
                bytes = ms.ToArray();
            }

            return bytes;
        }
        private void button1_Click(object sender, EventArgs e)
		{
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF (*.pdf)|*.pdf";
            sfd.FileName = "Output.pdf";
            bool fileError = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);
                    }
                    catch (IOException ex)
                    {
                        fileError = true;
                        MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                    }
                }
                if (!fileError)
                {
                    try
                    {
                        PdfPTable pdfTable = new PdfPTable(dataGridView1.Columns.Count);
                        pdfTable.DefaultCell.Padding = 3;
                        pdfTable.WidthPercentage = 100;
                        pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                        foreach (DataGridViewColumn column in dataGridView1.Columns)
                        {
                            PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));
                            //var a = cell.Column.;
                            if (column.HeaderText != "Edit" && column.HeaderText != "Delete")
                                pdfTable.AddCell(cell);
                        }

                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                if (cell.Value != null && cell.Value != "Edit" && cell.Value != "Delete")
                                    pdfTable.AddCell(cell.Value.ToString());
                            }
                        }

                        using (FileStream stream = new FileStream(sfd.FileName, FileMode.Create))
                        {
                            Document pdfDoc = new Document(PageSize.A4, 10f, 20f, 20f, 10f);
                            PdfWriter.GetInstance(pdfDoc, stream);
                            pdfDoc.Open();
                            pdfDoc.Add(pdfTable);
                            pdfDoc.Close();
                            stream.Close();
                        }

                        MessageBox.Show("Data Exported Successfully !!!", "Info");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error :" + ex.Message);
                    }
                }
            }
        }
		//End PDF Generate
        void combosAddress()
        {
            string sql = @"SELECT c.ID, f.Title, b.Title, r.Title, a.Title FROM ((((Address c LEFT JOIN Flats f ON c.Flat_ID = f.ID) 
            LEFT JOIN Building b ON c.Building_ID = b.ID) LEFT JOIN Roads r ON c.Road_ID = r.ID) 
            LEFT JOIN Areas a ON c.Area_ID = a.ID)";
            //DataTable dt = (DataTable)Select(sql).Data;

            address = getAddressList(sql);
            //flat = getComboList(address);
            comboAddress.Items.AddRange(address.Select(s => s.Value).ToArray());
        }
        void combosInvoiceType()
        {
            string sql = @"SELECT ID, Title FROM Spend_Time";
            //DataTable dt = (DataTable)Select(sql).Data;

            invoiceType = getInvoiceTypes(sql);
			comboInvoiceType.Items.AddRange(invoiceType.Select(s => s.Value).ToArray());
        }
        Dictionary<int, string> getAddressList(string sql)
        {
            DataTable dt = (DataTable)Select(sql).Data;
            return dt.AsEnumerable()
      .ToDictionary<DataRow, int, string>(row => row.Field<int>(0),
                                row => row.Field<string>(1) + ", " + row.Field<string>(2) + ", " + row.Field<string>(3) + ", " + row.Field<string>(4));
        }

        Dictionary<int, string> getInvoiceTypes(string sql)
        {
            DataTable dt = (DataTable)Select(sql).Data;
            return dt.AsEnumerable()
      .ToDictionary<DataRow, int, string>(row => row.Field<int>(0),
                                row => row.Field<string>(1));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(comboAddress.Text != "" && comboInvoiceType.Text != "")
            {
				int addressId = Convert.ToInt16(address.ElementAt(comboAddress.SelectedIndex).Key);
				int spendTimeId = Convert.ToInt16(invoiceType.ElementAt(comboInvoiceType.SelectedIndex).Key);
				DateTime date = DateTime.Parse(dateTimePicker1.Text);
				DateTime date2 = DateTime.Parse(dateTimePicker2.Text);
				string sql = @"SELECT s.ID, s.AddressID AS[Address ID], a.Title AS[Spend Area], s.Cost AS[Bill], s.IsPaid  FROM Spend_Enrollment s 
                    LEFT JOIN Spend_Area_Type a ON s.SpendAreaID = a.ID WHERE s.PaidDate 
                    BETWEEN #" + date.ToString("MM/dd/yyyy") + "# " +
						"AND #" + date2.ToString("MM/dd/yyyy") + "# AND s.AddressID=" + addressId + " AND s.SpendTimeID ="+ spendTimeId +"";
				//string sql = @"SELECT *From Spend_Enrollment WHERE AddressID = " + addressId + "";
				DataTable dt = (DataTable)Select(sql).Data;
				dataGridView1.DataSource = dt;
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
				comboAddress.ResetText();
			}
            else
            {
				MessageBox.Show("Please Select Address & Invoice Type");
            }
        }
    }
}
