﻿
namespace Racssoft_Housing.Pages
{
    partial class CashMaintain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRefresh = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nudCashToBank = new System.Windows.Forms.NumericUpDown();
            this.nudCExpend = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nudCAmmount = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nudBankToCash = new System.Windows.Forms.NumericUpDown();
            this.nudBExpend = new System.Windows.Forms.NumericUpDown();
            this.nudBAmmount = new System.Windows.Forms.NumericUpDown();
            this.lblMessage = new System.Windows.Forms.Label();
            this.hiddenTextBox = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCashToBank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCExpend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCAmmount)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudBankToCash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBExpend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBAmmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRefresh
            // 
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Location = new System.Drawing.Point(771, 152);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 30);
            this.btnRefresh.TabIndex = 16;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.nudCashToBank);
            this.groupBox3.Controls.Add(this.nudCExpend);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.nudCAmmount);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(439, 91);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(284, 199);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Cash";
            this.groupBox3.MouseHover += new System.EventHandler(this.MouseHoverCash);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "Cash To Bank";
            // 
            // nudCashToBank
            // 
            this.nudCashToBank.BackColor = System.Drawing.Color.WhiteSmoke;
            this.nudCashToBank.DecimalPlaces = 2;
            this.nudCashToBank.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudCashToBank.Location = new System.Drawing.Point(132, 123);
            this.nudCashToBank.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.nudCashToBank.Name = "nudCashToBank";
            this.nudCashToBank.Size = new System.Drawing.Size(120, 25);
            this.nudCashToBank.TabIndex = 5;
            this.nudCashToBank.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudCashToBank.ValueChanged += new System.EventHandler(this.CashToBank);
            // 
            // nudCExpend
            // 
            this.nudCExpend.BackColor = System.Drawing.Color.WhiteSmoke;
            this.nudCExpend.DecimalPlaces = 2;
            this.nudCExpend.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudCExpend.Location = new System.Drawing.Point(132, 80);
            this.nudCExpend.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.nudCExpend.Name = "nudCExpend";
            this.nudCExpend.Size = new System.Drawing.Size(120, 25);
            this.nudCExpend.TabIndex = 5;
            this.nudCExpend.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudCExpend.ValueChanged += new System.EventHandler(this.nudCExpend_ValueChanged);
            this.nudCExpend.Click += new System.EventHandler(this.ConClickExpend);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "Expend";
            // 
            // nudCAmmount
            // 
            this.nudCAmmount.BackColor = System.Drawing.Color.WhiteSmoke;
            this.nudCAmmount.DecimalPlaces = 2;
            this.nudCAmmount.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudCAmmount.Location = new System.Drawing.Point(132, 39);
            this.nudCAmmount.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.nudCAmmount.Name = "nudCAmmount";
            this.nudCAmmount.Size = new System.Drawing.Size(120, 25);
            this.nudCAmmount.TabIndex = 5;
            this.nudCAmmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudCAmmount.ValueChanged += new System.EventHandler(this.nudCAmmount_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Balance";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.nudBankToCash);
            this.groupBox2.Controls.Add(this.nudBExpend);
            this.groupBox2.Controls.Add(this.nudBAmmount);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(109, 91);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(284, 199);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bank";
            this.groupBox2.MouseHover += new System.EventHandler(this.MouseHoverBank);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(21, 126);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(98, 19);
            this.label.TabIndex = 7;
            this.label.Text = "Bank To Cash";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Expend";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Balance";
            // 
            // nudBankToCash
            // 
            this.nudBankToCash.BackColor = System.Drawing.Color.WhiteSmoke;
            this.nudBankToCash.DecimalPlaces = 2;
            this.nudBankToCash.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudBankToCash.Location = new System.Drawing.Point(142, 123);
            this.nudBankToCash.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.nudBankToCash.Name = "nudBankToCash";
            this.nudBankToCash.Size = new System.Drawing.Size(120, 25);
            this.nudBankToCash.TabIndex = 5;
            this.nudBankToCash.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudBankToCash.ValueChanged += new System.EventHandler(this.BankToCash);
            // 
            // nudBExpend
            // 
            this.nudBExpend.BackColor = System.Drawing.Color.WhiteSmoke;
            this.nudBExpend.DecimalPlaces = 2;
            this.nudBExpend.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudBExpend.Location = new System.Drawing.Point(142, 80);
            this.nudBExpend.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.nudBExpend.Name = "nudBExpend";
            this.nudBExpend.Size = new System.Drawing.Size(120, 25);
            this.nudBExpend.TabIndex = 5;
            this.nudBExpend.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudBExpend.ValueChanged += new System.EventHandler(this.nudBExpend_ValueChanged);
            this.nudBExpend.Click += new System.EventHandler(this.BonClickExpend);
            // 
            // nudBAmmount
            // 
            this.nudBAmmount.BackColor = System.Drawing.Color.WhiteSmoke;
            this.nudBAmmount.DecimalPlaces = 2;
            this.nudBAmmount.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudBAmmount.Location = new System.Drawing.Point(142, 37);
            this.nudBAmmount.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.nudBAmmount.Name = "nudBAmmount";
            this.nudBAmmount.Size = new System.Drawing.Size(120, 25);
            this.nudBAmmount.TabIndex = 5;
            this.nudBAmmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudBAmmount.ValueChanged += new System.EventHandler(this.nudBAmmount_ValueChanged);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(20, 29);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(67, 19);
            this.lblMessage.TabIndex = 13;
            this.lblMessage.Text = "Message";
            // 
            // hiddenTextBox
            // 
            this.hiddenTextBox.Location = new System.Drawing.Point(766, 33);
            this.hiddenTextBox.Name = "hiddenTextBox";
            this.hiddenTextBox.Size = new System.Drawing.Size(21, 20);
            this.hiddenTextBox.TabIndex = 12;
            this.hiddenTextBox.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Location = new System.Drawing.Point(771, 198);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 30);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 334);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(889, 70);
            this.dataGridView1.TabIndex = 10;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // CashMaintain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(913, 502);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.hiddenTextBox);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dataGridView1);
            this.Name = "CashMaintain";
            this.Text = "Cash Maintain";
            this.Load += new System.EventHandler(this.CashMaintain_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCashToBank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCExpend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCAmmount)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudBankToCash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBExpend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBAmmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudCashToBank;
        private System.Windows.Forms.NumericUpDown nudCExpend;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nudCAmmount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudBankToCash;
        private System.Windows.Forms.NumericUpDown nudBExpend;
        private System.Windows.Forms.NumericUpDown nudBAmmount;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.TextBox hiddenTextBox;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}