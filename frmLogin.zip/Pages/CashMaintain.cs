﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Model;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class CashMaintain : Common
    {
        public CashMaintain()
        {
            InitializeComponent();
        }

        private void CashMaintain_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            getOpeningAmmount();
            editButton();
            groupBox2.Enabled = false;
            groupBox3.Enabled = false;
            dataGridView1.AutoGenerateColumns = false;
            LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label4.ForeColor = ThemeColor.PrimaryColor;
            label6.ForeColor = ThemeColor.PrimaryColor;
            label.ForeColor = ThemeColor.PrimaryColor;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = ThemeColor.SecondaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.Gainsboro;
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;

        }
        void getOpeningAmmount()
        {
            string sql = @"SELECT ID, BankAmmount AS[Bank Ammount], CashAmmount AS[Cash Ammount],UpdatedDate AS[Updated Date],CreatedDate AS[Created Date] From Opening_Balance";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;
        }
        void editButton()
        {
            DataGridViewButtonColumn EditButton = new DataGridViewButtonColumn();
            EditButton.UseColumnTextForButtonValue = true;
            EditButton.HeaderText = "Edit";
            EditButton.DataPropertyName = "lnkColumn";
            EditButton.Text = "Edit";
            EditButton.FlatStyle = FlatStyle.Flat;
            EditButton.DefaultCellStyle.ForeColor = Color.White;
            EditButton.DefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            EditButton.DefaultCellStyle.SelectionBackColor = ThemeColor.SecondaryColor;
            EditButton.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.Columns.Add(EditButton);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            hiddenTextBox.Text = dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString();
            nudBAmmount.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Bank Ammount"].Value);
            nudCAmmount.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Cash Ammount"].Value);
            btnSave.Text = "Update";

            groupBox2.Enabled = true;
            groupBox3.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (btnSave.Text == "Save")
            {
                try
                {
                    string counts = @"Select *From Opening_Balance";
                    DataTable dt = (DataTable)Select(counts).Data;
                    if (dt.Rows.Count == 0)
                    {
                        string time = DateTime.Now.ToString();
                        string sql = @"INSERT INTO Opening_Balance(BankAmmount,CashAmmount,CreatedDate) VALUES('" + nudBAmmount.Value + "','" + nudCAmmount.Value + "','" + time + "')";
                        CUD(sql);
                        lblMessage.Text = Program.InsertSuccessMessage;
                        lblMessage.ForeColor = Color.Green;
                        getOpeningAmmount();
                    }
                    else
                    {
                        lblMessage.Text = "You Can't Add Again";
                        lblMessage.ForeColor = Color.Red;
                    }
                }
                catch (Exception ex)
                {
                    ex.ToString();
                    lblMessage.Text = Program.WrongMessage;
                    lblMessage.ForeColor = Color.Red;
                }
            }
            if (btnSave.Text == "Update")
            {
                try
                {
                    updateOpening();
                    lblMessage.Text = Program.UpdateSuccessMessage;
                    lblMessage.ForeColor = Color.Green;
                }
                catch
                {
                    lblMessage.Text = Program.WrongMessage;
                    lblMessage.ForeColor = Color.Red;
                }
            }
        }
        void updateOpening()
        {
            string time = DateTime.Now.ToString();
            int id = Convert.ToInt32(hiddenTextBox.Text.Trim());
            string sql = @"UPDATE Opening_Balance SET BankAmmount = '" + nudBAmmount.Value+"', CashAmmount = '"+nudCAmmount.Value+"', UpdatedDate = '"+time+"' WHERE ID = "+id+"";
            CUD(sql);
            btnSave.Text = "Save";
            getOpeningAmmount();
        }

        private void nudBExpend_ValueChanged(object sender, EventArgs e)
        {
            if (nudBExpend.Value<=nudBAmmount.Value)
            {
                nudBAmmount.Value = nudBAmmount.Value - nudBExpend.Value;
            }
            else
            {
                lblMessage.Text = "Min Value 0 , Can't Substract";
                lblMessage.ForeColor = Color.Red;
            }
            
        }
        private void nudCExpend_ValueChanged(object sender, EventArgs e)
        {
            if (nudCExpend.Value <= nudCAmmount.Value)
            {
                nudCAmmount.Value = nudCAmmount.Value - nudCExpend.Value;
                
            }
            else
            {
                lblMessage.Text = "Min Value 0 , Can't Substract";
                lblMessage.ForeColor = Color.Red;
            }
        }

        private void BonClickExpend(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(TextBox))
                ((TextBox)sender).SelectAll();
            else if (sender.GetType() == typeof(NumericUpDown))
            {
                NumericUpDown numeric = (NumericUpDown)sender;
                (numeric).Select(0, numeric.Value.ToString().Length + 3);
            }
            else
            {
                ((RichTextBox)sender).SelectAll();
            }
        }

        private void ConClickExpend(object sender, EventArgs e)
        {
            nudCExpend.ReadOnly = false;
            nudCExpend.Increment = 1;
            if (sender.GetType() == typeof(TextBox))
                ((TextBox)sender).SelectAll();
            else if (sender.GetType() == typeof(NumericUpDown))
            {
                NumericUpDown numeric = (NumericUpDown)sender;
                (numeric).Select(0, numeric.Value.ToString().Length + 3);
            }
            else
            {
                ((RichTextBox)sender).SelectAll();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            nudBAmmount.Value = 0;
            
            nudBExpend.Value = 0;
            nudCAmmount.Value = 0;
            
            nudCExpend.Value = 0;
            groupBox2.Enabled = false;
            groupBox3.Enabled = false;
        }

        private void MouseHoverCash(object sender, EventArgs e)
        {
            groupBox2.Enabled = false;
        }

        private void MouseHoverBank(object sender, EventArgs e)
        {
            groupBox3.Enabled = false;
        }

        private void BankToCash(object sender, EventArgs e)
        {
            if (nudBankToCash.Value <= nudBAmmount.Value)
            {
                nudBAmmount.Value = nudBAmmount.Value - nudBankToCash.Value;
                nudCAmmount.Value = nudCAmmount.Value + nudBankToCash.Value;
            }
            else
            {
                lblMessage.Text = "Min Value 0 , Can't Substract";
                lblMessage.ForeColor = Color.Red;
            }
        }

        private void CashToBank(object sender, EventArgs e)
        {
            if (nudCashToBank.Value <= nudCAmmount.Value)
            {
                nudCAmmount.Value = nudCAmmount.Value - nudCashToBank.Value;
                nudBAmmount.Value = nudBAmmount.Value + nudCashToBank.Value;
            }
            else
            {
                lblMessage.Text = "Min Value 0 , Can't Substract";
                lblMessage.ForeColor = Color.Red;
            }
        }

        private void nudBAmmount_ValueChanged(object sender, EventArgs e)
        {

        }

        private void nudCAmmount_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
