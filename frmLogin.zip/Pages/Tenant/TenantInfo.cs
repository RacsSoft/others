﻿using Racssoft_Housing.Pages.Tenant;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Model;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class TenantInfo : Common
    {
        string hwName = "", hwMobile = "", hwNID = "", hwAddress = "";
        string dName = "", dMobile = "", dNID = "", dAddress = "";
        string poName = "", poMobile = "", poAddress = "", poReasone = "";
        string FName = "",Mobile = "",Age = "",Occupation = "",FName2 = "",Mobile2 = "",Age2 = "",Occupation2 = "",FName3 = ""
            ,Mobile3 = "",Age3 = "",Occupation3 = "";

        private void Refresh_Click(object sender, EventArgs e)
        {
            clear();
            lblMessage.Text = "";
        }

        private void chkHouseMember_CheckedChanged(object sender, EventArgs e)
        {
            Name = "";
            Mobile = "";
            Age = "";
            Occupation = "";

            FName2 = "";
            Mobile2 = "";
            Age2 = "";
            Occupation2 = "";

            FName3 = "";
            Mobile3 = "";
            Age3 = "";
            Occupation3 = "";
            if (chkPrevious.Checked)
            {
                FamilyMembers obj = new FamilyMembers();
                obj.ShowDialog();
                FName = obj.Name;
                Mobile = obj.Mobile;
                Age = obj.Age;
                Occupation = obj.Occupation;

                FName2 = obj.Name2;
                Age2 = obj.Age2;
                Mobile2 = obj.Mobile2;
                Occupation2 = obj.Occupation2;

                FName3 = obj.Name3;
                Age3 = obj.Age3;
                Mobile3 = obj.Mobile3;
                Occupation3 = obj.Occupation3;
            }
        }

        private void TenantInfo_Load(object sender, EventArgs e)
        {
            getFlats();
            lblMessage.Text = "";
            textBox1.Text = (MaxId() + 1).ToString();
            LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label4.ForeColor = ThemeColor.PrimaryColor;
            label5.ForeColor = ThemeColor.PrimaryColor;
            label6.ForeColor = ThemeColor.PrimaryColor;
            label7.ForeColor = ThemeColor.PrimaryColor;
            label8.ForeColor = ThemeColor.PrimaryColor;
            label9.ForeColor = ThemeColor.PrimaryColor;
            label10.ForeColor = ThemeColor.PrimaryColor;
            label11.ForeColor = ThemeColor.PrimaryColor;
            label12.ForeColor = ThemeColor.PrimaryColor;
            label13.ForeColor = ThemeColor.PrimaryColor;
            label14.ForeColor = ThemeColor.PrimaryColor;
            //label15.ForeColor = ThemeColor.PrimaryColor;
            label16.ForeColor = ThemeColor.PrimaryColor;
            label17.ForeColor = ThemeColor.PrimaryColor;
            label18.ForeColor = ThemeColor.PrimaryColor;
            chkDriver.ForeColor = ThemeColor.PrimaryColor;
            chkHouseMember.ForeColor = ThemeColor.PrimaryColor;
            chkHouseWorker.ForeColor = ThemeColor.PrimaryColor;
            chkPrevious.ForeColor = ThemeColor.PrimaryColor;
        }
        void getFlats()
        {
            string sql = "SELECT *FROM One_Building_Flats";
            DataTable dt = (DataTable)Select(sql).Data;
            cmbFlat.DataSource = dt;
            cmbFlat.DisplayMember = "Title";
            cmbFlat.ValueMember = "ID";
            cmbFlat.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cmbFlat.AutoCompleteSource = AutoCompleteSource.ListItems;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtName.Text !="" && txtFatherName.Text !="" && txtMob.Text !="" && cmbFlat.Text !="" && txtNid.Text !="")
                {
                    string time = DateTime.Now.ToString();
                    string sql = @"INSERT INTO Tenants(TenantName,FatherName,DOB,MaritalStatus,PermanentAddress,FlatID,Occupation,Religion,Education,Mobile,Email,NID,Passport,ECName,ECRelation,ECAddress,ECMobile,HWName,HWNID,HWMobile,HWAddress,DName,DNID,DMobile,DAddress,POName,POMobile,POAddress,Reason,EntryDate) 
                           VALUES('" + txtName.Text.Trim()+"','"+txtFatherName.Text.Trim()+"','"+dtpDOB.Value.Date+"','"+cmbMs.Text+"','"+rTBPA.Text.Trim()+"',"+cmbFlat.SelectedValue+"," +
                           "'"+txtOccupation.Text.Trim()+"','"+cmbReligion.Text+"','"+txtEdu.Text.Trim()+"','"+txtMob.Text.Trim()+"','"+txtEmail.Text.Trim()+"','"+txtNid.Text.Trim()+"','"+txtPassport.Text.Trim()+"','"+txtEmCName.Text.Trim()+"','"+txtECRelation.Text.Trim()+"','"+rTBPA.Text.Trim()+"','"+EmCMob.Text.Trim()+"','"+hwName+"','"+hwNID+"','"+hwMobile+"','"+hwAddress+"','"+dName+"','"+dNID+"','"+dMobile+"','"+dAddress+"','"+poName+"','"+poMobile+"','"+poAddress+"','"+poReasone+"','"+time+"')";
                    CUD(sql);
                    
                    string FM1sql = @"INSERT INTO Tenant_Family_Members(TenantID,FName,FAge,FOccupation,FMobile) VALUES('"+textBox1.Text.Trim()+"','"+FName+"','"+Age+"','"+Occupation+"','"+Mobile+"')";
                    string FM2sql = @"INSERT INTO Tenant_Family_Members(TenantID,FName,FAge,FOccupation,FMobile) VALUES('"+textBox1.Text.Trim()+"','"+FName2+"','"+Age2+"','"+Occupation2+"','"+Mobile2+"')";
                    string FM3sql = @"INSERT INTO Tenant_Family_Members(TenantID,FName,FAge,FOccupation,FMobile) VALUES('"+textBox1.Text.Trim()+"','"+FName3+"','"+Age3+"','"+Occupation3+"','"+Mobile3+"')";
                    CUD(FM1sql);
                    CUD(FM2sql);
                    CUD(FM3sql);
                    lblMessage.Text = Program.InsertSuccessMessage;
                    lblMessage.ForeColor = Color.Green;
                    long id = MaxId();
                    textBox1.Text = (id + 1).ToString();
                    clear();
                }
                else
                {
                    lblMessage.Text = "Please Fill up all Information!";
                    lblMessage.ForeColor = Color.Red;
                }
            }
            catch(Exception ex)
            {
                ex.ToString();
            }
        }
        long MaxId()
        {
            DataTable dt;
            string cmd = "SELECT MAX(ID) FROM Tenants";
            dt = (DataTable)Select(cmd).Data;
            long id = dt.Rows.Count > 0 && !string.IsNullOrEmpty(dt.Rows[0][0].ToString()) ? Convert.ToInt64(dt.Rows[0][0]) : 0;
            return id;
        }
        void clear()
        {
            txtName.Clear();
            txtFatherName.Clear();
            cmbMs.ResetText();
            dtpDOB.ResetText();
            cmbFlat.ResetText();
            txtOccupation.Clear();
            cmbReligion.ResetText();
            txtEmail.Clear();
            txtNid.Clear();
            txtPassport.Clear();
            rTBPA.Clear();
            txtEmCName.Clear();
            EmCMob.Clear();
            EmCRTPA.Clear();
            txtECRelation.Clear();
            txtEdu.Clear();
            txtMob.Clear();

        }
       
        public TenantInfo()
        {
            InitializeComponent();
        }
        private void chkPrevious_CheckedChanged(object sender, EventArgs e)
        {
            poName = "";
            poMobile = "";
            poAddress = "";
            poReasone = "";
            if (chkPrevious.Checked)
            {
                PreviousHouse obj = new PreviousHouse();
                obj.ShowDialog();
                poName = obj.Name;
                poMobile = obj.Mobile;
                poReasone = obj.Reasone;
                poAddress = obj.Address;
            }
        }
        private void chkDriver_CheckedChanged(object sender, EventArgs e)
        {
            dName = "";
            dMobile = "";
            dNID = "";
            dAddress = "";
            if (chkDriver.Checked)
            {
                Driver obj = new Driver();
                obj.ShowDialog();
                dName = obj.Name;
                dMobile = obj.Mobile;
                dNID = obj.NID;
                dAddress = obj.Address;
            }
        }

        private void chkHouseWorker_CheckedChanged(object sender, EventArgs e)
        {
            hwName = "";
            hwMobile = "";
            hwNID = "";
            hwAddress = "";
            if (chkHouseWorker.Checked)
            {
                HouseWorker houseWorker = new HouseWorker();
                houseWorker.ShowDialog();
                hwName = houseWorker.Name;
                hwMobile = houseWorker.Mobile;
                hwNID = houseWorker.NID;
                hwAddress = houseWorker.Address;
            }
        }

    }
}
