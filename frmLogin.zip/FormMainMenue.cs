﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Racssoft_Housing.Pages;

namespace Racssoft_Housing
{
    public partial class FormMainMenue : Form
    {
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        public FormMainMenue()
        {
            InitializeComponent();
            random = new Random();
            btnCloseChildForm.Visible = false;
            this.Text = string.Empty;
            this.ControlBox = false;
            panelMemberManage.Visible = false;

        }
        [System.Runtime.InteropServices.DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [System.Runtime.InteropServices.DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void FormMainMenue_Load(object sender, EventArgs e)
        {

        }
        //method
        void hideSubMenue()
        {
            if(panelMemberManage.Visible == true)
            {
                panelMemberManage.Visible = false;
            }
        }
        void showSubMenue(Panel panel)
        {
            if(panel.Visible == false)
            {
                hideSubMenue();
                panel.Visible = true;
            }
            else
            {
                panel.Visible = false;
            }
        }


        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnSender)
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    panelTitleBar.BackColor = color;
                    panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    ThemeColor.PrimaryColor = color;
                    ThemeColor.SecondaryColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    btnCloseChildForm.Visible = true;
                }
            }
        }
        private void DisableButton()
        {
            foreach (Control previousBtn in panelMenue.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = Color.FromArgb(51, 51, 76);
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }
        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
                activeForm.Close();
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDesktopPane.Controls.Add(childForm);
            this.panelDesktopPane.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;
        }

        private void btnDailyExpenditure_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Pages.DailyCostCalculation(), sender);
        }

        private void btnBillInvoice_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Pages.Invoice(), sender);
        }

        private void btnBillCollection_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Pages.Bill_Collection(), sender);
        }

        private void btnCashMainTain_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Pages.CashMaintain(), sender);
        }

        private void btnTenantInfo_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Pages.TenantInfo(), sender);
        }

        private void btnMemberManage_Click(object sender, EventArgs e)
        {
            showSubMenue(panelMemberManage);
        }

        private void btnDocumentUp_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Pages.FileUpload(), sender);
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
        }

        private void btnCloseChildForm_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
                activeForm.Close();
            Reset();
        }
        private void Reset()
        {
            DisableButton();
            lblTitle.Text = "DashBoard";
            panelTitleBar.BackColor = Color.FromArgb(0, 150, 136);
            panelLogo.BackColor = Color.FromArgb(39, 39, 58);
            currentButton = null;
            btnCloseChildForm.Visible = false;
        }

        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimze_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnShowMember_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
        }

        private void btnMemberListAdd_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
        }

        private void btnMemberTitle_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
        }
    }
}
