﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Racssoft_Housing.Pages;
using Racssoft_Housing.Pages.Tenant;
using Racssoft_Housing.Pages.Members;

namespace Racssoft_Housing
{
    static class Program
    {
        public static string SessionID = "";
        public static string SessionName = "";
        public static string InsertSuccessMessage = "Save successfully";
        public static string UpdateSuccessMessage = "Updated successfully";
        public static string DeleteSuccessMessage = "Deleted successfully";
        public static string WrongMessage = "Something goes wrong!";
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Parent());
        }
    }
}
