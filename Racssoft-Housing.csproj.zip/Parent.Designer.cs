﻿
namespace Racssoft_Housing
{
	partial class Parent
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Parent));
			System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Dashboard");
			System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Daily Expenditure");
			System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Tenants");
			System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Add");
			System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Tenant", new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode4});
			System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Member Title ");
			System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Member Add");
			System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Show Member");
			System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Member", new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode7,
            treeNode8});
			System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Document Upload");
			System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Manage", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode9,
            treeNode10});
			System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Invoice");
			System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Bill Collection");
			System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Contact");
			System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Settings");
			System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Clients");
			System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Employees");
			System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Supliers");
			System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Users", new System.Windows.Forms.TreeNode[] {
            treeNode16,
            treeNode17,
            treeNode18});
			System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Your Profile");
			System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Logout");
			this.panel1 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.picLogo = new System.Windows.Forms.PictureBox();
			this.lblWelcomeUser = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.lblClose = new System.Windows.Forms.Label();
			this.lblMinimize = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.treeViewMenu = new System.Windows.Forms.TreeView();
			this.timerWindowAnimation = new System.Windows.Forms.Timer(this.components);
			this.panel3 = new System.Windows.Forms.Panel();
			this.lvProfile = new System.Windows.Forms.ListView();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.button1);
			this.panel1.Controls.Add(this.picLogo);
			this.panel1.Controls.Add(this.lblWelcomeUser);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.lblClose);
			this.panel1.Controls.Add(this.lblMinimize);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1000, 57);
			this.panel1.TabIndex = 0;
			this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTitleBar_MouseDown);
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.button1.BackColor = System.Drawing.Color.DodgerBlue;
			this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
			this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(922, -1);
			this.button1.Margin = new System.Windows.Forms.Padding(0);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(33, 24);
			this.button1.TabIndex = 17;
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// picLogo
			// 
			this.picLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.picLogo.Dock = System.Windows.Forms.DockStyle.Left;
			this.picLogo.Location = new System.Drawing.Point(0, 0);
			this.picLogo.Name = "picLogo";
			this.picLogo.Size = new System.Drawing.Size(198, 53);
			this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.picLogo.TabIndex = 16;
			this.picLogo.TabStop = false;
			// 
			// lblWelcomeUser
			// 
			this.lblWelcomeUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lblWelcomeUser.AutoSize = true;
			this.lblWelcomeUser.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lblWelcomeUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lblWelcomeUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblWelcomeUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.lblWelcomeUser.Location = new System.Drawing.Point(755, 3);
			this.lblWelcomeUser.Name = "lblWelcomeUser";
			this.lblWelcomeUser.Size = new System.Drawing.Size(47, 20);
			this.lblWelcomeUser.TabIndex = 15;
			this.lblWelcomeUser.Text = "User";
			this.lblWelcomeUser.Click += new System.EventHandler(this.lblWelcomeUser_Click);
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(937, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(0, 24);
			this.label1.TabIndex = 16;
			this.label1.Click += new System.EventHandler(this.lblMinimize_Click);
			// 
			// lblClose
			// 
			this.lblClose.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblClose.AutoSize = true;
			this.lblClose.BackColor = System.Drawing.Color.Red;
			this.lblClose.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lblClose.Font = new System.Drawing.Font("MS Reference Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.lblClose.Location = new System.Drawing.Point(960, -1);
			this.lblClose.Name = "lblClose";
			this.lblClose.Size = new System.Drawing.Size(34, 34);
			this.lblClose.TabIndex = 16;
			this.lblClose.Text = "X";
			this.lblClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblClose.Click += new System.EventHandler(this.lblClose_Click);
			// 
			// lblMinimize
			// 
			this.lblMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lblMinimize.AutoSize = true;
			this.lblMinimize.BackColor = System.Drawing.Color.DodgerBlue;
			this.lblMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lblMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMinimize.ForeColor = System.Drawing.Color.White;
			this.lblMinimize.Location = new System.Drawing.Point(888, -1);
			this.lblMinimize.Name = "lblMinimize";
			this.lblMinimize.Size = new System.Drawing.Size(30, 24);
			this.lblMinimize.TabIndex = 16;
			this.lblMinimize.Text = "__";
			this.lblMinimize.Click += new System.EventHandler(this.lblMinimize_Click);
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.White;
			this.panel2.Controls.Add(this.label2);
			this.panel2.Controls.Add(this.treeViewMenu);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.panel2.Location = new System.Drawing.Point(0, 57);
			this.panel2.Name = "panel2";
			this.panel2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
			this.panel2.Size = new System.Drawing.Size(200, 506);
			this.panel2.TabIndex = 4;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(40, 479);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(98, 18);
			this.label2.TabIndex = 6;
			this.label2.Text = "Version: 1.0.0";
			// 
			// treeViewMenu
			// 
			this.treeViewMenu.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.treeViewMenu.Dock = System.Windows.Forms.DockStyle.Left;
			this.treeViewMenu.Location = new System.Drawing.Point(0, 10);
			this.treeViewMenu.Name = "treeViewMenu";
			treeNode1.Checked = true;
			treeNode1.Name = "nDashboard";
			treeNode1.Text = "Dashboard";
			treeNode2.Name = "nExpenditure";
			treeNode2.Text = "Daily Expenditure";
			treeNode3.Name = "nAllTenant";
			treeNode3.Text = "Tenants";
			treeNode4.Name = "nTenantAdd";
			treeNode4.Text = "Add";
			treeNode5.Name = "nManageTenantInfo";
			treeNode5.Text = "Tenant";
			treeNode6.Name = "nMemberHierarchy";
			treeNode6.Text = "Member Title ";
			treeNode7.Name = "nMemberAdd";
			treeNode7.Text = "Member Add";
			treeNode8.Name = "nShowMember";
			treeNode8.Text = "Show Member";
			treeNode9.Name = "nManageMember";
			treeNode9.Text = "Member";
			treeNode10.Name = "nDocumentUpload";
			treeNode10.Text = "Document Upload";
			treeNode11.Name = "nManage";
			treeNode11.Text = "Manage";
			treeNode12.Name = "nInvoice";
			treeNode12.Text = "Invoice";
			treeNode13.Name = "nBillCollection";
			treeNode13.Text = "Bill Collection";
			treeNode14.Name = "nContact";
			treeNode14.Text = "Contact";
			treeNode15.Name = "nSetting";
			treeNode15.Text = "Settings";
			treeNode16.Name = "nClient";
			treeNode16.Text = "Clients";
			treeNode17.Name = "nEmployee";
			treeNode17.Text = "Employees";
			treeNode18.Name = "nSuplier";
			treeNode18.Text = "Supliers";
			treeNode19.Name = "nUser";
			treeNode19.Text = "Users";
			this.treeViewMenu.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode11,
            treeNode12,
            treeNode13,
            treeNode14,
            treeNode15,
            treeNode19});
			this.treeViewMenu.Size = new System.Drawing.Size(200, 496);
			this.treeViewMenu.TabIndex = 5;
			this.treeViewMenu.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewMenu_AfterSelect);
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.lvProfile);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(200, 57);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(800, 506);
			this.panel3.TabIndex = 5;
			// 
			// lvProfile
			// 
			this.lvProfile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lvProfile.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lvProfile.HideSelection = false;
			this.lvProfile.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2});
			this.lvProfile.Location = new System.Drawing.Point(619, 0);
			this.lvProfile.Name = "lvProfile";
			this.lvProfile.Size = new System.Drawing.Size(93, 45);
			this.lvProfile.TabIndex = 17;
			this.lvProfile.UseCompatibleStateImageBehavior = false;
			this.lvProfile.View = System.Windows.Forms.View.SmallIcon;
			this.lvProfile.Visible = false;
			this.lvProfile.SelectedIndexChanged += new System.EventHandler(this.lvProfile_SelectedIndexChanged);
			// 
			// Parent
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1000, 563);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Parent";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Parent";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.Parent_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.TreeView treeViewMenu;
		private System.Windows.Forms.Label lblWelcomeUser;
		private System.Windows.Forms.PictureBox picLogo;
		private System.Windows.Forms.Timer timerWindowAnimation;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.ListView lvProfile;
        private System.Windows.Forms.Label lblMinimize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lblClose;
	}
}