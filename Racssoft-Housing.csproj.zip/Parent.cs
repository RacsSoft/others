﻿using Models;
using Racssoft_Housing.Pages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Racssoft_Housing.Pages.Members;
using Racssoft_Housing.Pages.Tenant;

namespace Racssoft_Housing
{
	public partial class Parent : Form
	{
		public string UserFullName { get; set; }
		public string ComputerSerialKey { get; }
		public Parent()
		{
			InitializeComponent();
			//setAllPanelPicture();
			ImageList();
		}
		private void ImageList()
		{
			ImageList myImageList = new ImageList();
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Dashboard"))));//0
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Suppliers"))));
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("User"))));
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Products"))));//3
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Brands"))));//4
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Units"))));
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Sales"))));
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Notification"))));
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Logout"))));//8
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Users"))));//9
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Sales"))));//10
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Settings"))));//11
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Entry"))));//12
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Category"))));//13
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Tax"))));//14
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Customers"))));//15
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Selected"))));//16
			//myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Address"))));//17
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Utility"))));//18
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Contact"))));//19
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Invoice"))));//20
			myImageList.Images.Add(Image.FromStream(new MemoryStream(Pictures.GetPicture("Expenditure"))));//21


			// Assign the ImageList to the TreeView.
			treeViewMenu.ImageList = myImageList;

			// Set the TreeView control's default image and selected image indexes.
			//treeViewMenu.ImageIndex = 0;
			treeViewMenu.SelectedImageIndex = 16;

			treeViewMenu.Nodes[0].ImageIndex = 0;
			treeViewMenu.Nodes[1].ImageIndex = 21;
			//treeViewMenu.Nodes[1].Nodes[0].ImageIndex = 12;
			//treeViewMenu.Nodes[1].Nodes[1].ImageIndex = 10;
			//treeViewMenu.Nodes[1].Nodes[2].ImageIndex = 4;
			//treeViewMenu.Nodes[1].Nodes[3].ImageIndex = 13;
			//treeViewMenu.Nodes[1].Nodes[4].ImageIndex = 14;
			//treeViewMenu.Nodes[1].Nodes[5].ImageIndex = 5;
			treeViewMenu.Nodes[2].ImageIndex = 13;
			treeViewMenu.Nodes[2].Nodes[0].ImageIndex = 17;
			treeViewMenu.Nodes[2].Nodes[1].ImageIndex = 18;
			//treeViewMenu.Nodes[2].Nodes[2].ImageIndex = 2; //9
			treeViewMenu.Nodes[3].ImageIndex = 20;
			treeViewMenu.Nodes[4].ImageIndex = 19;
			//treeViewMenu.SelectedNode.ImageIndex = 0;
			//treeViewMenu.SelectedNode.SelectedImageIndex = 1;


			// setup listview
			lvProfile.StateImageList = myImageList;
			// set up initial image index
			lvProfile.Items[0].StateImageIndex = 2;
			lvProfile.Items[1].StateImageIndex = 8;
			//lblMaximize.Image = myImageList.Images[0];

			picLogo.Image = Image.FromStream(new MemoryStream(Pictures.GetPicture("RacsLogo")));
			//this.Icon = Image.FromStream(new MemoryStream(Pictures.GetPicture("RacsIco")));

		}
		//private void setAllPanelPicture()
		//{
		//	picNotification.Image = Image.FromStream(new MemoryStream(Pictures.GetPicture("Notification")));
		//}
		
		void BuyFullVersion()
		{
			MessageBox.Show("Please Buy Full Version" + Environment.NewLine + "Contact Number: +880 9666 770 780");
		}
		bool isLvProfileVisible = false;
		private void lblWelcomeUser_Click(object sender, EventArgs e)
		{
			lvProfile.Visible = !isLvProfileVisible;
			isLvProfileVisible = !isLvProfileVisible;
			this.panel3.Controls.Add(lvProfile);
			lvProfile.BringToFront();

		}
		private void ShowForm(object form)
		{
			this.panel3.Controls.Clear();
			Form frm = form as Form;
			frm.Dock = DockStyle.Fill;

			frm.FormBorderStyle = FormBorderStyle.None;
			frm.ShowIcon = false;
			frm.StartPosition = FormStartPosition.CenterScreen;
			frm.WindowState = FormWindowState.Maximized;
			frm.BackColor = Color.WhiteSmoke;


			frm.TopLevel = false;
			frm.TopMost = false;
			frm.SendToBack();
			this.panel3.Controls.Add(frm);
			this.panel3.Tag = frm;
			frm.Show();
		}
		private void Parent_Load(object sender, EventArgs e)
		{
			lblWelcomeUser.Visible = false;
			frmLogin login = new frmLogin(this);
			login.ShowDialog();

			lblWelcomeUser.Text = "Welcome " + UserFullName + " !";
			lblWelcomeUser.Visible = true;

			//btnWelcomeUser.Text = "Welcome " + UserFullName + " !";
			lblWelcomeUser.Visible = true;

			ShowForm(new Dashboard());
		}

		private void lvProfile_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lvProfile.SelectedItems.Count > 0)
			{
				var item = lvProfile.SelectedItems[0].Text;
				if(item == "Logout")
				{
					//Environment.Exit(0);
					//this.Close();
					this.panel3.Controls.Clear();
					isLvProfileVisible = false;
					lblWelcomeUser.Visible = false;
					frmLogin login = new frmLogin(this);
					login.ShowDialog();

					lblWelcomeUser.Text = "Welcome " + UserFullName + " !";
					lblWelcomeUser.Visible = true;

					//btnWelcomeUser.Text = "Welcome " + UserFullName + " !";
					lblWelcomeUser.Visible = true;

					ShowForm(new Dashboard());
				}
			}
			
		}

		[DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
		private extern static void ReleaseCapture();

		[DllImport("user32.DLL", EntryPoint = "SendMessage")]
		private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
		private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
		{
			ReleaseCapture();
			SendMessage(this.Handle, 0x112, 0xf012, 0);
		}

		private void treeViewMenu_AfterSelect(object sender, TreeViewEventArgs e)
		{
			switch (treeViewMenu.SelectedNode.Name)
			{
				case "nDashboard":
					ShowForm(new Dashboard());
					break;
				case "nExpenditure":
					ShowForm(new DailyCostCalculation());
					break;
				case "nManageTenantInfo":
					ShowForm(new TenantInfo());
					break;
				case "nAllTenant":
					ShowForm(new AllTenants());
					break;
				case "nTenantAdd":
					ShowForm(new AllTenants());
					break;
				case "nManageMember":
					treeViewMenu.Nodes[2].Nodes[1].Expand();
                    break;
                case "nMemberHierarchy":
					ShowForm(new MemberHierarchy());
					break;
				case "nMemberAdd":
					ShowForm(new MemberList());
					break;
                case "nShowMember":
                    ShowForm(new ShowMembers());
                    break;
                case "nDocumentUpload":
					ShowForm(new FileUpload());
					break;
				case "nInvoice":
					ShowForm(new Invoice());
					break;
				case "nBillCollection":
					ShowForm(new Bill_Collection());
					break;
				case "nManage":
					treeViewMenu.Nodes[2].Expand();// Expand the node.
					break;
				case "nUser":
					treeViewMenu.Nodes[7].Expand();// Expand the node.
					break;
				default: 
					BuyFullVersion();
					break;

			}
		
		

		}

        private void lblMinimize_Click(object sender, EventArgs e)
        {
			this.WindowState = FormWindowState.Minimized;
		}

        private void lblMaximize_Click(object sender, EventArgs e)
        {
			if(this.WindowState == FormWindowState.Normal)
            {
				this.WindowState = FormWindowState.Maximized;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
			if (this.WindowState == FormWindowState.Normal)
			{
				this.WindowState = FormWindowState.Maximized;
			}
			else
			{
				this.WindowState = FormWindowState.Normal;
			}
		}

  //      private void button2_Click(object sender, EventArgs e)
  //      {
		//	lvProfile.Visible = !isLvProfileVisible;
		//	isLvProfileVisible = !isLvProfileVisible;

		//	this.panel3.Controls.Add(lvProfile);
		//	lvProfile.BringToFront();
		//	lvProfile.Visible = true;
		//}

		private void lblClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
