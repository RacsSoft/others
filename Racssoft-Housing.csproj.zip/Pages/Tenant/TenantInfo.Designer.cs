﻿
namespace Racssoft_Housing.Pages
{
    partial class TenantInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnSave = new System.Windows.Forms.Button();
			this.dtpDOB = new System.Windows.Forms.DateTimePicker();
			this.txtName = new System.Windows.Forms.TextBox();
			this.rTBPA = new System.Windows.Forms.RichTextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtFatherName = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.cmbFlat = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.cmbReligion = new System.Windows.Forms.ComboBox();
			this.label9 = new System.Windows.Forms.Label();
			this.txtEdu = new System.Windows.Forms.TextBox();
			this.txtMob = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.txtNid = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.txtPassport = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.txtEmCName = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label18 = new System.Windows.Forms.Label();
			this.EmCRTPA = new System.Windows.Forms.RichTextBox();
			this.EmCMob = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.txtECRelation = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.chkHouseWorker = new System.Windows.Forms.CheckBox();
			this.chkDriver = new System.Windows.Forms.CheckBox();
			this.chkPrevious = new System.Windows.Forms.CheckBox();
			this.chkHouseMember = new System.Windows.Forms.CheckBox();
			this.txtOccupation = new System.Windows.Forms.TextBox();
			this.cmbMs = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.lblMessage = new System.Windows.Forms.Label();
			this.Refresh = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnSave
			// 
			this.btnSave.Location = new System.Drawing.Point(808, 449);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(75, 23);
			this.btnSave.TabIndex = 0;
			this.btnSave.Text = "Save";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// dtpDOB
			// 
			this.dtpDOB.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpDOB.Location = new System.Drawing.Point(122, 83);
			this.dtpDOB.Name = "dtpDOB";
			this.dtpDOB.Size = new System.Drawing.Size(169, 25);
			this.dtpDOB.TabIndex = 2;
			// 
			// txtName
			// 
			this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtName.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtName.Location = new System.Drawing.Point(123, 49);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(168, 25);
			this.txtName.TabIndex = 3;
			// 
			// rTBPA
			// 
			this.rTBPA.BackColor = System.Drawing.Color.WhiteSmoke;
			this.rTBPA.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.rTBPA.Location = new System.Drawing.Point(480, 80);
			this.rTBPA.Name = "rTBPA";
			this.rTBPA.Size = new System.Drawing.Size(401, 79);
			this.rTBPA.TabIndex = 4;
			this.rTBPA.Text = "";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(2, 52);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(113, 16);
			this.label1.TabIndex = 5;
			this.label1.Text = "Tenant\'s Name";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtFatherName
			// 
			this.txtFatherName.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtFatherName.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtFatherName.Location = new System.Drawing.Point(480, 49);
			this.txtFatherName.Name = "txtFatherName";
			this.txtFatherName.Size = new System.Drawing.Size(164, 25);
			this.txtFatherName.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(358, 55);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(109, 16);
			this.label2.TabIndex = 5;
			this.label2.Text = "Father\'s Name";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(73, 88);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(40, 16);
			this.label4.TabIndex = 5;
			this.label4.Text = "DOB";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(321, 117);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(144, 16);
			this.label5.TabIndex = 5;
			this.label5.Text = "Permanent Address";
			// 
			// cmbFlat
			// 
			this.cmbFlat.BackColor = System.Drawing.Color.WhiteSmoke;
			this.cmbFlat.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmbFlat.FormattingEnabled = true;
			this.cmbFlat.Location = new System.Drawing.Point(122, 119);
			this.cmbFlat.Name = "cmbFlat";
			this.cmbFlat.Size = new System.Drawing.Size(169, 27);
			this.cmbFlat.TabIndex = 6;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(78, 125);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(34, 16);
			this.label6.TabIndex = 5;
			this.label6.Text = "Flat";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(26, 160);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(86, 16);
			this.label7.TabIndex = 5;
			this.label7.Text = "Occupation";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(46, 196);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(66, 16);
			this.label8.TabIndex = 5;
			this.label8.Text = "Religion";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// cmbReligion
			// 
			this.cmbReligion.BackColor = System.Drawing.Color.WhiteSmoke;
			this.cmbReligion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbReligion.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmbReligion.FormattingEnabled = true;
			this.cmbReligion.Items.AddRange(new object[] {
            "Islam",
            "Hinduism",
            "Buddhism",
            "Christians",
            "Others"});
			this.cmbReligion.Location = new System.Drawing.Point(122, 190);
			this.cmbReligion.Name = "cmbReligion";
			this.cmbReligion.Size = new System.Drawing.Size(169, 27);
			this.cmbReligion.TabIndex = 6;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.Location = new System.Drawing.Point(36, 237);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(77, 16);
			this.label9.TabIndex = 5;
			this.label9.Text = "Education";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtEdu
			// 
			this.txtEdu.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtEdu.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtEdu.Location = new System.Drawing.Point(121, 230);
			this.txtEdu.Name = "txtEdu";
			this.txtEdu.Size = new System.Drawing.Size(170, 25);
			this.txtEdu.TabIndex = 3;
			// 
			// txtMob
			// 
			this.txtMob.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtMob.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtMob.Location = new System.Drawing.Point(121, 269);
			this.txtMob.Name = "txtMob";
			this.txtMob.Size = new System.Drawing.Size(170, 25);
			this.txtMob.TabIndex = 3;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.Location = new System.Drawing.Point(56, 274);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(55, 16);
			this.label10.TabIndex = 5;
			this.label10.Text = "Mobile";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtEmail
			// 
			this.txtEmail.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtEmail.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtEmail.Location = new System.Drawing.Point(121, 306);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(170, 25);
			this.txtEmail.TabIndex = 3;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(62, 313);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(47, 16);
			this.label11.TabIndex = 5;
			this.label11.Text = "Email";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtNid
			// 
			this.txtNid.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtNid.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtNid.Location = new System.Drawing.Point(121, 340);
			this.txtNid.Name = "txtNid";
			this.txtNid.Size = new System.Drawing.Size(170, 25);
			this.txtNid.TabIndex = 3;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.Location = new System.Drawing.Point(75, 347);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(34, 16);
			this.label12.TabIndex = 5;
			this.label12.Text = "NID";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtPassport
			// 
			this.txtPassport.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtPassport.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtPassport.Location = new System.Drawing.Point(121, 372);
			this.txtPassport.Name = "txtPassport";
			this.txtPassport.Size = new System.Drawing.Size(170, 25);
			this.txtPassport.TabIndex = 3;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.Location = new System.Drawing.Point(39, 381);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(70, 16);
			this.label13.TabIndex = 5;
			this.label13.Text = "Passport";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtEmCName
			// 
			this.txtEmCName.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtEmCName.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtEmCName.Location = new System.Drawing.Point(156, 21);
			this.txtEmCName.Name = "txtEmCName";
			this.txtEmCName.Size = new System.Drawing.Size(164, 25);
			this.txtEmCName.TabIndex = 3;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(70, 24);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(49, 16);
			this.label14.TabIndex = 5;
			this.label14.Text = "Name";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label18);
			this.groupBox1.Controls.Add(this.EmCRTPA);
			this.groupBox1.Controls.Add(this.EmCMob);
			this.groupBox1.Controls.Add(this.label17);
			this.groupBox1.Controls.Add(this.txtECRelation);
			this.groupBox1.Controls.Add(this.label16);
			this.groupBox1.Controls.Add(this.txtEmCName);
			this.groupBox1.Controls.Add(this.label14);
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(324, 229);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(564, 165);
			this.groupBox1.TabIndex = 7;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Emergency Contact";
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.Location = new System.Drawing.Point(6, 74);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(144, 16);
			this.label18.TabIndex = 7;
			this.label18.Text = "Permanent Address";
			// 
			// EmCRTPA
			// 
			this.EmCRTPA.BackColor = System.Drawing.Color.WhiteSmoke;
			this.EmCRTPA.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.EmCRTPA.Location = new System.Drawing.Point(156, 54);
			this.EmCRTPA.Name = "EmCRTPA";
			this.EmCRTPA.Size = new System.Drawing.Size(401, 59);
			this.EmCRTPA.TabIndex = 6;
			this.EmCRTPA.Text = "";
			// 
			// EmCMob
			// 
			this.EmCMob.BackColor = System.Drawing.Color.WhiteSmoke;
			this.EmCMob.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.EmCMob.Location = new System.Drawing.Point(414, 24);
			this.EmCMob.Name = "EmCMob";
			this.EmCMob.Size = new System.Drawing.Size(144, 25);
			this.EmCMob.TabIndex = 3;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(353, 27);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(55, 16);
			this.label17.TabIndex = 5;
			this.label17.Text = "Mobile";
			// 
			// txtECRelation
			// 
			this.txtECRelation.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtECRelation.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtECRelation.Location = new System.Drawing.Point(156, 128);
			this.txtECRelation.Name = "txtECRelation";
			this.txtECRelation.Size = new System.Drawing.Size(164, 25);
			this.txtECRelation.TabIndex = 3;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.Location = new System.Drawing.Point(60, 131);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(66, 16);
			this.label16.TabIndex = 5;
			this.label16.Text = "Relation";
			// 
			// chkHouseWorker
			// 
			this.chkHouseWorker.AutoSize = true;
			this.chkHouseWorker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkHouseWorker.Location = new System.Drawing.Point(36, 412);
			this.chkHouseWorker.Name = "chkHouseWorker";
			this.chkHouseWorker.Size = new System.Drawing.Size(155, 20);
			this.chkHouseWorker.TabIndex = 9;
			this.chkHouseWorker.Text = "House Worker Info";
			this.chkHouseWorker.UseVisualStyleBackColor = true;
			this.chkHouseWorker.CheckedChanged += new System.EventHandler(this.chkHouseWorker_CheckedChanged);
			// 
			// chkDriver
			// 
			this.chkDriver.AutoSize = true;
			this.chkDriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkDriver.Location = new System.Drawing.Point(279, 412);
			this.chkDriver.Name = "chkDriver";
			this.chkDriver.Size = new System.Drawing.Size(98, 20);
			this.chkDriver.TabIndex = 9;
			this.chkDriver.Text = "Driver Info";
			this.chkDriver.UseVisualStyleBackColor = true;
			this.chkDriver.CheckedChanged += new System.EventHandler(this.chkDriver_CheckedChanged);
			// 
			// chkPrevious
			// 
			this.chkPrevious.AutoSize = true;
			this.chkPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkPrevious.Location = new System.Drawing.Point(481, 412);
			this.chkPrevious.Name = "chkPrevious";
			this.chkPrevious.Size = new System.Drawing.Size(169, 20);
			this.chkPrevious.TabIndex = 9;
			this.chkPrevious.Text = "Previous Tenant Info";
			this.chkPrevious.UseVisualStyleBackColor = true;
			this.chkPrevious.CheckedChanged += new System.EventHandler(this.chkPrevious_CheckedChanged);
			// 
			// chkHouseMember
			// 
			this.chkHouseMember.AutoSize = true;
			this.chkHouseMember.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkHouseMember.Location = new System.Drawing.Point(733, 412);
			this.chkHouseMember.Name = "chkHouseMember";
			this.chkHouseMember.Size = new System.Drawing.Size(161, 20);
			this.chkHouseMember.TabIndex = 9;
			this.chkHouseMember.Text = "House Member Info";
			this.chkHouseMember.UseVisualStyleBackColor = true;
			this.chkHouseMember.CheckedChanged += new System.EventHandler(this.chkHouseMember_CheckedChanged);
			// 
			// txtOccupation
			// 
			this.txtOccupation.BackColor = System.Drawing.Color.WhiteSmoke;
			this.txtOccupation.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtOccupation.Location = new System.Drawing.Point(123, 154);
			this.txtOccupation.Name = "txtOccupation";
			this.txtOccupation.Size = new System.Drawing.Size(168, 25);
			this.txtOccupation.TabIndex = 10;
			// 
			// cmbMs
			// 
			this.cmbMs.BackColor = System.Drawing.Color.WhiteSmoke;
			this.cmbMs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbMs.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmbMs.FormattingEnabled = true;
			this.cmbMs.Items.AddRange(new object[] {
            "Single",
            "Married"});
			this.cmbMs.Location = new System.Drawing.Point(756, 44);
			this.cmbMs.Name = "cmbMs";
			this.cmbMs.Size = new System.Drawing.Size(121, 27);
			this.cmbMs.TabIndex = 11;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(650, 49);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(102, 16);
			this.label3.TabIndex = 5;
			this.label3.Text = "Marital Status";
			// 
			// lblMessage
			// 
			this.lblMessage.AutoSize = true;
			this.lblMessage.BackColor = System.Drawing.Color.White;
			this.lblMessage.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMessage.Location = new System.Drawing.Point(12, 14);
			this.lblMessage.Name = "lblMessage";
			this.lblMessage.Size = new System.Drawing.Size(67, 19);
			this.lblMessage.TabIndex = 12;
			this.lblMessage.Text = "Message";
			// 
			// Refresh
			// 
			this.Refresh.Location = new System.Drawing.Point(715, 449);
			this.Refresh.Name = "Refresh";
			this.Refresh.Size = new System.Drawing.Size(75, 23);
			this.Refresh.TabIndex = 0;
			this.Refresh.Text = "Refresh";
			this.Refresh.UseVisualStyleBackColor = true;
			this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(834, 12);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(24, 20);
			this.textBox1.TabIndex = 13;
			this.textBox1.Visible = false;
			// 
			// TenantInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(913, 502);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.lblMessage);
			this.Controls.Add(this.cmbMs);
			this.Controls.Add(this.txtOccupation);
			this.Controls.Add(this.chkHouseMember);
			this.Controls.Add(this.chkPrevious);
			this.Controls.Add(this.chkDriver);
			this.Controls.Add(this.chkHouseWorker);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.cmbReligion);
			this.Controls.Add(this.cmbFlat);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.rTBPA);
			this.Controls.Add(this.txtFatherName);
			this.Controls.Add(this.txtPassport);
			this.Controls.Add(this.txtNid);
			this.Controls.Add(this.txtEmail);
			this.Controls.Add(this.txtMob);
			this.Controls.Add(this.txtEdu);
			this.Controls.Add(this.txtName);
			this.Controls.Add(this.dtpDOB);
			this.Controls.Add(this.Refresh);
			this.Controls.Add(this.btnSave);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "TenantInfo";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Tenant Info";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.TenantInfo_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.RichTextBox rTBPA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFatherName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbFlat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbReligion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtEdu;
        private System.Windows.Forms.TextBox txtMob;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNid;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtPassport;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtEmCName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RichTextBox EmCRTPA;
        private System.Windows.Forms.TextBox EmCMob;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox chkHouseWorker;
        private System.Windows.Forms.CheckBox chkDriver;
        private System.Windows.Forms.CheckBox chkPrevious;
        private System.Windows.Forms.CheckBox chkHouseMember;
        private System.Windows.Forms.TextBox txtOccupation;
        private System.Windows.Forms.ComboBox cmbMs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.TextBox txtECRelation;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button Refresh;
        private System.Windows.Forms.TextBox textBox1;
    }
}