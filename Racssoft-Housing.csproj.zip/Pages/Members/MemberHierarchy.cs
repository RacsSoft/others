﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class MemberHierarchy : Common
    {
        public MemberHierarchy()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sql = @"INSERT INTO Committee_Hierarchy(Title) VALUES('" + txtTitle.Text + "')";
            CUD(sql);
        }
    }
}
