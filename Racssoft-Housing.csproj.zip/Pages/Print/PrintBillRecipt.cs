﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
	public partial class PrintBillRecipt : Form
	{
		private string ids, months, apartments, payeds, dues, payDates, bankOrCashs;
		

        

        public PrintBillRecipt(string invoice,string month,string apartment,string payed,string due,string payDate,string bankOrCash)
		{
			ids = invoice;
			months = month;
			apartments = apartment;
			payeds = payed;
			dues = due;
			payDates = payDate;
			bankOrCashs = bankOrCash;
			
			InitializeComponent();
		}

		private void label15_Click(object sender, EventArgs e)
		{

		}
		Bitmap bmp;

		private void btnPrint_Click(object sender, EventArgs e)
		{
			btnPrint.Visible = false;

			Graphics g = this.CreateGraphics();
			bmp = new Bitmap(this.Size.Width, this.Size.Height, g);
			Graphics p = Graphics.FromImage(bmp);
			p.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, this.Size);
			//printDialog.ShowDialog();

			printDialog.Document = printDocument;
			if (printDialog.ShowDialog() == DialogResult.OK)
			{
				printDocument.Print();
			}
			this.Close();
		}
		private void PrintBill_Load(object sender, EventArgs e)
		{
			lblMonth.Text = months.ToString();
			lblApartment.Text = apartments.ToString();
			lblInvoice.Text = ids.ToString();
			lblDueAmmount.Text = dues.ToString();
			lblPaidAmmount.Text = payeds.ToString();
			lblPaidBy.Text = bankOrCashs.ToString();
			lblPaidDate.Text = payDates.ToString();
			
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			e.Graphics.DrawImage(bmp, 0, 0);

			
		}
	}
}
