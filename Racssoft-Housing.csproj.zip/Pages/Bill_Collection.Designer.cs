﻿
namespace Racssoft_Housing.Pages
{
    partial class Bill_Collection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtCashBalance = new System.Windows.Forms.NumericUpDown();
            this.txtBankBalance = new System.Windows.Forms.NumericUpDown();
            this.txtMonth = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtOther = new System.Windows.Forms.TextBox();
            this.numProfit = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbInvId = new System.Windows.Forms.ComboBox();
            this.cmbBankCash = new System.Windows.Forms.ComboBox();
            this.numPayed = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.numDue = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numPayable = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCashBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBankBalance)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numProfit)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPayed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPayable)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 268);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(889, 222);
            this.dataGridView1.TabIndex = 29;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txtCashBalance
            // 
            this.txtCashBalance.DecimalPlaces = 2;
            this.txtCashBalance.Location = new System.Drawing.Point(808, 84);
            this.txtCashBalance.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.txtCashBalance.Name = "txtCashBalance";
            this.txtCashBalance.Size = new System.Drawing.Size(75, 20);
            this.txtCashBalance.TabIndex = 27;
            this.txtCashBalance.Visible = false;
            // 
            // txtBankBalance
            // 
            this.txtBankBalance.DecimalPlaces = 2;
            this.txtBankBalance.Location = new System.Drawing.Point(808, 58);
            this.txtBankBalance.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.txtBankBalance.Name = "txtBankBalance";
            this.txtBankBalance.Size = new System.Drawing.Size(75, 20);
            this.txtBankBalance.TabIndex = 28;
            this.txtBankBalance.Visible = false;
            // 
            // txtMonth
            // 
            this.txtMonth.Location = new System.Drawing.Point(708, 84);
            this.txtMonth.Name = "txtMonth";
            this.txtMonth.Size = new System.Drawing.Size(80, 20);
            this.txtMonth.TabIndex = 26;
            this.txtMonth.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(708, 57);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(80, 20);
            this.textBox2.TabIndex = 25;
            this.textBox2.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(713, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 13);
            this.label8.TabIndex = 24;
            this.label8.Visible = false;
            // 
            // btnRefresh
            // 
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Location = new System.Drawing.Point(750, 113);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 30);
            this.btnRefresh.TabIndex = 22;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnSave
            // 
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Location = new System.Drawing.Point(750, 153);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 30);
            this.btnSave.TabIndex = 23;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txtOther);
            this.groupBox3.Controls.Add(this.numProfit);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(453, 36);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(245, 208);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Other Collection (Optional)";
            this.groupBox3.MouseHover += new System.EventHandler(this.groupBox3_MouseHover);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "Details";
            // 
            // txtOther
            // 
            this.txtOther.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtOther.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOther.Location = new System.Drawing.Point(76, 52);
            this.txtOther.Name = "txtOther";
            this.txtOther.Size = new System.Drawing.Size(113, 25);
            this.txtOther.TabIndex = 0;
            // 
            // numProfit
            // 
            this.numProfit.BackColor = System.Drawing.Color.WhiteSmoke;
            this.numProfit.DecimalPlaces = 2;
            this.numProfit.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numProfit.Location = new System.Drawing.Point(76, 89);
            this.numProfit.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numProfit.Name = "numProfit";
            this.numProfit.Size = new System.Drawing.Size(113, 25);
            this.numProfit.TabIndex = 4;
            this.numProfit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(21, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 19);
            this.label7.TabIndex = 2;
            this.label7.Text = "Profit";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(22, 14);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(67, 19);
            this.lblMessage.TabIndex = 19;
            this.lblMessage.Text = "Message";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbInvId);
            this.groupBox2.Controls.Add(this.cmbBankCash);
            this.groupBox2.Controls.Add(this.numPayed);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.numDue);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.numPayable);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(163, 36);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(245, 208);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Appartment Collection";
            this.groupBox2.MouseHover += new System.EventHandler(this.groupBox2_MouseHover);
            // 
            // cmbInvId
            // 
            this.cmbInvId.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cmbInvId.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbInvId.FormattingEnabled = true;
            this.cmbInvId.Location = new System.Drawing.Point(111, 30);
            this.cmbInvId.Name = "cmbInvId";
            this.cmbInvId.Size = new System.Drawing.Size(113, 27);
            this.cmbInvId.TabIndex = 5;
            this.cmbInvId.SelectedIndexChanged += new System.EventHandler(this.cmbInvId_SelectedIndexChanged);
            // 
            // cmbBankCash
            // 
            this.cmbBankCash.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cmbBankCash.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBankCash.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBankCash.FormattingEnabled = true;
            this.cmbBankCash.Items.AddRange(new object[] {
            "Cash",
            "Bank"});
            this.cmbBankCash.Location = new System.Drawing.Point(111, 62);
            this.cmbBankCash.Name = "cmbBankCash";
            this.cmbBankCash.Size = new System.Drawing.Size(113, 27);
            this.cmbBankCash.TabIndex = 5;
            // 
            // numPayed
            // 
            this.numPayed.BackColor = System.Drawing.Color.WhiteSmoke;
            this.numPayed.DecimalPlaces = 2;
            this.numPayed.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numPayed.Location = new System.Drawing.Point(111, 128);
            this.numPayed.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numPayed.Name = "numPayed";
            this.numPayed.Size = new System.Drawing.Size(113, 25);
            this.numPayed.TabIndex = 4;
            this.numPayed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numPayed.ValueChanged += new System.EventHandler(this.numPayed_ValueChanged);
            this.numPayed.Click += new System.EventHandler(this.numPayed_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Invoice ID";
            // 
            // numDue
            // 
            this.numDue.BackColor = System.Drawing.Color.WhiteSmoke;
            this.numDue.DecimalPlaces = 2;
            this.numDue.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numDue.Location = new System.Drawing.Point(111, 162);
            this.numDue.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numDue.Name = "numDue";
            this.numDue.Size = new System.Drawing.Size(113, 25);
            this.numDue.TabIndex = 4;
            this.numDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numDue.Click += new System.EventHandler(this.numPayed_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(56, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 19);
            this.label5.TabIndex = 2;
            this.label5.Text = "Due";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Payable";
            // 
            // numPayable
            // 
            this.numPayable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.numPayable.DecimalPlaces = 2;
            this.numPayable.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numPayable.Location = new System.Drawing.Point(111, 96);
            this.numPayable.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numPayable.Name = "numPayable";
            this.numPayable.Size = new System.Drawing.Size(113, 25);
            this.numPayable.TabIndex = 4;
            this.numPayable.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Bank / Cash";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 19);
            this.label6.TabIndex = 2;
            this.label6.Text = "Payed";
            // 
            // Bill_Collection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(913, 502);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtCashBalance);
            this.Controls.Add(this.txtBankBalance);
            this.Controls.Add(this.txtMonth);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.groupBox2);
            this.Name = "Bill_Collection";
            this.ShowIcon = false;
            this.Text = "Bill Collection";
            this.Load += new System.EventHandler(this.Monthly_Collection_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCashBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBankBalance)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numProfit)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPayed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPayable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.NumericUpDown txtCashBalance;
        private System.Windows.Forms.NumericUpDown txtBankBalance;
        private System.Windows.Forms.TextBox txtMonth;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOther;
        private System.Windows.Forms.NumericUpDown numProfit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbInvId;
        private System.Windows.Forms.ComboBox cmbBankCash;
        private System.Windows.Forms.NumericUpDown numPayed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numDue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numPayable;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
    }
}