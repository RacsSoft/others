﻿using System;
using Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class Address : Common
    {
        public Address()
        {
            InitializeComponent();
            combosBuilding();
            combosFlat();
            combosArea();
            combosRoad();
            combosDistrict();
            combosCountry();
            getAddress();
            
        }

        private void Address_Load(object sender, EventArgs e)
        {
            
        }
        public void combosFlat()
        {
            string sql = @"SELECT *From Flats";
            DataTable dt = (DataTable)Select(sql).Data;
            comboFlats.DataSource = dt;

            DataRow itemrow = dt.NewRow();
            itemrow[1] = "Select Flat";
            dt.Rows.InsertAt(itemrow, 0);
            comboFlats.SelectedIndex = 0;
            

            comboFlats.DisplayMember = "Title";
            comboFlats.ValueMember = "ID";
        }
        public void combosBuilding()
        {
            string sql = @"SELECT *From Building";
            DataTable dt = (DataTable)Select(sql).Data;
            comboBuildings.DataSource = dt;
            DataRow itemrow = dt.NewRow();
            itemrow[1] = "Select Building";
            dt.Rows.InsertAt(itemrow, 0);
            comboBuildings.SelectedIndex = 0;

            comboBuildings.DisplayMember = "Title";
            comboBuildings.ValueMember = "ID";
        }
        public void combosArea()
        {
            string sql = @"SELECT *From Areas";
            DataTable dt = (DataTable)Select(sql).Data;
            comboAreas.DataSource = dt;
            DataRow itemrow = dt.NewRow();
            itemrow[1] = "Select Area";
            dt.Rows.InsertAt(itemrow, 0);
            comboAreas.SelectedIndex = 0;

            comboAreas.DisplayMember = "Title";
            comboAreas.ValueMember = "ID";
        }
        public void combosRoad()
        {
            string sql = @"SELECT *From Roads";
            DataTable dt = (DataTable)Select(sql).Data;
            comboRoads.DataSource = dt;
            DataRow itemrow = dt.NewRow();
            itemrow[1] = "Select Road";
            dt.Rows.InsertAt(itemrow, 0);
            comboRoads.SelectedIndex = 0;

            comboRoads.DisplayMember = "Title";
            comboRoads.ValueMember = "ID";
        }
        public void combosDistrict()
        {
            string sql = @"SELECT *From Districts";
            DataTable dt = (DataTable)Select(sql).Data;
            comboDistricts.DataSource = dt;
            DataRow itemrow = dt.NewRow();
            itemrow[1] = "Select District";
            dt.Rows.InsertAt(itemrow, 0);
            comboDistricts.SelectedIndex = 0;

            comboDistricts.DisplayMember = "Title";
            comboDistricts.ValueMember = "ID";
        }
        public void combosCountry()
        {
            string sql = @"SELECT *From Country";
            DataTable dt = (DataTable)Select(sql).Data;
            comboCountrys.DataSource = dt;
            DataRow itemrow = dt.NewRow();
            itemrow[1] = "Select Country";
            dt.Rows.InsertAt(itemrow, 0);
            comboCountrys.SelectedIndex = 0;

            comboCountrys.DisplayMember = "Title";
            comboCountrys.ValueMember = "ID";
        }
        private void comboFlat_SelectedValueChanged(object sender, EventArgs e)
        {
            label8.Text = comboFlats.SelectedValue.ToString();
            
        }
        private void comboArea_SelectedValueChanged(object sender, EventArgs e)
        {
            label12.Text = comboAreas.SelectedValue.ToString();
        }
        private void comboBuildings_SelectedValueChanged(object sender, EventArgs e)
        {
            label11.Text = comboBuildings.SelectedValue.ToString();
        }
        private void comboRoads_SelectedValueChanged(object sender, EventArgs e)
        {
            label9.Text = comboRoads.SelectedValue.ToString();
        }

        private void comboCountrys_SelectedValueChanged(object sender, EventArgs e)
        {
            label10.Text = comboCountrys.SelectedValue.ToString();
        }

        private void comboDistricts_SelectedValueChanged(object sender, EventArgs e)
        {
            label13.Text = comboDistricts.SelectedValue.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if(label8.Text != "" && label11.Text !="" && label9.Text !="" && label12.Text != "" && label13.Text != "" && label10.Text != "")
                {
                    string sql = @"INSERT INTO Address(Flat_ID, Building_ID, Road_ID, Area_ID, District_ID, Country_ID) VALUES('" + label8.Text.Trim() + "','" + label11.Text.Trim() + "','" + label9.Text.Trim() + "','" + label12.Text.Trim() + "','" + label13.Text.Trim() + "','" + label10.Text.Trim() + "')";
                    CUD(sql);
                    comboBuildings.ResetText();
                    comboFlats.ResetText();
                    comboRoads.ResetText();
                    comboAreas.ResetText();
                    comboCountrys.ResetText();
                    comboDistricts.ResetText();
                    MessageBox.Show("Saved!");
                    getAddress();
                }
                else
                {
                    MessageBox.Show("Please Select All Information!");
                }
                
            }
            catch
            {
                MessageBox.Show("Something Goes Wrong!");
            }
        }
        void getAddress()
        {
            string sql = @"SELECT c.ID, f.Title AS[Flat], b.Title AS[Building], r.Title AS[Road], 
                    a.Title AS[Area], d.Title AS[District], p.Title AS[Country]  FROM ((((((Address c LEFT JOIN Flats f ON c.Flat_ID = f.ID) 
                    LEFT JOIN Building b ON c.Building_ID = b.ID) LEFT JOIN Roads r ON c.Road_ID = r.ID) 
                    LEFT JOIN Areas a ON c.Area_ID = a.ID) LEFT JOIN Districts d ON c.District_ID = d.ID) 
                    LEFT JOIN Country p ON c.Country_ID = p.ID)";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Visible = false;
        } 
    }
}
