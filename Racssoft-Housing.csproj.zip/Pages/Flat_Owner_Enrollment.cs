﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class Flat_Owner_Enrollment : Common
    {
        public Flat_Owner_Enrollment()
        {
            InitializeComponent();
            getFlatOwner();
        }

        private void Flat_Owner_Enrollment_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            string sql = "SELECT ID, Title FROM FLATs";
            DataTable dt = (DataTable)Select(sql).Data;
            if (dt != null)
            {
                cmbFlats.DataSource = dt;
                DataRow itemrow = dt.NewRow();
                itemrow[1] = "Select Flat";
                dt.Rows.InsertAt(itemrow, 0);
                cmbFlats.SelectedIndex = 0;

                cmbFlats.DisplayMember = "Title";
                cmbFlats.ValueMember = "ID";
            }
            sql = "SELECT ID, OwnerName FROM Owners";
            dt = (DataTable)Select(sql).Data;
            if (dt != null)
            {
                cmbOwners.DataSource = dt;

                DataRow itemrow = dt.NewRow();
                itemrow[1] = "Select Name";
                dt.Rows.InsertAt(itemrow, 0);
                cmbOwners.SelectedIndex = 0;

                cmbOwners.DisplayMember = "OwnerName";
                cmbOwners.ValueMember = "ID";
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbFlats.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please select a flat!";
                    lblMessage.ForeColor = Color.Red;
                    return;
                }
                if (cmbOwners.SelectedIndex == 0)
                {
                    lblMessage.Text = "Please select an owner!";
                    lblMessage.ForeColor = Color.Red;
                    return;
                }
                string sql = @"INSERT INTO Flat_Owner_Enrollment(Flat_ID, Owner_ID, BuyDate, Comment) 
                        VALUES(" + cmbFlats.SelectedValue + ", " + cmbOwners.SelectedValue
                            + ",'" + dtpBuyingDate.Value + "','" + txtComment.Text + "')";
                CUD(sql);
                lblMessage.Text = Program.InsertSuccessMessage;
                lblMessage.ForeColor = Color.Green;
                getFlatOwner();
            }
            catch (Exception ex)
            {
                //log
                lblMessage.Text = Program.WrongMessage;
                lblMessage.ForeColor = Color.Red;
            }
        }
        void getFlatOwner()
        {
            string sql = @"SELECT f.ID, o.OwnerName AS[Owner Name], a.Title AS[Appartment] FROM ((Flat_Owner_Enrollment f LEFT JOIN Owners o ON f.Owner_ID = o.ID) LEFT JOIN One_Building_Flats a ON f.Flat_ID = a.ID)";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView.DataSource = dt;
            dataGridView.Columns["ID"].Visible = false;
            
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string sql = @"SELECT f.ID, o.OwnerName AS[Owner Name], a.Title AS[Appartment] FROM ((Flat_Owner_Enrollment f LEFT JOIN Owners o ON f.Owner_ID = o.ID) LEFT JOIN One_Building_Flats a ON f.Flat_ID = a.ID) WHERE a.Title LIKE '%" + txtSearch.Text + "%' OR o.OwnerName LIKE '%" + txtSearch.Text + "%'";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView.DataSource = dt;
            //dataGridView.Columns["ID"].Visible = false; 
        }
    }
}
