﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
	public partial class SpendAreaType : Common
	{
		public SpendAreaType()
		{
			InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if(button2.Text=="Save")
            {
                string value = textBox1.Text.Trim();
                try
                {
                    if(value != "")
                    {
                        string sql = @"INSERT INTO Spend_Area_Type(Title) VALUES('" + value + "')";
                        CUD(sql);
                        MessageBox.Show("Saved Successfully");
                        textBox1.Clear();
                        getItems();
                    }
                    else
                    {
                        MessageBox.Show("Please Enter Utility Type!");
                    }
                    
                }
                catch
                {
                    MessageBox.Show("Something Goes Wrong!");
                }
            }
            if (button2.Text == "Update")
            {
                try
                {
                    string value = textBox1.Text.Trim();
                    if(value != "")
                    {
                        updateUtilityType();
                    }
                    else
                    {
                        MessageBox.Show("Please Enter Utility Type!");
                    }
                }
                catch
                {
                    MessageBox.Show("Something Goes Wrong!");
                }
            }
            
        }
        void getItems()
        {
            string sql = @"SELECT ID,Title FROM Spend_Area_Type";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;
        }
        void updateUtilityType()
        {
            string title = textBox1.Text.Trim();
            int id = Convert.ToInt32(hiddenTextBox.Text.Trim());
            string sql = @"UPDATE Spend_Area_Type SET Title ='" + title + "' WHERE ID="+id+"";
            CUD(sql);
            textBox1.Clear();
            button2.Text = "Save";
            MessageBox.Show("Updated!");
            getItems();
            hiddenTextBox.Clear();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            hiddenTextBox.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            button2.Text = "Update";
        }
        void editButton()
        {
            DataGridViewLinkColumn Editlink = new DataGridViewLinkColumn();
            Editlink.UseColumnTextForLinkValue = true;
            Editlink.HeaderText = "Edit";
            Editlink.DataPropertyName = "lnkColumn";
            Editlink.LinkBehavior = LinkBehavior.SystemDefault;
            Editlink.Text = "Edit";
            dataGridView1.Columns.Add(Editlink);

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string sql = @"SELECT *FROM Spend_Area_Type WHERE Title LIKE '%" + textBox2.Text+"%'";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            //dataGridView1.Columns[1].Visible = false;   
        }

        private void SpendAreaType_Load(object sender, EventArgs e)
        {
            getItems();
            editButton();
        }
    }
}
