﻿using System;
using Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;

namespace Racssoft_Housing.Pages
{
    public partial class FileUpload : Common
    {
        Dictionary<int, string> address;
        Dictionary<int, string> spendAreaType;
        public FileUpload()
        {
            InitializeComponent();
        }
        private void FileUpload_Load(object sender, EventArgs e)
        {
            combosApartment();
            getDocument();
            LoadButton();
            //LoadTheme();
            dataGridView1.AutoGenerateColumns = false;
        }
        static string path = Environment.CurrentDirectory;
        static string databasePath = @"\DB\Document.accdb;";
        static string tPath = path + databasePath;
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + tPath);
        OleDbCommand cmd = new OleDbCommand();
        string sql;
        OpenFileDialog ofd = new OpenFileDialog();

        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label4.ForeColor = ThemeColor.PrimaryColor;
            lblUtility.ForeColor = ThemeColor.PrimaryColor;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = ThemeColor.SecondaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.Gainsboro;
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;

        }
        private void saveImage(string sql)
        {
            try
            {
                con.Open();
                string path = ofd.FileName;
                byte[] imageData;

                cmd = new OleDbCommand();

                cmd.Connection = con;
                cmd.CommandText = sql;
                imageData = System.IO.File.ReadAllBytes(@path);
                cmd.Parameters.AddWithValue("@IM", imageData);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var size = new FileInfo(ofd.FileName).Length;
            if(size<=5000000)
            {
                if (comboApartment.Text !="" && txtDocTitle.Text !="")
                {
                    string time = DateTime.Now.ToString();
                    string address = comboApartment.Text.Trim();
                    string bill = txtDocTitle.Text.Trim();
                    sql = "INSERT INTO Document (Apartment, MonthName, Bill_Title, IMG, Upload_Time) VALUES ('" + address + "','"+cmbMonth.Text.Trim()+"','" + bill + "',@IM,'"+time+"')";
                    saveImage(sql);
                    MessageBox.Show("Image has been saved into the database");
                    comboApartment.ResetText();
                    
                    getDocument();
                }
                else
                {
                    MessageBox.Show("Please Select All Information");
                }
            }
            else
            {
                MessageBox.Show("Max Upload File Size 5 MB");
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //'CHECK THE SELECTED FILE IF IT EXIST OTHERWISE THE DIALOG BOX WILL DISPLAY A WARNING.
            ofd.CheckFileExists = true;

            //'CHECK THE SELECTED PATH IF IT EXIST OTHERWISE THE DIALOG BOX WILL DISPLAY A WARNING.
            ofd.CheckPathExists = true;

            //'GET AND SET THE DEFAULT EXTENSION
            ofd.DefaultExt = "jpg";

            //'RETURN THE FILE LINKED TO THE LNK FILE
            ofd.DereferenceLinks = true;

            //'SET THE FILE NAME TO EMPTY 
            ofd.FileName = ".jpg";

            //'FILTERING THE FILES
            ofd.Filter = "(*.jpg)|*.jpg|(*.png)|*.png|(*.jpeg)|*.jpeg";
            //'SET THIS FOR ONE FILE SELECTION ONLY.
            ofd.Multiselect = false;

            //'SET THIS TO PUT THE CURRENT FOLDER BACK TO WHERE IT HAS STARTED.
            ofd.RestoreDirectory = true;

            //'SET THE TITLE OF THE DIALOG BOX.
            ofd.Title = "Select a file to open";

            //'ACCEPT ONLY THE VALID WIN32 FILE NAMES.
            ofd.ValidateNames = true;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(ofd.FileName);
            }
        }

        void combosApartment()
        {
            string sql = "SELECT *FROM One_Building_Flats";
            DataTable dt = (DataTable)Select(sql).Data;
            comboApartment.DataSource = dt;
            comboApartment.DisplayMember = "Title";
            comboApartment.ValueMember = "ID";
            comboApartment.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboApartment.AutoCompleteSource = AutoCompleteSource.ListItems;
        }
        
        void getDocument()
        {
            try
            {
                string sql = @"SELECT *From Document";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, con);
                DataTable table = new DataTable();
                dataAdapter.Fill(table);
                dataGridView1.DataSource = table;
                dataGridView1.Columns["ID"].Visible = false;
                dataGridView1.Columns["IMG"].Visible = false;
            }
            catch(Exception ex)
            {
                ex.ToString();
            } 
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string sql = @"SELECT *FROM Document WHERE Bill_Title LIKE '%" + textBox1.Text + "%' OR Apartment LIKE '%" + textBox1.Text + "%' OR Upload_Time LIKE '%" + textBox1.Text + "%' OR MonthName LIKE '%" + textBox1.Text + "%'";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sql, con);
                DataTable table = new DataTable();
                dataAdapter.Fill(table);
                dataGridView1.DataSource = table;
                dataGridView1.Columns["ID"].Visible = false;
                dataGridView1.Columns["IMG"].Visible = false;
            }
            catch(Exception ex)
            {
                ex.ToString();
            } 
        }

        void LoadButton()
        {
            DataGridViewButtonColumn LoadButton = new DataGridViewButtonColumn();
            LoadButton.UseColumnTextForButtonValue = true;
            LoadButton.HeaderText = "Load";
            LoadButton.DataPropertyName = "lnkColumn";
            //LoadButton.LinkBehavior = LinkBehavior.SystemDefault;
            LoadButton.Text = "Load";
            LoadButton.FlatStyle = FlatStyle.Flat;
            LoadButton.DefaultCellStyle.ForeColor = Color.White;
            LoadButton.DefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            LoadButton.DefaultCellStyle.SelectionBackColor = ThemeColor.SecondaryColor;
            LoadButton.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.Columns.Add(LoadButton);
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                byte[] bytes = (byte[])dataGridView1.Rows[e.RowIndex].Cells["IMG"].Value;
                var form = new DocumentLoad(bytes);
                form.ShowDialog();
            }
            catch(Exception ex)
            {
                ex.ToString();
            }
        }
    }
}
