﻿using System;
using Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Racssoft_Housing.Pages
{
    public partial class Invoice : Common
    {
        public Invoice()
        {
            InitializeComponent();
        }
        private void MonthlyCostCalculation_Load(object sender, EventArgs e)
        {
            getFlats();
            getMonthlyCollections();
            editButton();
            lblMessage.Text = "";
            txtInvoiceNo.Text = "inv000" + (invoiceId() + 1);
            printButton();
            dataGridView1.AutoGenerateColumns = false;
            //LoadTheme();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label4.ForeColor = ThemeColor.PrimaryColor;
            label5.ForeColor = ThemeColor.PrimaryColor;
            label6.ForeColor = ThemeColor.PrimaryColor;
            label7.ForeColor = ThemeColor.PrimaryColor;
            label8.ForeColor = ThemeColor.PrimaryColor;
            label9.ForeColor = ThemeColor.PrimaryColor;
            label10.ForeColor = ThemeColor.PrimaryColor;
            label11.ForeColor = ThemeColor.PrimaryColor;
            label12.ForeColor = ThemeColor.PrimaryColor;
            

            dataGridView1.EnableHeadersVisualStyles = false;
            //dataGridView1.GridColor = ThemeColor.SecondaryColor;
            //dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            //dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            //dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //dataGridView1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft YaHei", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //dataGridView1.DefaultCellStyle.SelectionBackColor = Color.Gainsboro;
            //dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;
            
        }
        void getFlats()
        {
            string sql = "SELECT *FROM One_Building_Flats";
            DataTable dt = (DataTable)Select(sql).Data;
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Title";
            comboBox1.ValueMember = "ID";
            comboBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboBox1.AutoCompleteSource = AutoCompleteSource.ListItems;
        }
        void getMonthlyCollections()
        {
            string sql =@"SELECT m.ID,m.InvoiceNo,f.Title AS[Appartment],m.GasBill AS[Gas Bill],m.ElectricBill AS[Electric Bill]" +
                ",m.WaterBill AS[Water Bill],m.Due,m.LPS AS[LPS],m.MosqueBill AS[Mosque Bill],m.Others,m.Comment,m.Total,m.MonthName AS[Month]" +
                "FROM Invoice m LEFT JOIN One_Building_Flats f ON m.FlatID = f.ID ";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string sql = @"SELECT m.ID,m.InvoiceNo,f.Title AS[Appartment],m.GasBill AS[Gas Bill],m.ElectricBill AS[Electric Bill]" +
                ",m.WaterBill AS[Water Bill],m.Due,m.LPS AS[LPS],m.MosqueBill AS[Mosque Bill],m.Others,m.Comment,m.Total,m.MonthName AS[Month]" +
                "FROM Invoice m LEFT JOIN One_Building_Flats f ON m.FlatID = f.ID  WHERE f.Title LIKE '%" + textBox1.Text + "%'";
            DataTable dt = (DataTable)Select(sql).Data;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].Visible = false;

        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(btnSave.Text == "Save")
            {
                try
                {
                    if(comboBox1.Text !="" && cmbMonth.Text !="")
                    {
                        string sql = @"SELECT * FROM Invoice Where FlatID = " + comboBox1.SelectedValue + " AND MonthName ='" + cmbMonth.Text + "'";
                        DataTable dt = (DataTable)Select(sql).Data;
                        if (dt.Rows.Count == 0)
                        {
                            double Total = (double)(numGasBill.Value + numElectricBill.Value + numMosqueBill.Value + numLPS.Value + numWaterBill.Value + numDue.Value + numOthers.Value);
                            string time = DateTime.Now.ToString();
                            int flatId = Convert.ToInt32(comboBox1.SelectedValue.ToString());
                            sql = @"INSERT INTO Invoice(InvoiceNo,GasBill, ElectricBill, MosqueBill, LPS, WaterBill, Due, Others, Comment,Total,FlatID, MonthName, CreatedDate) VALUES('" + txtInvoiceNo.Text.Trim() + "','" + Convert.ToDouble(numGasBill.Value) + "','" + Convert.ToDouble(numElectricBill.Value) + "','" + Convert.ToDouble(numMosqueBill.Value) + "','" + Convert.ToDouble(numLPS.Value) + "','" + Convert.ToDouble(numWaterBill.Value) + "','" + Convert.ToDouble(numDue.Value) + "','" + Convert.ToDouble(numOthers.Value) + "','" + richTextComment.Text.Trim() + "'," + Total + ",'" + flatId + "','" + cmbMonth.Text.Trim() + "','" + time + "')";
                            CUD(sql);
                            MessageBox.Show("Saved!");
                            comboBox1.ResetText();
                            cmbMonth.ResetText();
                            getMonthlyCollections();
                            long id = invoiceId();
                            txtInvoiceNo.Text = "Inv000" + (id + 1);
                        }
                        else
                        {
                            lblMessage.Text = "Already Exist";
                            lblMessage.ForeColor = Color.Red;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Slect Appartment and Month Field");
                    } 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Something goes wrong!");
                }
            }
            if (btnSave.Text == "Update")
            {
                try
                {
                    updateMonthlyCollection();
                }
                catch
                {
                    MessageBox.Show("Something Goes Wrong!");
                }
            }
        }
        void editButton()
        {
            DataGridViewButtonColumn EditButton = new DataGridViewButtonColumn();
            EditButton.UseColumnTextForButtonValue = true;
            EditButton.HeaderText = "Edit";
            EditButton.DataPropertyName = "lnkColumn";
            //EditButton.LinkBehavior = LinkBehavior.SystemDefault;
            EditButton.Text = "Edit";
            EditButton.FlatStyle = FlatStyle.Flat;
            EditButton.DefaultCellStyle.ForeColor = Color.White;
            EditButton.DefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            EditButton.DefaultCellStyle.SelectionBackColor = ThemeColor.SecondaryColor;
            EditButton.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.Columns.Add(EditButton);
        }
        void printButton()
        {
            DataGridViewButtonColumn print = new DataGridViewButtonColumn();
            //Deletelink.UseColumnTextForLinkValue = true;
            print.HeaderText = "Print";
            print.Text = "Print";
            print.UseColumnTextForButtonValue = true;
            print.FlatStyle = FlatStyle.Flat;
            print.DefaultCellStyle.ForeColor = Color.White;
            print.DefaultCellStyle.BackColor = ThemeColor.PrimaryColor;
            print.DefaultCellStyle.SelectionBackColor = ThemeColor.SecondaryColor;
            print.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.Columns.Add(print);
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex == 14)
            {
                hiddenTextBox.Text = dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString();
                cmbMonth.Text = dataGridView1.Rows[e.RowIndex].Cells["Month"].Value.ToString();
                comboBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["Appartment"].Value.ToString();
                numGasBill.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Gas Bill"].Value);
                numElectricBill.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Electric Bill"].Value);
                numMosqueBill.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Mosque Bill"].Value);
                numLPS.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["LPS"].Value);
                numWaterBill.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Water Bill"].Value);
                numDue.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Due"].Value);
                numOthers.Value = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Others"].Value);
                richTextComment.Text = dataGridView1.Rows[e.RowIndex].Cells["Comment"].Value.ToString();
                btnSave.Text = "Update";
                comboBox1.Enabled = false;
                cmbMonth.Enabled = false;
            }
            if(e.ColumnIndex == 15)
            {
                //get every column value here
                string id = dataGridView1.Rows[e.RowIndex].Cells["InvoiceNo"].Value.ToString();
                string month = dataGridView1.Rows[e.RowIndex].Cells["Month"].Value.ToString();
                string apartment = dataGridView1.Rows[e.RowIndex].Cells["Appartment"].Value.ToString();
                
                double electricBill = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Electric Bill"].Value);
                double mosqueBill = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Mosque Bill"].Value);
                double lps = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["LPS"].Value);
                double due = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Due"].Value);
                string comment = dataGridView1.Rows[e.RowIndex].Cells["Comment"].Value.ToString();
                double gasBill = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Gas Bill"].Value); 
                double waterBill = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Water Bill"].Value);
                double otherBill = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Others"].Value);
                double total = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Total"].Value);
                
                PrintInvoice frm = new PrintInvoice(id,month,apartment,electricBill,mosqueBill,lps,due,comment,gasBill, waterBill, otherBill,total);
                frm.ShowDialog();
            }
        }
        void updateMonthlyCollection()
        {
            int flatId = Convert.ToInt32(comboBox1.SelectedValue.ToString());
            int id = Convert.ToInt32(hiddenTextBox.Text.Trim());
            string sql = @"UPDATE Invoice SET GasBill ='" + numGasBill.Value + "'" +
                    ",ElectricBill ='" + numElectricBill.Value + "'" +
                    ",MosqueBill ='" + numMosqueBill.Value + "'" +
                    ",LPS ='" + numLPS.Value + "'" +
                    ",WaterBill ='" + numWaterBill.Value + "'" +
                    ",Others ='" + numOthers.Value + "'" +
                    ",Comment ='" + richTextComment.Text.Trim() + "',FlatID = '"+flatId+"' WHERE ID=" + id + "";
            CUD(sql);
            btnSave.Text = "Save";
            MessageBox.Show("Updated!");
            getMonthlyCollections();
        }
        private void textBox_Click(object sender, EventArgs e)
        {
            if (sender.GetType() == typeof(TextBox))
                ((TextBox)sender).SelectAll();
            else if (sender.GetType() == typeof(NumericUpDown))
            {
                NumericUpDown numeric = (NumericUpDown)sender;
                (numeric).Select(0, numeric.Value.ToString().Length + 3);
            }
            else
            {
                ((RichTextBox)sender).SelectAll();
            }
        }
        long invoiceId()
        {
            DataTable dt;
            string cmd = "SELECT MAX(ID) FROM Invoice";
            dt = (DataTable)Select(cmd).Data;
            long id = dt.Rows.Count > 0 && !string.IsNullOrEmpty(dt.Rows[0][0].ToString()) ? Convert.ToInt64(dt.Rows[0][0]) : 0;
            return id;
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            comboBox1.ResetText();
            cmbMonth.ResetText();
            lblMessage.Text = "";
        }
    }
}
