﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class User : Common
    {
        public User()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtFullName.Text.Trim();
            string phoneNo = txtPhoneNo.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();
            string rePassword = txtRePassword.Text.Trim();

            if(password != rePassword)
            {
                MessageBox.Show("Password Mismatched!!!");
            }

            else
            {
                string sql = @"INSERT INTO Users(FullName, PhoneNumber, Email, Password, CreatedDate, CreatedBy, UpdatedDate) VALUES ('" + name + "', '" + phoneNo + "', '" + email + "', '" + password + "', '" +DateTime.Now+"', '1', '" +DateTime.Now+ "')";
                string sql2 = @"INSERT INTO Users(FullName, PhoneNumber, Email, CreatedDate, CreatedBy, UpdatedDate) VALUES ('" + name + "', '" + phoneNo + "', '" + email + "', '" +DateTime.Now+"', '1', '" +DateTime.Now+ "')";
                string sql1 = @"INSERT INTO Users(UserPassword) VALUES ('" + email+ "')";
                CUD(sql1);
                MessageBox.Show("Registration Completed!!!");
            }
        }
    }
}
