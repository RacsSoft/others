﻿using System;
using Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages
{
    public partial class Bill_Collection : Common
    {
        public Bill_Collection()
        {
            InitializeComponent();
        }

        private void Monthly_Collection_Load(object sender, EventArgs e)
        {
            getInvoiceId();
            cmbBankCash.SelectedIndex = 0;

			Bill_Collection_Grid_Load();

		}
        void getInvoiceId()
        {
			try
			{
                string sql = @"SELECT ID, InvoiceNo From Invoice";
                DataTable dt = (DataTable)Select(sql).Data;
                cmbInvId.DataSource = dt;
                cmbInvId.DisplayMember = "InvoiceNo";
                cmbInvId.ValueMember = "ID";
            }
			catch (Exception ex)
			{

				throw;
			}
            
        }

        private void cmbInvId_SelectedIndexChanged(object sender, EventArgs e)
        {
            string data = cmbInvId.SelectedValue.ToString();
            string sql = @"SELECT * From Invoice WHERE ID = " + data + "";
            DataTable dt = (DataTable)Select(sql).Data;
            if(dt != null && dt.Rows.Count > 0)
            {
                numPayable.Value = Convert.ToDecimal(dt.Rows[0]["Total"].ToString());
                //foreach (DataRow dr in dt.Rows)
                //{
                //    numPayable.Value = Convert.ToDecimal(dr["Total"].ToString());
                //}
            }
        }



		void getItems()
		{
			string sql = @"select * from Invoice";
			DataTable dt = (DataTable)Select(sql).Data;
			dgvCollection.DataSource = dt;
			dgvCollection.AutoGenerateColumns = false;
			dgvCollection.Columns[0].Visible = false;
			dgvCollection.Refresh();
		}

		private void Bill_Collection_Grid_Load()
		{
			getItems();

			DataGridViewButtonColumn edit = new DataGridViewButtonColumn();
			//Editlink.UseColumnTextForLinkValue = true;
			edit.HeaderText = "Edit";
			//Editlink.LinkBehavior = LinkBehavior.SystemDefault;
			edit.Name = "Edit";
			edit.Text = "Edit";
			edit.UseColumnTextForButtonValue = true;
			dgvCollection.Columns.Add(edit);

			DataGridViewButtonColumn delete = new DataGridViewButtonColumn();
			//Deletelink.UseColumnTextForLinkValue = true;
			delete.HeaderText = "Delete";
			delete.DataPropertyName = "delete";
			delete.Text = "Delete";
			delete.Name = "Delete";
			delete.UseColumnTextForButtonValue = true;
			dgvCollection.Columns.Add(delete);

			DataGridViewButtonColumn print = new DataGridViewButtonColumn();
			//Deletelink.UseColumnTextForLinkValue = true;
			print.HeaderText = "Print";
			print.Text = "Print";
			print.UseColumnTextForButtonValue = true;
			dgvCollection.Columns.Add(print);
		}

		private void dgItems_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
				if (e.ColumnIndex == 17)
				{
					long id = Convert.ToInt64(dgvCollection.Rows[e.RowIndex].Cells[0].Value.ToString());
					string name = dgvCollection.Rows[e.RowIndex].Cells[1].Value.ToString();
					string code = dgvCollection.Rows[e.RowIndex].Cells[2].Value.ToString();
					int totalBuyingQuantity = Convert.ToInt32(dgvCollection.Rows[e.RowIndex].Cells[3].Value);
					int price = Convert.ToInt32(dgvCollection.Rows[e.RowIndex].Cells[4].Value);
					int sellingPrice = Convert.ToInt32(dgvCollection.Rows[e.RowIndex].Cells[5].Value);
				}
				else if (e.ColumnIndex == 18)
				{
					long id = Convert.ToInt64(dgvCollection.Rows[e.RowIndex].Cells[0].Value.ToString());
					string name = dgvCollection.Rows[e.RowIndex].Cells[1].Value.ToString();
					DialogResult dr = MessageBox.Show("Are You Sure You Want To Delete " + Environment.NewLine
						+ name + "'s Informations", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
					if (dr.ToString() == "Yes")
					{
						string sql = "DELETE FROM Bill_Collection WHERE Id = " + id;
						if (CUD(sql).IsSuccess)
						{
							getItems();
						}
						else
						{
							MessageBox.Show("Data couldn't delete!");
						}
					}
				}
				else if (e.ColumnIndex == 19)
				{
					long id = Convert.ToInt64(dgvCollection.Rows[e.RowIndex].Cells[0].Value.ToString());
					//get every column value here
					double gasBill = 975.00;
					double waterBill = 258.28;
					double otherBill = 100;
					PrintBill frm = new PrintBill(gasBill, waterBill, otherBill);
					frm.ShowDialog();
					
				}
			}
			catch (Exception ex)
			{
				ex.ToString();
			}
		}

		private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			//e.Graphics.DrawString()
		}
	}
}
