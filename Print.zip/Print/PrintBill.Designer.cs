﻿
namespace Racssoft_Housing.Pages
{
	partial class PrintBill
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lblGas = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.lblWater = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.lblElectricity = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.lblMosque = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.lblOthers = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.printDialog = new System.Windows.Forms.PrintDialog();
			this.printDocument = new System.Drawing.Printing.PrintDocument();
			this.btnPrint = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(137, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(163, 24);
			this.label1.TabIndex = 0;
			this.label1.Text = "ABC Housig Ltd.";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(20, 155);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(63, 20);
			this.label2.TabIndex = 1;
			this.label2.Text = "Gas Bill";
			// 
			// lblGas
			// 
			this.lblGas.AutoSize = true;
			this.lblGas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblGas.Location = new System.Drawing.Point(116, 155);
			this.lblGas.Name = "lblGas";
			this.lblGas.Size = new System.Drawing.Size(58, 20);
			this.lblGas.TabIndex = 1;
			this.lblGas.Text = "975.00";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(251, 155);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(76, 20);
			this.label4.TabIndex = 1;
			this.label4.Text = "Water Bill";
			// 
			// lblWater
			// 
			this.lblWater.AutoSize = true;
			this.lblWater.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblWater.Location = new System.Drawing.Point(361, 155);
			this.lblWater.Name = "lblWater";
			this.lblWater.Size = new System.Drawing.Size(40, 20);
			this.lblWater.TabIndex = 1;
			this.lblWater.Text = "0.00";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(20, 189);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(100, 20);
			this.label6.TabIndex = 1;
			this.label6.Text = "Electricity Bill";
			// 
			// lblElectricity
			// 
			this.lblElectricity.AutoSize = true;
			this.lblElectricity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblElectricity.Location = new System.Drawing.Point(116, 189);
			this.lblElectricity.Name = "lblElectricity";
			this.lblElectricity.Size = new System.Drawing.Size(58, 20);
			this.lblElectricity.TabIndex = 1;
			this.lblElectricity.Text = "257.25";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(251, 189);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(90, 20);
			this.label8.TabIndex = 1;
			this.label8.Text = "Mosque Bill";
			// 
			// lblMosque
			// 
			this.lblMosque.AutoSize = true;
			this.lblMosque.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMosque.Location = new System.Drawing.Point(364, 189);
			this.lblMosque.Name = "lblMosque";
			this.lblMosque.Size = new System.Drawing.Size(36, 20);
			this.lblMosque.TabIndex = 1;
			this.lblMosque.Text = "200";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.Location = new System.Drawing.Point(20, 228);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(86, 20);
			this.label10.TabIndex = 1;
			this.label10.Text = "LP Gas Bill";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(133, 228);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(36, 20);
			this.label11.TabIndex = 1;
			this.label11.Text = "950";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.Location = new System.Drawing.Point(251, 228);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(57, 20);
			this.label12.TabIndex = 1;
			this.label12.Text = "Others";
			// 
			// lblOthers
			// 
			this.lblOthers.AutoSize = true;
			this.lblOthers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblOthers.Location = new System.Drawing.Point(364, 228);
			this.lblOthers.Name = "lblOthers";
			this.lblOthers.Size = new System.Drawing.Size(36, 20);
			this.lblOthers.TabIndex = 1;
			this.lblOthers.Text = "150";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(81, 303);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(52, 13);
			this.label14.TabIndex = 1;
			this.label14.Text = "Secretary";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(134, 368);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(135, 13);
			this.label15.TabIndex = 1;
			this.label15.Text = "Powered By: Racssoft.com";
			this.label15.Click += new System.EventHandler(this.label15_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(187, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(45, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Address";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(166, 73);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(85, 18);
			this.label5.TabIndex = 2;
			this.label5.Text = "December";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(12, 114);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(140, 18);
			this.label7.TabIndex = 2;
			this.label7.Text = "Mohammad Hanif";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.Location = new System.Drawing.Point(259, 114);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(68, 18);
			this.label9.TabIndex = 2;
			this.label9.Text = "Flat No.";
			// 
			// printDialog
			// 
			this.printDialog.UseEXDialog = true;
			// 
			// printDocument
			// 
			this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
			// 
			// btnPrint
			// 
			this.btnPrint.Location = new System.Drawing.Point(331, 371);
			this.btnPrint.Name = "btnPrint";
			this.btnPrint.Size = new System.Drawing.Size(75, 23);
			this.btnPrint.TabIndex = 3;
			this.btnPrint.Text = "OK";
			this.btnPrint.UseVisualStyleBackColor = true;
			this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
			// 
			// PrintBill
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(418, 406);
			this.Controls.Add(this.btnPrint);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.lblWater);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lblOthers);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.lblMosque);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.lblElectricity);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.lblGas);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "PrintBill";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "PrintBill";
			this.Load += new System.EventHandler(this.PrintBill_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lblGas;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label lblWater;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label lblElectricity;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label lblMosque;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label lblOthers;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.PrintDialog printDialog;
		private System.Drawing.Printing.PrintDocument printDocument;
		private System.Windows.Forms.Button btnPrint;
	}
}