﻿
namespace Racssoft_Housing.Pages
{
    partial class BalanceSheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label1 = new System.Windows.Forms.Label();
            this.lblOpeningBalanceBank = new System.Windows.Forms.Label();
            this.dgCredit = new System.Windows.Forms.DataGridView();
            this.dgDebit = new System.Windows.Forms.DataGridView();
            this.lblTotalCredit = new System.Windows.Forms.Label();
            this.lblCreditBank = new System.Windows.Forms.Label();
            this.lblCreditCash = new System.Windows.Forms.Label();
            this.dpFrom = new System.Windows.Forms.DateTimePicker();
            this.lblOpeningBalanceCash = new System.Windows.Forms.Label();
            this.lblOpeningBalance = new System.Windows.Forms.Label();
            this.lblTotalDebit = new System.Windows.Forms.Label();
            this.lblCurrentBalance = new System.Windows.Forms.Label();
            this.lblCurrentBalanceBank = new System.Windows.Forms.Label();
            this.lblCurrentBalanceCash = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dpTo = new System.Windows.Forms.DateTimePicker();
            this.btnDetailOpening = new FontAwesome.Sharp.IconButton();
            this.btnRefresh = new FontAwesome.Sharp.IconButton();
            this.btnDetailCurrent = new FontAwesome.Sharp.IconButton();
            this.saleChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lblLiability = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.cmbSearch = new System.Windows.Forms.ComboBox();
            this.calendar = new System.Windows.Forms.MonthCalendar();
            ((System.ComponentModel.ISupportInitialize)(this.dgCredit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDebit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleChart)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(717, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "From";
            this.label1.Visible = false;
            // 
            // lblOpeningBalanceBank
            // 
            this.lblOpeningBalanceBank.AutoSize = true;
            this.lblOpeningBalanceBank.Location = new System.Drawing.Point(658, 39);
            this.lblOpeningBalanceBank.Name = "lblOpeningBalanceBank";
            this.lblOpeningBalanceBank.Size = new System.Drawing.Size(44, 13);
            this.lblOpeningBalanceBank.TabIndex = 0;
            this.lblOpeningBalanceBank.Text = "Bank: 0";
            // 
            // dgCredit
            // 
            this.dgCredit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCredit.Location = new System.Drawing.Point(324, 246);
            this.dgCredit.Name = "dgCredit";
            this.dgCredit.Size = new System.Drawing.Size(389, 150);
            this.dgCredit.TabIndex = 1;
            this.dgCredit.Visible = false;
            // 
            // dgDebit
            // 
            this.dgDebit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDebit.Location = new System.Drawing.Point(719, 246);
            this.dgDebit.Name = "dgDebit";
            this.dgDebit.Size = new System.Drawing.Size(299, 150);
            this.dgDebit.TabIndex = 1;
            this.dgDebit.Visible = false;
            // 
            // lblTotalCredit
            // 
            this.lblTotalCredit.AutoSize = true;
            this.lblTotalCredit.Location = new System.Drawing.Point(530, 404);
            this.lblTotalCredit.Name = "lblTotalCredit";
            this.lblTotalCredit.Size = new System.Drawing.Size(73, 13);
            this.lblTotalCredit.TabIndex = 0;
            this.lblTotalCredit.Text = "Total Credit: 0";
            // 
            // lblCreditBank
            // 
            this.lblCreditBank.AutoSize = true;
            this.lblCreditBank.Location = new System.Drawing.Point(559, 456);
            this.lblCreditBank.Name = "lblCreditBank";
            this.lblCreditBank.Size = new System.Drawing.Size(44, 13);
            this.lblCreditBank.TabIndex = 0;
            this.lblCreditBank.Text = "Bank: 0";
            // 
            // lblCreditCash
            // 
            this.lblCreditCash.AutoSize = true;
            this.lblCreditCash.Location = new System.Drawing.Point(559, 430);
            this.lblCreditCash.Name = "lblCreditCash";
            this.lblCreditCash.Size = new System.Drawing.Size(43, 13);
            this.lblCreditCash.TabIndex = 0;
            this.lblCreditCash.Text = "Cash: 0";
            // 
            // dpFrom
            // 
            this.dpFrom.Location = new System.Drawing.Point(753, 44);
            this.dpFrom.Name = "dpFrom";
            this.dpFrom.Size = new System.Drawing.Size(200, 20);
            this.dpFrom.TabIndex = 3;
            this.dpFrom.Visible = false;
            // 
            // lblOpeningBalanceCash
            // 
            this.lblOpeningBalanceCash.AutoSize = true;
            this.lblOpeningBalanceCash.Location = new System.Drawing.Point(538, 36);
            this.lblOpeningBalanceCash.Name = "lblOpeningBalanceCash";
            this.lblOpeningBalanceCash.Size = new System.Drawing.Size(43, 13);
            this.lblOpeningBalanceCash.TabIndex = 0;
            this.lblOpeningBalanceCash.Text = "Cash: 0";
            // 
            // lblOpeningBalance
            // 
            this.lblOpeningBalance.AutoSize = true;
            this.lblOpeningBalance.Location = new System.Drawing.Point(349, 39);
            this.lblOpeningBalance.Name = "lblOpeningBalance";
            this.lblOpeningBalance.Size = new System.Drawing.Size(101, 13);
            this.lblOpeningBalance.TabIndex = 0;
            this.lblOpeningBalance.Text = "Opening Balance: 0";
            // 
            // lblTotalDebit
            // 
            this.lblTotalDebit.AutoSize = true;
            this.lblTotalDebit.Location = new System.Drawing.Point(750, 404);
            this.lblTotalDebit.Name = "lblTotalDebit";
            this.lblTotalDebit.Size = new System.Drawing.Size(71, 13);
            this.lblTotalDebit.TabIndex = 0;
            this.lblTotalDebit.Text = "Total Debit: 0";
            // 
            // lblCurrentBalance
            // 
            this.lblCurrentBalance.AutoSize = true;
            this.lblCurrentBalance.Location = new System.Drawing.Point(355, 65);
            this.lblCurrentBalance.Name = "lblCurrentBalance";
            this.lblCurrentBalance.Size = new System.Drawing.Size(95, 13);
            this.lblCurrentBalance.TabIndex = 0;
            this.lblCurrentBalance.Text = "Current Balance: 0";
            // 
            // lblCurrentBalanceBank
            // 
            this.lblCurrentBalanceBank.AutoSize = true;
            this.lblCurrentBalanceBank.Location = new System.Drawing.Point(658, 70);
            this.lblCurrentBalanceBank.Name = "lblCurrentBalanceBank";
            this.lblCurrentBalanceBank.Size = new System.Drawing.Size(44, 13);
            this.lblCurrentBalanceBank.TabIndex = 0;
            this.lblCurrentBalanceBank.Text = "Bank: 0";
            this.lblCurrentBalanceBank.Visible = false;
            // 
            // lblCurrentBalanceCash
            // 
            this.lblCurrentBalanceCash.AutoSize = true;
            this.lblCurrentBalanceCash.Location = new System.Drawing.Point(538, 67);
            this.lblCurrentBalanceCash.Name = "lblCurrentBalanceCash";
            this.lblCurrentBalanceCash.Size = new System.Drawing.Size(43, 13);
            this.lblCurrentBalanceCash.TabIndex = 0;
            this.lblCurrentBalanceCash.Text = "Cash: 0";
            this.lblCurrentBalanceCash.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(717, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "To";
            this.label2.Visible = false;
            // 
            // dpTo
            // 
            this.dpTo.Location = new System.Drawing.Point(753, 76);
            this.dpTo.Name = "dpTo";
            this.dpTo.Size = new System.Drawing.Size(200, 20);
            this.dpTo.TabIndex = 3;
            this.dpTo.Visible = false;
            // 
            // btnDetailOpening
            // 
            this.btnDetailOpening.BackgroundImage = global::Racssoft_Housing.Properties.Resources.details;
            this.btnDetailOpening.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDetailOpening.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDetailOpening.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnDetailOpening.IconColor = System.Drawing.Color.Black;
            this.btnDetailOpening.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnDetailOpening.Location = new System.Drawing.Point(477, 36);
            this.btnDetailOpening.Name = "btnDetailOpening";
            this.btnDetailOpening.Size = new System.Drawing.Size(31, 19);
            this.btnDetailOpening.TabIndex = 2;
            this.btnDetailOpening.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDetailOpening.UseVisualStyleBackColor = true;
            // 
            // btnRefresh
            // 
            this.btnRefresh.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnRefresh.IconColor = System.Drawing.Color.Black;
            this.btnRefresh.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnRefresh.Location = new System.Drawing.Point(735, 113);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(62, 23);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Visible = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnDetailCurrent
            // 
            this.btnDetailCurrent.BackgroundImage = global::Racssoft_Housing.Properties.Resources.details;
            this.btnDetailCurrent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDetailCurrent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDetailCurrent.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnDetailCurrent.IconColor = System.Drawing.Color.Black;
            this.btnDetailCurrent.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnDetailCurrent.Location = new System.Drawing.Point(477, 64);
            this.btnDetailCurrent.Name = "btnDetailCurrent";
            this.btnDetailCurrent.Size = new System.Drawing.Size(31, 19);
            this.btnDetailCurrent.TabIndex = 2;
            this.btnDetailCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDetailCurrent.UseVisualStyleBackColor = true;
            // 
            // saleChart
            // 
            chartArea1.Name = "ChartArea1";
            this.saleChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.saleChart.Legends.Add(legend1);
            this.saleChart.Location = new System.Drawing.Point(-2, 4);
            this.saleChart.Name = "saleChart";
            this.saleChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series1.Legend = "Legend1";
            series1.Name = "sale";
            this.saleChart.Series.Add(series1);
            this.saleChart.Size = new System.Drawing.Size(303, 451);
            this.saleChart.TabIndex = 5;
            this.saleChart.Text = "chart1";
            // 
            // lblLiability
            // 
            this.lblLiability.AutoSize = true;
            this.lblLiability.Location = new System.Drawing.Point(899, 404);
            this.lblLiability.Name = "lblLiability";
            this.lblLiability.Size = new System.Drawing.Size(83, 13);
            this.lblLiability.TabIndex = 0;
            this.lblLiability.Text = "Total Liability : 0";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(349, 4);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(50, 13);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.Text = "Message";
            this.lblMessage.Visible = false;
            // 
            // cmbSearch
            // 
            this.cmbSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmbSearch.FormattingEnabled = true;
            this.cmbSearch.Items.AddRange(new object[] {
            "Today",
            "This Month",
            "Last Month",
            "This Year",
            "Last Year",
            "Month Wise",
            "Date Wise"});
            this.cmbSearch.Location = new System.Drawing.Point(828, 17);
            this.cmbSearch.Name = "cmbSearch";
            this.cmbSearch.Size = new System.Drawing.Size(154, 21);
            this.cmbSearch.TabIndex = 6;
            this.cmbSearch.SelectedIndexChanged += new System.EventHandler(this.cmbSearch_SelectedIndexChanged);
            // 
            // calendar
            // 
            this.calendar.Location = new System.Drawing.Point(791, 76);
            this.calendar.Name = "calendar";
            this.calendar.TabIndex = 7;
            this.calendar.Visible = false;
            // 
            // BalanceSheet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 524);
            this.Controls.Add(this.calendar);
            this.Controls.Add(this.cmbSearch);
            this.Controls.Add(this.saleChart);
            this.Controls.Add(this.dpTo);
            this.Controls.Add(this.dpFrom);
            this.Controls.Add(this.btnDetailCurrent);
            this.Controls.Add(this.btnDetailOpening);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgDebit);
            this.Controls.Add(this.dgCredit);
            this.Controls.Add(this.lblCurrentBalance);
            this.Controls.Add(this.lblCurrentBalanceCash);
            this.Controls.Add(this.lblCreditCash);
            this.Controls.Add(this.lblLiability);
            this.Controls.Add(this.lblTotalDebit);
            this.Controls.Add(this.lblCurrentBalanceBank);
            this.Controls.Add(this.lblCreditBank);
            this.Controls.Add(this.lblTotalCredit);
            this.Controls.Add(this.lblOpeningBalance);
            this.Controls.Add(this.lblOpeningBalanceCash);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblOpeningBalanceBank);
            this.Controls.Add(this.label1);
            this.Name = "BalanceSheet";
            this.Text = "BalanceSheet";
            this.Load += new System.EventHandler(this.BalanceSheet_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgCredit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgDebit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblOpeningBalanceBank;
        private System.Windows.Forms.DataGridView dgCredit;
        private System.Windows.Forms.DataGridView dgDebit;
        private System.Windows.Forms.Label lblTotalCredit;
        private System.Windows.Forms.Label lblCreditBank;
        private System.Windows.Forms.Label lblCreditCash;
        private FontAwesome.Sharp.IconButton btnRefresh;
        private System.Windows.Forms.DateTimePicker dpFrom;
        private System.Windows.Forms.Label lblOpeningBalanceCash;
        private System.Windows.Forms.Label lblOpeningBalance;
        private System.Windows.Forms.Label lblTotalDebit;
        private System.Windows.Forms.Label lblCurrentBalance;
        private System.Windows.Forms.Label lblCurrentBalanceBank;
        private System.Windows.Forms.Label lblCurrentBalanceCash;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dpTo;
        private FontAwesome.Sharp.IconButton btnDetailOpening;
        private FontAwesome.Sharp.IconButton btnDetailCurrent;
        private System.Windows.Forms.DataVisualization.Charting.Chart saleChart;
        private System.Windows.Forms.Label lblLiability;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ComboBox cmbSearch;
        private System.Windows.Forms.MonthCalendar calendar;
    }
}