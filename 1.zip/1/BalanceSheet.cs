﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Schema;

namespace Racssoft_Housing.Pages
{
    public partial class BalanceSheet : Common
    {
        public BalanceSheet()
        {
            InitializeComponent();
        }

        void graph()
        {
            saleChart.Series["sale"].Points.AddXY("Profit", 10000);
            saleChart.Series["sale"].Points[0].Color = Color.YellowGreen;
            saleChart.Series["sale"].Points.AddXY("Loss", 200);
            saleChart.Series["sale"].Points[1].Color = Color.Red;
        }
        private void BalanceSheet_Load(object sender, EventArgs e)
        {
            graph();
            LoadCredit(dpFrom.Value, dpTo.Value);
            LoadDebit(dpFrom.Value, dpTo.Value);
           

            var openingBalance = Balance(dpFrom.Value.AddDays(-1));
            openingBalanceCalculation(openingBalance);
            var currentBalance = Balance(dpTo.Value);
            currentBalanceCalculation(currentBalance);
        }

        private void openingBalanceCalculation((double, double) openingBalance)
        {
            double cash = openingBalance.Item1 - openingBalance.Item2;
            lblOpeningBalance.Text = "Opening Balance: " + cash.ToString();
            lblOpeningBalanceCash.Text = "Opening Balance(Cash): " + cash.ToString();
            lblOpeningBalanceBank.Text = "Opening Balance(Bank): " + 0;
        }
        private void currentBalanceCalculation((double, double) currentBalance)
        {
            double cash = currentBalance.Item1 - currentBalance.Item2;
            lblCurrentBalance.Text = "Current Balance: " + cash.ToString();
            lblCurrentBalanceCash.Text = "Current Balance(Cash): " + cash.ToString();
            lblCurrentBalanceBank.Text = "Current Balance(Bank): " + 0;
        }

        void LoadCredit(DateTime dFrom, DateTime dTo)
        {
            string sql = @"SELECT PaidAmmount as [Paid], DueAmmount as [Due], PaidDate as [Paid Date] FROM Bill_Collection 
                    WHERE PaidDate Between #" + dFrom.Date + "# AND #" + dTo.Date + "# ";
            DataTable dt = (DataTable)Select(sql).Data;
            dgCredit.DataSource = dt;
            object totoal = dt.Compute("Sum(Paid)", "");
            lblTotalCredit.Text = "Total Credit: " + totoal;
            lblCreditCash.Text = "Cash: " + totoal;
        }
        void LoadDebit(DateTime dFrom, DateTime dTo)
        {
            string sql = @"SELECT WhichDateTime as [Collection Date], Cost as Amount FROM Daily_Expenditure_Debit 
                        WHERE WhichDateTime Between #" + dFrom.Date + "# AND #" + dTo.Date + "#";
            DataTable dt = (DataTable)Select(sql).Data;
            dgDebit.DataSource = dt;
            object totoal = dt.Compute("Sum(Amount)", "");
            totoal = totoal is DBNull ? 0 : totoal;
            lblTotalDebit.Text = "Total Debit: " + totoal;
        }
        (double, double) Balance(DateTime date)
        {
            string sql = @"SELECT PaidAmmount as [Paid], DueAmmount as [Due], PaidDate as [Paid Date] FROM Bill_Collection WHERE PaidDate = #" + date.Date.ToString("MM/dd/yyyy") + "#";
            DataTable dt = (DataTable)Select(sql).Data;

            object totoalCredit = dt.Compute("Sum(Paid)", "");
            totoalCredit = totoalCredit is DBNull ? 0 : totoalCredit;
            sql = @"SELECT WhichDateTime as [Collection Date], Cost as Amount FROM Daily_Expenditure_Debit WHERE WhichDateTime = #" + date.Date.ToString("MM/dd/yyyy") + "#";
            dt = (DataTable)Select(sql).Data;

            object totoalDebit = dt.Compute("Sum(Amount)", "");
            totoalDebit = totoalDebit is DBNull ? 0 : totoalDebit;
            return (Convert.ToDouble(totoalCredit), Convert.ToDouble(totoalDebit));
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (dpFrom.Value > dpTo.Value) { lblMessage.Text = "Date range not valid!"; lblMessage.Visible = true; return; }
            LoadCredit(dpFrom.Value, dpTo.Value);
            LoadDebit(dpFrom.Value, dpTo.Value);

            var openingBalance = Balance(dpFrom.Value.Date.AddDays(-1));
            openingBalanceCalculation(openingBalance);
            var currentBalance = Balance(dpTo.Value);
            currentBalanceCalculation(currentBalance);
        }

        private void cmbSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            string searchText = cmbSearch.Text;
            if (searchText == "Month Wise")
            {
                calendar.Visible = true;
                dpFrom.Visible = false;
                dpTo.Visible = false;
                btnRefresh.Visible = false;
            }
            else if (searchText == "Date Wise")
            {
                calendar.Visible = false;
                dpFrom.Visible = true;
                dpTo.Visible = true;
                btnRefresh.Visible = true;
            }
        }
    }
}
