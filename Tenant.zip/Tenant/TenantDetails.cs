﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages.Tenant
{
	public partial class TenantDetails : Common
	{
		int tenantId = 0;
		public TenantDetails(int tId)
		{
			InitializeComponent();
			tenantId = tId;
		}

		private void TenantDetails_Load(object sender, EventArgs e)
		{
			string sql = @"Select * from Tenants where ID = " + tenantId;
			DataTable dt = (DataTable)Select(sql).Data;
			string details = string.Empty;
			int col = dt.Columns.Count;
			for (int i = 0; i < col; i++)
			{
				details += dt.Columns[i].ColumnName + ": " + dt.Rows[0][i].ToString() + Environment.NewLine;
			}

			txtDetails.Text = details;

			txtDetails.SelectAll();
			txtDetails.SelectionAlignment = HorizontalAlignment.Center;
			txtDetails.DeselectAll();
		}

		private void btnPrint_Click(object sender, EventArgs e)
		{
			if (printDialog1.ShowDialog() == DialogResult.OK)
			{
				printDocument1.Print();
			}
		}

		private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
		{
			char[] param = { '\n' };

			if (printDialog1.PrinterSettings.PrintRange == PrintRange.Selection)
			{
				lines = txtDetails.SelectedText.Split(param);
			}
			else
			{
				lines = txtDetails.Text.Split(param);
			}

			int i = 0;
			char[] trimParam = { '\r' };
			foreach (string s in lines)
			{
				lines[i++] = s.TrimEnd(trimParam);
			}
		}

		private int linesPrinted;
		private string[] lines;

		private void OnPrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			int x = e.MarginBounds.Left;
			int y = e.MarginBounds.Top;
			Brush brush = new SolidBrush(txtDetails.ForeColor);

			while (linesPrinted < lines.Length)
			{
				e.Graphics.DrawString(lines[linesPrinted++],
					txtDetails.Font, brush, x, y);
				y += 15;
				if (y >= e.MarginBounds.Bottom)
				{
					e.HasMorePages = true;
					return;
				}
			}

			linesPrinted = 0;
			e.HasMorePages = false;
		}
	}
}
