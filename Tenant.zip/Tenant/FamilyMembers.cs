﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages.Tenant
{
    public partial class FamilyMembers : Form
    {
        public string Name, Mobile, Age, Occupation
            , Name2, Mobile2, Age2, Occupation2, Name3, Mobile3, Age3, Occupation3;

        int i = 0;

       // private void btnAddMore_Click(object sender, EventArgs e)
       // {
       //     System.Windows.Forms.GroupBox manualGroupBox1 = new GroupBox();

       // }

       //private void createAGroup()
       // {
       //     Label lbl = new Label();
       //     lbl.AutoSize = true;
       //     lbl.Location = new System.Drawing.Point(-1, 22);
       //     lbl.Name = "lbl" + (i++);
       //     lbl.Size = new System.Drawing.Size(35, 13);
       //     lbl.TabIndex = 14;
       //     lbl.Text = "Name";
       // }

        public FamilyMembers()
        {
            InitializeComponent();
            LoadTheme();
        }
        private void LoadTheme()
        {
            btnOK.BackColor = ThemeColor.PrimaryColor;
            btnOK.ForeColor = Color.White;
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label15.ForeColor = ThemeColor.PrimaryColor;
            label10.ForeColor = ThemeColor.PrimaryColor;
            label4.ForeColor = ThemeColor.PrimaryColor;
            label5.ForeColor = ThemeColor.PrimaryColor;
            label6.ForeColor = ThemeColor.PrimaryColor;
            label7.ForeColor = ThemeColor.PrimaryColor;
            label8.ForeColor = ThemeColor.PrimaryColor;
            label9.ForeColor = ThemeColor.PrimaryColor;
            label11.ForeColor = ThemeColor.PrimaryColor;
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            Name = txtName.Text.Trim();
            Mobile = txtMobile.Text.Trim();
            Age = txtAge.Text.Trim();
            Occupation = txtOccupation.Text.Trim();

            Name2 = txtName.Text.Trim();
            Mobile2 = txtMobile.Text.Trim();
            Age2 = txtAge.Text.Trim();
            Occupation2 = txtOccupation.Text.Trim();

            Name3 = txtName.Text.Trim();
            Mobile3 = txtMobile.Text.Trim();
            Age3 = txtAge.Text.Trim();
            Occupation3 = txtOccupation.Text.Trim();

            this.Close();
        }
    }
}
