﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages.Tenant
{
    public partial class HouseWorker : Form
    {
        public string Name, Mobile, NID, Address;
        public HouseWorker()
        {
            InitializeComponent();
            LoadTheme();
        }
        private void LoadTheme()
        {
            btnOK.BackColor = ThemeColor.PrimaryColor;
            btnOK.ForeColor = Color.White;
            label1.ForeColor = ThemeColor.PrimaryColor;
            label2.ForeColor = ThemeColor.PrimaryColor;
            label3.ForeColor = ThemeColor.PrimaryColor;
            label15.ForeColor = ThemeColor.PrimaryColor;
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            Name = txtName.Text.Trim();
            Mobile = txtMobile.Text.Trim();
            NID = txtNID.Text.Trim();
            Address = txtPermanentAddress.Text.Trim();
            this.Close();
        }
    }
}
