﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Racssoft_Housing.Pages.Tenant
{
	public partial class TenantDetails : Common
	{
		int tenantId = 0;
		public TenantDetails(int tId)
		{
			InitializeComponent();
			tenantId = tId;
		}

		private void TenantDetails_Load(object sender, EventArgs e)
		{
			string sql = @"Select * from Tenants where ID = " + tenantId;
			DataTable dt = (DataTable)Select(sql).Data;
			string details = string.Empty;
			int col = dt.Columns.Count;
			for (int i = 0; i < col; i++)
			{
				details += dt.Columns[i].ColumnName + ": " + dt.Rows[0][i].ToString() + Environment.NewLine;
			}

			txtDetails.Text = details;

			txtDetails.SelectAll();
			txtDetails.SelectionAlignment = HorizontalAlignment.Center;
			txtDetails.DeselectAll();
		}

		private void btnPrint_Click(object sender, EventArgs e)
		{

		}
	}
}
